<?php
/**
 * Plugin Name: Claude WordPress MCP
 * Description: Connect Claude AI to your WordPress site via MCP with OAuth 2.0.
 * Version:     30.8.0
 * Author:      Claude MCP
 * License:     GPL v2 or later
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CLAUDE_MCP_VERSION',    '30.8.0' );

/**
 * License server for commercial distribution.
 *
 * This URL is baked in for client builds. The plugin phones home to this
 * endpoint to verify the license key the customer entered. See
 * includes/class-claude-mcp-license.php for the full policy (grace period,
 * expiry, seat enforcement).
 *
 * Advanced users can override this in wp-config.php by defining the constant
 * BEFORE WordPress loads plugins — but the default is our production server.
 */
if ( ! defined( 'CLAUDE_MCP_LICENSE_SERVER' ) ) {
    define( 'CLAUDE_MCP_LICENSE_SERVER', 'https://claude-license-admin-awais-anwar-s-projects.vercel.app' );
}

/**
 * CORS allowlist helper (v30.7.0+).
 *
 * Previously every endpoint sent Access-Control-Allow-Origin: *, which lets
 * any attacker-controlled page in a victim's browser trigger a cross-origin
 * request. For MCP that's low real-world risk (tokens are never in the
 * browser) but still worth tightening.
 *
 * Returns the origin to echo back if it matches claude.ai or anthropic.com;
 * returns '' if the origin should not be allowed (caller sends no ACAO then).
 */
if ( ! function_exists( 'claude_mcp_cors_allowed_origin' ) ) {
    function claude_mcp_cors_allowed_origin() {
        $origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? trim( (string) $_SERVER['HTTP_ORIGIN'] ) : '';
        if ( ! $origin ) return ''; // no origin header (server-to-server) — skip CORS entirely
        $host = parse_url( $origin, PHP_URL_HOST );
        if ( ! $host ) return '';
        $allowed_hosts = array( 'claude.ai', 'anthropic.com' );
        foreach ( $allowed_hosts as $base ) {
            if ( $host === $base || substr( $host, -( strlen( $base ) + 1 ) ) === '.' . $base ) {
                return $origin;
            }
        }
        return '';
    }
}
define( 'CLAUDE_MCP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CLAUDE_MCP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// SSE keepalive timeout in seconds — raise on hosts that kill connections early.
if ( ! defined( 'CLAUDE_MCP_SSE_TIMEOUT' ) ) define( 'CLAUDE_MCP_SSE_TIMEOUT', 55 );

// Rate limiting: max tool calls per minute per token (0 = disabled).
if ( ! defined( 'CLAUDE_MCP_RATE_LIMIT' ) ) define( 'CLAUDE_MCP_RATE_LIMIT', 120 );

require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-permissions.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-activity.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-token-store.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-license.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-oauth.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-templates.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-tools.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-server.php';
require_once CLAUDE_MCP_PLUGIN_DIR . 'includes/class-claude-mcp-admin.php';

class Claude_WordPress_MCP {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init',              array( $this, 'init' ) );
        add_filter( 'query_vars',        array( 'Claude_MCP_OAuth', 'add_query_vars' ) );
        add_action( 'rest_api_init',     array( $this, 'register_rest_routes' ) );
        add_action( 'template_redirect', array( $this, 'handle_early_routes' ), 1 );

        // Daily cron: purge expired OAuth tokens and auth codes.
        add_action( 'claude_mcp_daily_cleanup', array( 'Claude_MCP_OAuth', 'cleanup_expired' ) );
        // Daily cron: revalidate the license (no-op on unmanaged installs).
        add_action( 'claude_mcp_daily_cleanup', array( 'Claude_MCP_License', 'daily_check' ) );
        // Admin notices if the license is in a bad state.
        add_action( 'admin_notices',             array( 'Claude_MCP_License', 'maybe_render_admin_notice' ) );

        register_activation_hook(   __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
    }

    public function init() {
        Claude_MCP_OAuth::add_rewrite_rules();
        Claude_MCP_Templates::register_post_type();
        ( new Claude_MCP_Admin() )->init();
        ( new Claude_MCP_Templates() )->init();

        // Safety net: plugin updates via zip upload don't fire the activation hook,
        // so permissions may be unseeded on first page load after an upgrade.
        // set_defaults() is idempotent (VERSION_MARKER guard).
        if ( ! get_option( Claude_MCP_Permissions::VERSION_MARKER ) ) {
            Claude_MCP_Permissions::set_defaults( get_option( 'claude_mcp_version' ) );
            update_option( 'claude_mcp_version', CLAUDE_MCP_VERSION );
        }

        // Same safety net for the activity + token-store schemas. Both guard
        // internally on a schema-version option, so running every init is fine.
        Claude_MCP_Activity::install_schema();
        Claude_MCP_Token_Store::install_schema();
        Claude_MCP_Token_Store::migrate_from_options();

        // Self-healing: re-inject .htaccess rules if they've been wiped by
        // another plugin, a WordPress update, or a cache purge.
        if ( is_admin() && current_user_can( 'manage_options' ) ) {
            self::maybe_repair_htaccess();
        }
    }

    /**
     * Re-inject .htaccess rules only when they're missing.
     * Runs once per admin page load — uses a transient to avoid
     * reading .htaccess on every single request.
     */
    public static function maybe_repair_htaccess() {
        // Check at most once every 5 minutes.
        if ( get_transient( 'claude_mcp_htaccess_ok' ) ) return;

        // get_home_path() lives in wp-admin/includes/file.php — load it if not yet available.
        if ( ! function_exists( 'get_home_path' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $htaccess = get_home_path() . '.htaccess';
        if ( ! file_exists( $htaccess ) ) return;

        $contents = file_get_contents( $htaccess );
        if ( strpos( $contents, '# BEGIN Claude MCP OAuth Token' ) === false ) {
            self::write_htaccess_rule();
            error_log( 'Claude MCP: .htaccess rules were missing — re-injected.' );
        }

        set_transient( 'claude_mcp_htaccess_ok', 1, 300 );
    }

    public function register_rest_routes() {
        ( new Claude_MCP_Server() )->register_routes();
        ( new Claude_MCP_OAuth() )->register_rest_routes();
        add_filter( 'rest_authentication_errors', array( $this, 'allow_mcp_auth' ), 999 );
    }

    public function allow_mcp_auth( $result ) {
        if ( ! isset( $_SERVER['REQUEST_URI'] ) ) return $result;
        if ( strpos( $_SERVER['REQUEST_URI'], 'claude-mcp/v1' ) === false ) return $result;
        if ( is_wp_error( $result ) ) return null;
        return $result;
    }

    public function handle_early_routes() {
        $oauth = new Claude_MCP_OAuth();
        $path  = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );

        if ( $path === 'authorize' || get_query_var( 'claude_mcp_authorize' ) ) {
            $oauth->handle_authorize();
            exit;
        }

        if ( $path === 'oauth/token' || get_query_var( 'claude_mcp_token' ) ) {
            $oauth->handle_token_direct();
            exit;
        }

        if ( $path === '.well-known/oauth-authorization-server' || get_query_var( 'claude_mcp_wellknown' ) ) {
            // Aggressive cache prevention — LiteSpeed/Airlift can append HTML
            // comments to cached responses, which corrupts JSON for OAuth clients.
            if ( function_exists( 'litespeed_purge_all' ) ) {
                do_action( 'litespeed_control_set_nocache', 'Claude MCP OAuth discovery' );
            }
            header( 'X-LiteSpeed-Cache-Control: no-cache, no-store, must-revalidate' );
            header( 'X-LiteSpeed-Tag: ' );
            header( 'Content-Type: application/json; charset=utf-8' );
            $cmcp_cors_origin = claude_mcp_cors_allowed_origin();
            if ( $cmcp_cors_origin ) header( 'Access-Control-Allow-Origin: ' . $cmcp_cors_origin );
            header( 'Vary: Origin' );
            header( 'Cache-Control: no-cache, no-store, must-revalidate' );
            header( 'Pragma: no-cache' );
            header( 'Expires: 0' );
            $site = get_bloginfo( 'url' );
            echo json_encode( array(
                'issuer'                                => $site,
                'authorization_endpoint'                => $site . '/authorize',
                'token_endpoint'                        => $site . '/oauth/token',
                'response_types_supported'              => array( 'code' ),
                'grant_types_supported'                 => array( 'authorization_code' ),
                'code_challenge_methods_supported'      => array( 'S256' ),
                'token_endpoint_auth_methods_supported' => array( 'none' ),
            ) );
            // Die immediately to prevent any output buffer (Airlift, LiteSpeed,
            // other optimizers) from appending HTML to the JSON.
            die();
        }
    }

    public function activate() {
        // Capture any pre-existing version marker BEFORE we overwrite it, so the
        // permissions seeder can tell fresh-install from upgrade reliably.
        $prior_version = get_option( 'claude_mcp_version' );

        if ( ! get_option( 'claude_mcp_api_key' ) ) {
            update_option( 'claude_mcp_api_key', wp_generate_password( 48, false ) );
        }

        // Seed permission toggles (v30.5.0+). Fresh install → all OFF.
        // Upgrade from an older version → all ON, so existing workflows survive.
        Claude_MCP_Permissions::set_defaults( $prior_version );

        // Install the activity log + token store tables (v30.5.1+). Both idempotent.
        Claude_MCP_Activity::install_schema();
        Claude_MCP_Token_Store::install_schema();
        // One-shot: copy any existing wp_options tokens into the new table.
        Claude_MCP_Token_Store::migrate_from_options();

        // v30.6.0+: establish the watermark install_id and run an initial
        // license check if the server URL is configured.
        Claude_MCP_License::install_id();
        if ( Claude_MCP_License::is_managed() && Claude_MCP_License::key() ) {
            Claude_MCP_License::verify_now();
        }

        // Record current version so later upgrades can detect their starting point.
        update_option( 'claude_mcp_version', CLAUDE_MCP_VERSION );

        Claude_MCP_OAuth::add_rewrite_rules();
        Claude_MCP_Templates::register_post_type();
        flush_rewrite_rules();
        self::write_htaccess_rule();

        // Install bundled starter templates as CPT entries — one-shot, idempotent.
        Claude_MCP_Templates::install_starter_pack();

        // Clear preview backfill guard so the backfill re-runs on next admin
        // load — picks up any templates whose previews are missing after a
        // plugin update (fixes templates saved before the sync bug fix).
        delete_transient( 'claude_mcp_previews_backfilled_v1' );

        if ( ! wp_next_scheduled( 'claude_mcp_daily_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'claude_mcp_daily_cleanup' );
        }
    }

    public function deactivate() {
        self::remove_htaccess_rule();
        flush_rewrite_rules();
        wp_clear_scheduled_hook( 'claude_mcp_daily_cleanup' );
    }

    public static function write_htaccess_rule() {
        if ( ! function_exists( 'get_home_path' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $htaccess = get_home_path() . '.htaccess';

        // Build paths with spaces URL-encoded for .htaccess compatibility.
        $plugin_dir = '/wp-content/plugins/' . str_replace( ' ', '%20', plugin_basename( CLAUDE_MCP_PLUGIN_DIR ) );
        $token_path = $plugin_dir . '/oauth-token.php';
        $wk_path    = $plugin_dir . '/well-known-oauth.php';
        $mcp_path   = $plugin_dir . '/mcp-server.php';

        $marker = 'Claude MCP OAuth Token';

        // CRITICAL: .well-known MUST come before oauth/token.
        // If oauth/token is matched first on some Apache configs, .well-known
        // requests fall through to the token handler and return an error.
        $rules  = array(
            '<IfModule mod_rewrite.c>',
            'RewriteEngine On',
            'RewriteRule ^\.well-known/oauth-authorization-server/?$ ' . $wk_path . ' [L,QSA]',
            'RewriteRule ^mcp/?$ ' . $mcp_path . ' [L,QSA]',
            'RewriteRule ^oauth/token/?$ ' . $token_path . ' [L,QSA]',
            '</IfModule>',
        );

        if ( function_exists( 'insert_with_markers' ) ) {
            insert_with_markers( $htaccess, $marker, $rules );
        }
    }

    public static function remove_htaccess_rule() {
        if ( ! function_exists( 'get_home_path' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $htaccess = get_home_path() . '.htaccess';
        if ( function_exists( 'insert_with_markers' ) ) {
            insert_with_markers( $htaccess, 'Claude MCP OAuth Token', array() );
        }
    }
}

Claude_WordPress_MCP::get_instance();
