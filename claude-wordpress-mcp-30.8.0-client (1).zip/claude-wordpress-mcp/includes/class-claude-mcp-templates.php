<?php
/**
 * Claude MCP — Templates module
 *
 * Stores reusable Elementor section templates as a custom post type
 * (claude_mcp_template) with a custom taxonomy (mcp_template_category).
 * Ships a starter pack of 5 templates bundled as JSON files under /templates/.
 * Templates are editable from the WordPress admin under Claude MCP → Templates.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_Templates {

    const CPT      = 'claude_mcp_template';
    const TAX      = 'mcp_template_category';
    const META_KEY = '_mcp_template_json';
    const STARTER_INSTALLED_OPTION = 'claude_mcp_starter_installed';

    /* ── Registration ───────────────────────────────────────────── */

    public static function register_post_type() {
        register_post_type( self::CPT, array(
            'labels' => array(
                'name'               => 'MCP Templates',
                'singular_name'      => 'Template',
                'add_new'            => 'Add Template',
                'add_new_item'       => 'Add New Template',
                'edit_item'          => 'Edit Template',
                'new_item'           => 'New Template',
                'view_item'          => 'View Template',
                'search_items'       => 'Search Templates',
                'not_found'          => 'No templates found. Click "Add Template" to create one, or paste an Elementor export.',
                'not_found_in_trash' => 'No templates in trash.',
                'menu_name'          => 'Templates',
            ),
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => 'claude-mcp',       // lives under the top-level Claude MCP menu
            'show_in_admin_bar'   => false,
            'show_in_nav_menus'   => false,
            'show_in_rest'        => false,
            'supports'            => array( 'title', 'editor', 'thumbnail', 'revisions' ),
            'has_archive'         => false,
            'rewrite'             => false,
            'query_var'           => false,
            'capability_type'     => 'post',
            'map_meta_cap'        => true,
        ) );

        register_taxonomy( self::TAX, self::CPT, array(
            'labels' => array(
                'name'          => 'Categories',
                'singular_name' => 'Category',
                'menu_name'     => 'Categories',
                'all_items'     => 'All Categories',
                'edit_item'     => 'Edit Category',
                'add_new_item'  => 'Add Category',
            ),
            'public'            => false,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'show_admin_column' => true,
            'hierarchical'      => false,
            'rewrite'           => false,
            'query_var'         => false,
        ) );
    }

    /* ── Lifecycle ──────────────────────────────────────────────── */

    const PREVIEW_META = '_mcp_preview_for_template';
    const PREVIEW_ID_META = '_mcp_preview_page_id';

    public function init() {
        add_action( 'admin_init',                            array( $this, 'maybe_install_starter_pack' ) );
        add_action( 'admin_init',                            array( $this, 'maybe_backfill_previews' ) );
        add_action( 'add_meta_boxes',                        array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post_' . self::CPT,                array( $this, 'save_meta' ), 10, 2 );
        add_action( 'save_post_' . self::CPT,                array( $this, 'sync_preview_page' ), 20, 2 );
        add_action( 'before_delete_post',                    array( $this, 'delete_preview_page' ) );
        add_filter( 'manage_' . self::CPT . '_posts_columns',       array( $this, 'admin_columns' ) );
        add_action( 'manage_' . self::CPT . '_posts_custom_column', array( $this, 'admin_column_content' ), 10, 2 );
        add_filter( 'post_row_actions',                      array( $this, 'row_actions' ), 10, 2 );
        add_action( 'admin_notices',                         array( $this, 'starter_installed_notice' ) );

        // Hide preview pages from public menus, page lists, and search.
        add_filter( 'wp_list_pages_excludes',                array( $this, 'exclude_preview_pages_from_lists' ) );
        add_filter( 'get_pages',                             array( $this, 'filter_out_preview_pages' ), 10, 2 );
        add_action( 'pre_get_posts',                         array( $this, 'exclude_previews_from_search_and_admin' ) );
    }

    /**
     * Self-healing: if the starter pack was never installed (e.g. plugin was
     * uploaded as an update over an older version, which skips the activation
     * hook), install it on the next admin page load.
     *
     * Uses a transient to only run the check once every 6 hours so we're not
     * hitting the DB on every admin page load forever.
     */
    public function maybe_install_starter_pack() {
        if ( get_option( self::STARTER_INSTALLED_OPTION ) ) return;
        if ( get_transient( 'claude_mcp_starter_check' ) ) return;
        set_transient( 'claude_mcp_starter_check', 1, 6 * HOUR_IN_SECONDS );
        self::install_starter_pack();
    }

    /* ── CRUD (public API used by MCP tools) ────────────────────── */

    /**
     * List templates. Returns lightweight summaries suitable for a tool response.
     *
     * @param string|null $category Slug of a taxonomy term, or null for all.
     * @param int         $limit    Max templates to return (0 = all).
     * @return array
     */
    public static function list_all( $category = null, $limit = 200 ) {
        $args = array(
            'post_type'      => self::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => $limit > 0 ? $limit : -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        );
        if ( $category ) {
            $args['tax_query'] = array( array(
                'taxonomy' => self::TAX,
                'field'    => 'slug',
                'terms'    => sanitize_title( $category ),
            ) );
        }
        $q   = new WP_Query( $args );
        $out = array();
        foreach ( $q->posts as $p ) {
            $terms       = wp_get_post_terms( $p->ID, self::TAX, array( 'fields' => 'slugs' ) );
            $preview_id  = intval( get_post_meta( $p->ID, self::PREVIEW_ID_META, true ) );
            $preview_url = $preview_id ? get_permalink( $preview_id ) : null;
            $out[] = array(
                'slug'          => $p->post_name,
                'id'            => $p->ID,
                'title'         => $p->post_title,
                'description'   => wp_strip_all_tags( $p->post_excerpt ?: wp_trim_words( $p->post_content, 30 ) ),
                'categories'    => is_wp_error( $terms ) ? array() : $terms,
                'thumbnail_url' => get_the_post_thumbnail_url( $p->ID, 'medium' ) ?: null,
                'preview_url'   => $preview_url,
                'has_json'      => (bool) get_post_meta( $p->ID, self::META_KEY, true ),
            );
        }
        return $out;
    }

    /**
     * Load one template's full data by slug or ID.
     * Returns array with slug, title, description, category, and elementor_data (decoded array).
     */
    public static function get_by_slug_or_id( $ref ) {
        $post = null;
        if ( is_numeric( $ref ) ) {
            $post = get_post( intval( $ref ) );
        } else {
            $post = get_page_by_path( sanitize_title( $ref ), OBJECT, self::CPT );
        }
        if ( ! $post || $post->post_type !== self::CPT ) return null;

        $raw     = get_post_meta( $post->ID, self::META_KEY, true );
        $decoded = $raw ? json_decode( $raw, true ) : array();
        if ( ! is_array( $decoded ) ) $decoded = array();

        $terms = wp_get_post_terms( $post->ID, self::TAX, array( 'fields' => 'slugs' ) );

        return array(
            'slug'           => $post->post_name,
            'id'             => $post->ID,
            'title'          => $post->post_title,
            'description'    => $post->post_content,
            'categories'     => is_wp_error( $terms ) ? array() : $terms,
            'thumbnail_url'  => get_the_post_thumbnail_url( $post->ID, 'medium' ) ?: null,
            'elementor_data' => $decoded,
        );
    }

    /**
     * Create a new template from raw Elementor JSON.
     *
     * @return int  New post ID.
     */
    public static function create( $title, $elementor_data, $description = '', $categories = array() ) {
        // Accept either an already-decoded array or a JSON string.
        if ( is_string( $elementor_data ) ) {
            $decoded = json_decode( $elementor_data, true );
            if ( json_last_error() !== JSON_ERROR_NONE ) {
                throw new Exception( 'Template JSON is invalid: ' . json_last_error_msg() );
            }
            $elementor_data = $decoded;
        }
        if ( ! is_array( $elementor_data ) ) {
            throw new Exception( 'Template data must be an array of Elementor sections.' );
        }

        $post_id = wp_insert_post( array(
            'post_type'    => self::CPT,
            'post_status'  => 'publish',
            'post_title'   => sanitize_text_field( $title ),
            'post_content' => wp_kses_post( $description ),
        ), true );

        if ( is_wp_error( $post_id ) ) {
            throw new Exception( 'Failed to create template: ' . $post_id->get_error_message() );
        }

        $json = wp_json_encode( $elementor_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        update_post_meta( $post_id, self::META_KEY, wp_slash( $json ) );

        if ( ! empty( $categories ) ) {
            $terms = is_array( $categories ) ? $categories : array( $categories );
            wp_set_object_terms( $post_id, array_map( 'sanitize_title', $terms ), self::TAX, false );
        }

        // Explicitly sync preview page now that meta is saved — the save_post
        // hook fired during wp_insert_post above, before meta was in place.
        self::do_sync_preview_page( $post_id );

        return $post_id;
    }

    /* ── Starter pack ───────────────────────────────────────────── */

    /**
     * Install bundled starter templates from /templates/*.json.
     * Idempotent — skips if any starter template already exists (matched by slug).
     */
    public static function install_starter_pack( $force = false ) {
        if ( ! $force && get_option( self::STARTER_INSTALLED_OPTION ) ) {
            return array( 'installed' => 0, 'skipped_all' => true );
        }

        $dir = CLAUDE_MCP_PLUGIN_DIR . 'templates';
        if ( ! is_dir( $dir ) ) {
            update_option( self::STARTER_INSTALLED_OPTION, time() );
            return array( 'installed' => 0, 'skipped_all' => true, 'reason' => 'templates directory not found' );
        }

        $installed = 0;
        $skipped   = 0;
        foreach ( glob( $dir . '/*.json' ) as $file ) {
            $slug = sanitize_title( basename( $file, '.json' ) );

            // Skip if a template with this slug already exists.
            if ( get_page_by_path( $slug, OBJECT, self::CPT ) ) {
                $skipped++;
                continue;
            }

            $raw     = file_get_contents( $file );
            $decoded = json_decode( $raw, true );
            if ( ! is_array( $decoded ) ) { $skipped++; continue; }

            $title       = isset( $decoded['title'] )       ? $decoded['title']       : ucwords( str_replace( '-', ' ', $slug ) );
            $description = isset( $decoded['description'] ) ? $decoded['description'] : '';
            $categories  = isset( $decoded['categories'] )  ? (array) $decoded['categories'] : array();
            $data        = isset( $decoded['elementor_data'] ) ? $decoded['elementor_data'] : array();

            $post_id = wp_insert_post( array(
                'post_type'    => self::CPT,
                'post_status'  => 'publish',
                'post_title'   => sanitize_text_field( $title ),
                'post_name'    => $slug,
                'post_content' => wp_kses_post( $description ),
            ), true );

            if ( is_wp_error( $post_id ) ) { $skipped++; continue; }

            $json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
            update_post_meta( $post_id, self::META_KEY, wp_slash( $json ) );

            if ( ! empty( $categories ) ) {
                wp_set_object_terms( $post_id, array_map( 'sanitize_title', $categories ), self::TAX, false );
            }

            // Explicitly sync preview page now that meta and taxonomy are saved.
            self::do_sync_preview_page( $post_id );

            $installed++;
        }

        update_option( self::STARTER_INSTALLED_OPTION, time() );
        return array( 'installed' => $installed, 'skipped' => $skipped );
    }

    /* ── Export / Import ────────────────────────────────────────── */

    /**
     * Return every published template as an array suitable for JSON export.
     * Format matches the bundled starter JSON files so the same data can be
     * either imported through the admin or dropped into /templates/.
     */
    public static function export_all() {
        $ids = get_posts( array(
            'post_type'      => self::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'orderby'        => 'title',
            'order'          => 'ASC',
        ) );

        $templates = array();
        foreach ( $ids as $id ) {
            $post = get_post( $id );
            if ( ! $post ) continue;

            $raw = get_post_meta( $id, self::META_KEY, true );
            $decoded = $raw ? json_decode( $raw, true ) : array();
            if ( ! is_array( $decoded ) ) $decoded = array();

            $terms = wp_get_post_terms( $id, self::TAX, array( 'fields' => 'slugs' ) );

            $templates[] = array(
                'slug'           => $post->post_name,
                'title'          => $post->post_title,
                'description'    => $post->post_content,
                'categories'     => is_wp_error( $terms ) ? array() : $terms,
                'elementor_data' => $decoded,
            );
        }

        return array(
            'format'    => 'claude-mcp-templates/v1',
            'exported_at' => current_time( 'c' ),
            'source_url'  => home_url(),
            'count'       => count( $templates ),
            'templates'   => $templates,
        );
    }

    /**
     * Import templates from a decoded JSON bundle.
     *
     * @param array $data    Decoded bundle (must have "templates" array).
     * @param array $opts    'replace' (bool) — overwrite existing by slug.
     * @return array         Counts: imported, skipped, replaced, failed.
     */
    public static function import_bundle( $data, $opts = array() ) {
        $replace = ! empty( $opts['replace'] );
        $result  = array( 'imported' => 0, 'skipped' => 0, 'replaced' => 0, 'failed' => 0, 'errors' => array() );

        if ( ! is_array( $data ) || empty( $data['templates'] ) || ! is_array( $data['templates'] ) ) {
            $result['errors'][] = 'Bundle is not valid — missing "templates" array.';
            return $result;
        }

        foreach ( $data['templates'] as $tpl ) {
            if ( ! is_array( $tpl ) ) { $result['failed']++; continue; }

            $slug  = isset( $tpl['slug'] )  ? sanitize_title( $tpl['slug'] )  : '';
            $title = isset( $tpl['title'] ) ? sanitize_text_field( $tpl['title'] ) : '';
            if ( ! $title ) { $result['failed']++; $result['errors'][] = 'Template missing title.'; continue; }

            $description = isset( $tpl['description'] )    ? wp_kses_post( $tpl['description'] ) : '';
            $categories  = isset( $tpl['categories'] )     ? (array) $tpl['categories']          : array();
            $data_arr    = isset( $tpl['elementor_data'] ) ? $tpl['elementor_data']              : array();

            // Check for existing by slug.
            $existing = $slug ? get_page_by_path( $slug, OBJECT, self::CPT ) : null;

            if ( $existing && ! $replace ) {
                $result['skipped']++;
                continue;
            }

            if ( $existing && $replace ) {
                // Update existing.
                wp_update_post( array(
                    'ID'           => $existing->ID,
                    'post_title'   => $title,
                    'post_content' => $description,
                ) );
                $json = wp_json_encode( $data_arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
                update_post_meta( $existing->ID, self::META_KEY, wp_slash( $json ) );
                if ( ! empty( $categories ) ) {
                    wp_set_object_terms( $existing->ID, array_map( 'sanitize_title', $categories ), self::TAX, false );
                }
                self::do_sync_preview_page( $existing->ID );
                $result['replaced']++;
                continue;
            }

            // Create new.
            try {
                $post_id = self::create( $title, $data_arr, $description, $categories );
                if ( $slug ) {
                    wp_update_post( array( 'ID' => $post_id, 'post_name' => $slug ) );
                }
                $result['imported']++;
            } catch ( Exception $e ) {
                $result['failed']++;
                $result['errors'][] = $title . ': ' . $e->getMessage();
            }
        }

        return $result;
    }

    /**
     * Force-rebuild preview pages for every published template.
     * Called from the admin "Rebuild All Previews" button.
     *
     * @return array Count of previews rebuilt.
     */
    public static function rebuild_all_previews() {
        $ids = get_posts( array(
            'post_type'      => self::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ) );
        $rebuilt = 0;
        foreach ( $ids as $id ) {
            $preview_id = self::do_sync_preview_page( $id );
            if ( $preview_id ) $rebuilt++;
        }
        // Reset backfill transient so subsequent admin loads don't skip.
        delete_transient( 'claude_mcp_previews_backfilled_v1' );
        return array( 'rebuilt' => $rebuilt, 'total' => count( $ids ) );
    }

    public function starter_installed_notice() {
        if ( ! isset( $_GET['claude_mcp_starter'] ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;
        $count = intval( $_GET['claude_mcp_starter'] );
        echo '<div class="notice notice-success is-dismissible"><p><strong>Claude MCP:</strong> Installed ' . $count . ' starter template(s).</p></div>';
    }

    /* ── Admin UI: edit screen meta boxes ───────────────────────── */

    public function add_meta_boxes() {
        add_meta_box(
            'claude_mcp_template_json',
            'Elementor Template JSON',
            array( $this, 'render_json_meta_box' ),
            self::CPT,
            'normal',
            'high'
        );
        add_meta_box(
            'claude_mcp_template_help',
            'How this works',
            array( $this, 'render_help_meta_box' ),
            self::CPT,
            'side',
            'default'
        );
    }

    public function render_json_meta_box( $post ) {
        wp_nonce_field( 'claude_mcp_save_template', 'claude_mcp_template_nonce' );
        $json = get_post_meta( $post->ID, self::META_KEY, true );

        // Pretty-print for editing if it's stored compactly.
        $pretty = $json;
        if ( $json ) {
            $decoded = json_decode( $json, true );
            if ( is_array( $decoded ) ) {
                $pretty = wp_json_encode( $decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
            }
        }

        $size_kb = $json ? round( strlen( $json ) / 1024, 1 ) : 0;
        ?>
        <p style="margin-top:0;">
            <strong>Paste the Elementor section JSON below.</strong>
            In Elementor, right-click a section → <em>Copy</em>, then paste here.
            You can also paste an array of multiple sections.
        </p>
        <textarea
            name="claude_mcp_template_json"
            id="claude_mcp_template_json"
            rows="20"
            style="width:100%;font-family:Menlo,Monaco,Consolas,monospace;font-size:12px;line-height:1.5;"
            spellcheck="false"
        ><?php echo esc_textarea( $pretty ); ?></textarea>
        <p class="description">
            Current size: <?php echo esc_html( $size_kb ); ?> KB.
            Templates over 25 KB may hit the MCP response limit — split large layouts into multiple section templates.
        </p>
        <?php
    }

    public function render_help_meta_box( $post ) {
        $slug        = $post->post_name ?: '(saved on publish)';
        $preview_id  = intval( get_post_meta( $post->ID, self::PREVIEW_ID_META, true ) );
        $preview_url = $preview_id ? get_permalink( $preview_id ) : '';
        ?>
        <p><strong>Template slug:</strong><br><code><?php echo esc_html( $slug ); ?></code></p>
        <p>Claude will reference this template by its slug when calling <code>apply_template</code>.</p>

        <?php if ( $preview_url ) : ?>
            <p><strong>Live preview:</strong><br>
            <a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" class="button button-primary" style="margin-top:6px;">Open preview ↗</a></p>
            <p class="description">Preview auto-updates when you save this template. To use it as the thumbnail, take a screenshot and set it as the Featured Image (panel below).</p>
        <?php else : ?>
            <p><em>The live preview page is created when this template is first published.</em></p>
        <?php endif; ?>

        <p><strong>Tips</strong></p>
        <ul style="margin-left:1em;list-style:disc;">
            <li>Use the <em>Description</em> field to explain what this template is for — Claude reads it when picking a template.</li>
            <li>Set a <em>Featured Image</em> screenshot for easy visual browsing in the list.</li>
            <li>Assign a <em>Category</em> (hero, features, cta, footer, etc.) so filtering works.</li>
            <li>Section-scale templates (one section) work better than full-page templates — Claude assembles pages from several.</li>
        </ul>
        <?php
    }

    public function save_meta( $post_id, $post ) {
        if ( ! isset( $_POST['claude_mcp_template_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['claude_mcp_template_nonce'], 'claude_mcp_save_template' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        $raw = isset( $_POST['claude_mcp_template_json'] ) ? wp_unslash( $_POST['claude_mcp_template_json'] ) : '';
        $raw = trim( $raw );

        if ( $raw === '' ) {
            delete_post_meta( $post_id, self::META_KEY );
            return;
        }

        // Validate JSON. If invalid, keep the raw text so the user can fix it, but flag it.
        $decoded = json_decode( $raw, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            update_post_meta( $post_id, self::META_KEY, wp_slash( $raw ) );
            set_transient( 'claude_mcp_template_error_' . $post_id, 'JSON parse error: ' . json_last_error_msg(), 30 );
            return;
        }

        // Re-encode compact to save space.
        $compact = wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        update_post_meta( $post_id, self::META_KEY, wp_slash( $compact ) );
    }

    /* ── Admin UI: list-table columns ───────────────────────────── */

    public function admin_columns( $cols ) {
        $new = array();
        foreach ( $cols as $k => $v ) {
            $new[ $k ] = $v;
            if ( $k === 'title' ) {
                $new['mcp_thumb']    = 'Preview';
                $new['mcp_size']     = 'JSON size';
            }
        }
        return $new;
    }

    public function admin_column_content( $col, $post_id ) {
        if ( $col === 'mcp_thumb' ) {
            $thumb       = get_the_post_thumbnail( $post_id, array( 60, 60 ) );
            $preview_id  = intval( get_post_meta( $post_id, self::PREVIEW_ID_META, true ) );
            $preview_url = $preview_id ? get_permalink( $preview_id ) : '';
            if ( $thumb ) {
                echo $thumb;
            } else {
                echo '<span style="color:#999;">—</span>';
            }
            if ( $preview_url ) {
                echo '<br><a href="' . esc_url( $preview_url ) . '" target="_blank" style="font-size:12px;">View live ↗</a>';
            }
        }
        if ( $col === 'mcp_size' ) {
            $raw = get_post_meta( $post_id, self::META_KEY, true );
            if ( ! $raw ) {
                echo '<span style="color:#c00;">no JSON</span>';
            } else {
                $kb = round( strlen( $raw ) / 1024, 1 );
                echo esc_html( $kb ) . ' KB';
            }
        }
    }

    /**
     * Add a "Preview" row action under each template's title so it matches the
     * standard WordPress admin UX (Edit | Quick Edit | Trash | Preview).
     */
    public function row_actions( $actions, $post ) {
        if ( $post->post_type !== self::CPT ) return $actions;
        $preview_id = intval( get_post_meta( $post->ID, self::PREVIEW_ID_META, true ) );
        if ( ! $preview_id ) return $actions;
        $url = get_permalink( $preview_id );
        if ( ! $url ) return $actions;
        // Insert Preview right after Edit if possible.
        $new = array();
        foreach ( $actions as $k => $v ) {
            $new[ $k ] = $v;
            if ( $k === 'edit' ) {
                $new['mcp_preview'] = '<a href="' . esc_url( $url ) . '" target="_blank">Preview ↗</a>';
            }
        }
        if ( ! isset( $new['mcp_preview'] ) ) {
            $new['mcp_preview'] = '<a href="' . esc_url( $url ) . '" target="_blank">Preview ↗</a>';
        }
        return $new;
    }

    /* ── Preview page lifecycle ─────────────────────────────────── */

    /**
     * Create or update the companion preview page for a template. Fires on
     * every template publish/update. The preview page is a real WordPress page
     * (post_type=page) with elementor_canvas template and the template's
     * Elementor JSON as its content — so it renders exactly as the template
     * will look when applied.
     *
     * Filters below hide these pages from menus, wp_list_pages, search, and
     * the Pages admin screen so they don't clutter the site.
     */
    public function sync_preview_page( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) ) return;
        if ( $post->post_status !== 'publish' ) return;
        self::do_sync_preview_page( $post_id, $post );
    }

    /**
     * Static version so the starter installer and backfill routine can call it
     * without needing an instance.
     */
    public static function do_sync_preview_page( $post_id, $post = null ) {
        if ( ! $post ) $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== self::CPT ) return 0;

        $raw = get_post_meta( $post_id, self::META_KEY, true );
        if ( ! $raw ) return 0;
        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) || empty( $data ) ) return 0;

        // Find existing preview page for this template.
        $preview_id = intval( get_post_meta( $post_id, self::PREVIEW_ID_META, true ) );
        if ( $preview_id && ! get_post( $preview_id ) ) {
            $preview_id = 0;
            delete_post_meta( $post_id, self::PREVIEW_ID_META );
        }

        $preview_title = '[MCP Preview] ' . $post->post_title;
        $preview_slug  = 'mcp-preview-' . $post->post_name;

        if ( ! $preview_id ) {
            $preview_id = wp_insert_post( array(
                'post_type'      => 'page',
                'post_status'    => 'publish',
                'post_title'     => $preview_title,
                'post_name'      => $preview_slug,
                'post_content'   => '',
                'comment_status' => 'closed',
                'ping_status'    => 'closed',
            ), true );
            if ( is_wp_error( $preview_id ) || ! $preview_id ) return 0;

            update_post_meta( $preview_id, self::PREVIEW_META, $post_id );
            update_post_meta( $post_id,    self::PREVIEW_ID_META, $preview_id );
        } else {
            // Keep the preview title in sync if the template was renamed.
            wp_update_post( array(
                'ID'         => $preview_id,
                'post_title' => $preview_title,
            ) );
        }

        // Write the Elementor payload to the preview page.
        $json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        update_post_meta( $preview_id, '_elementor_data',          wp_slash( $json ) );
        update_post_meta( $preview_id, '_elementor_edit_mode',     'builder' );
        update_post_meta( $preview_id, '_elementor_version',       defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0' );
        update_post_meta( $preview_id, '_elementor_template_type', 'wp-page' );
        update_post_meta( $preview_id, '_wp_page_template',        'elementor_canvas' );

        // Regenerate the Elementor CSS file for the preview so styles show up.
        if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
            try {
                $css_file = \Elementor\Core\Files\CSS\Post::create( $preview_id );
                $css_file->update();
            } catch ( Exception $e ) { /* non-fatal */ }
        }

        clean_post_cache( $preview_id );
        return $preview_id;
    }

    /**
     * Delete the companion preview page when the template is deleted.
     */
    public function delete_preview_page( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== self::CPT ) return;
        $preview_id = intval( get_post_meta( $post_id, self::PREVIEW_ID_META, true ) );
        if ( $preview_id && get_post( $preview_id ) ) {
            wp_delete_post( $preview_id, true );
        }
    }

    /**
     * Backfill: after an update from an older version, existing templates won't
     * have preview pages yet. Run once (transient-guarded) on admin_init.
     */
    public function maybe_backfill_previews() {
        if ( get_transient( 'claude_mcp_previews_backfilled_v1' ) ) return;
        set_transient( 'claude_mcp_previews_backfilled_v1', 1, DAY_IN_SECONDS );

        $ids = get_posts( array(
            'post_type'      => self::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ) );
        foreach ( $ids as $id ) {
            $has = intval( get_post_meta( $id, self::PREVIEW_ID_META, true ) );
            if ( $has && get_post( $has ) ) continue;
            self::do_sync_preview_page( $id );
        }
    }

    /* ── Hide preview pages from site listings ──────────────────── */

    public function exclude_preview_pages_from_lists( $excludes ) {
        $ids = self::get_all_preview_page_ids();
        return array_merge( (array) $excludes, $ids );
    }

    public function filter_out_preview_pages( $pages, $args ) {
        if ( empty( $pages ) ) return $pages;
        return array_values( array_filter( $pages, function( $p ) {
            return ! get_post_meta( $p->ID, self::PREVIEW_META, true );
        } ) );
    }

    public function exclude_previews_from_search_and_admin( $query ) {
        // Public search: never surface previews.
        if ( ! is_admin() && $query->is_search() ) {
            $excl = (array) $query->get( 'post__not_in' );
            $query->set( 'post__not_in', array_merge( $excl, self::get_all_preview_page_ids() ) );
            return;
        }
        // Admin Pages screen: hide previews from the main pages list.
        if ( is_admin() && $query->is_main_query() ) {
            $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
            if ( $screen && $screen->id === 'edit-page' ) {
                $meta_query = (array) $query->get( 'meta_query' );
                $meta_query[] = array(
                    'key'     => self::PREVIEW_META,
                    'compare' => 'NOT EXISTS',
                );
                $query->set( 'meta_query', $meta_query );
            }
        }
    }

    private static function get_all_preview_page_ids() {
        static $cache = null;
        if ( is_array( $cache ) ) return $cache;
        $cache = get_posts( array(
            'post_type'      => 'page',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_key'       => self::PREVIEW_META,
        ) );
        return $cache;
    }
}
