<?php
/**
 * OAuth 2.0 - v8
 * Fixes: plaintext token storage → SHA-256 hashed, expired token/code cleanup cron,
 * api_key query-string auth removed (header-only).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_OAuth {

    const AUTH_CODES_OPTION = 'claude_mcp_auth_codes';
    const TOKENS_OPTION     = 'claude_mcp_tokens';
    const DEBUG_OPTION      = 'claude_mcp_debug_log';

    /* ── Rewrite rules ──────────────────────────────────────────── */

    public static function add_rewrite_rules() {
        add_rewrite_rule( '^authorize/?$',                               'index.php?claude_mcp_authorize=1',  'top' );
        add_rewrite_rule( '^oauth/token/?$',                             'index.php?claude_mcp_token=1',      'top' );
        add_rewrite_rule( '^\\.well-known/oauth-authorization-server/?$','index.php?claude_mcp_wellknown=1',  'top' );
    }

    public static function add_query_vars( $vars ) {
        $vars[] = 'claude_mcp_authorize';
        $vars[] = 'claude_mcp_token';
        $vars[] = 'claude_mcp_wellknown';
        return $vars;
    }

    /* ── Cleanup (runs daily via cron) ──────────────────────────── */

    /**
     * Purge expired access tokens and auth codes from wp_options.
     * Called by the claude_mcp_daily_cleanup cron action.
     */
    public static function cleanup_expired() {
        $now = time();

        // Clean auth codes
        $codes = get_option( self::AUTH_CODES_OPTION, array() );
        $clean = array();
        foreach ( $codes as $code => $data ) {
            if ( isset( $data['expires'] ) && $data['expires'] > $now ) {
                $clean[ $code ] = $data;
            }
        }
        update_option( self::AUTH_CODES_OPTION, $clean );

        // v30.5.1+: tokens live in the custom table; delegate cleanup there.
        if ( class_exists( 'Claude_MCP_Token_Store' ) ) {
            Claude_MCP_Token_Store::cleanup_expired();
        }

        // Also prune the activity log on the same daily cron.
        if ( class_exists( 'Claude_MCP_Activity' ) ) {
            Claude_MCP_Activity::prune();
        }

        error_log( 'Claude MCP: daily cleanup done.' );
    }

    /* ── REST routes ────────────────────────────────────────────── */

    public function register_rest_routes() {
        register_rest_route( 'claude-mcp/v1', '/oauth/discovery', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'rest_discovery' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function rest_discovery() {
        $site = get_bloginfo( 'url' );
        return new WP_REST_Response( array(
            'issuer'                                => $site,
            'authorization_endpoint'                => $site . '/authorize',
            'token_endpoint'                        => $site . '/oauth/token',
            'response_types_supported'              => array( 'code' ),
            'grant_types_supported'                 => array( 'authorization_code' ),
            'code_challenge_methods_supported'      => array( 'S256' ),
            'token_endpoint_auth_methods_supported' => array( 'none' ),
        ), 200 );
    }

    /* ── /authorize handler ─────────────────────────────────────── */

    public function handle_authorize() {
        $method                = $_SERVER['REQUEST_METHOD'];
        $client_id             = sanitize_text_field( $_REQUEST['client_id']             ?? '' );
        $redirect_uri          = esc_url_raw(          $_REQUEST['redirect_uri']          ?? '' );
        $state                 = sanitize_text_field( $_REQUEST['state']                  ?? '' );
        $code_challenge        = sanitize_text_field( $_REQUEST['code_challenge']        ?? '' );
        $code_challenge_method = sanitize_text_field( $_REQUEST['code_challenge_method'] ?? '' );

        // v30.5.0+: PKCE is mandatory and must use S256. A missing challenge or
        // the "plain" method is now a hard error. Older clients that relied on
        // optional PKCE must upgrade.
        if ( empty( $code_challenge ) ) {
            wp_die(
                esc_html__( 'PKCE required: this server only accepts OAuth requests with code_challenge.', 'claude-mcp' ),
                esc_html__( 'OAuth error', 'claude-mcp' ),
                array( 'response' => 400 )
            );
        }
        if ( $code_challenge_method !== 'S256' ) {
            wp_die(
                esc_html__( 'Unsupported code_challenge_method. This server requires S256; plain is not accepted.', 'claude-mcp' ),
                esc_html__( 'OAuth error', 'claude-mcp' ),
                array( 'response' => 400 )
            );
        }

        if ( $method === 'POST' ) {
            if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'claude_mcp_oauth_authorize' ) ) {
                wp_die( 'Security check failed.' );
            }

            if ( ( $_POST['claude_action'] ?? '' ) === 'allow' ) {
                $code  = wp_generate_password( 32, false );
                $codes = get_option( self::AUTH_CODES_OPTION, array() );
                $codes[ $code ] = array(
                    'client_id'             => $client_id,
                    'redirect_uri'          => $redirect_uri,
                    'code_challenge'        => $code_challenge,
                    'code_challenge_method' => $code_challenge_method,
                    'expires'               => time() + 600,
                );
                update_option( self::AUTH_CODES_OPTION, $codes );
                $this->log( 'Auth code issued: ' . substr( $code, 0, 8 ) . ' redirect=' . $redirect_uri );
                wp_redirect( add_query_arg( array( 'code' => $code, 'state' => $state ), $redirect_uri ) );
                exit;
            }

            wp_redirect( add_query_arg( array( 'error' => 'access_denied', 'state' => $state ), $redirect_uri ) );
            exit;
        }

        if ( ! is_user_logged_in() ) {
            $return = get_bloginfo( 'url' ) . '/authorize?' . http_build_query( array_filter( array(
                'response_type'         => 'code',
                'client_id'             => $client_id,
                'redirect_uri'          => $redirect_uri,
                'state'                 => $state,
                'code_challenge'        => $code_challenge,
                'code_challenge_method' => $code_challenge_method,
            ) ) );
            wp_redirect( wp_login_url( $return ) );
            exit;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Administrator access required.' );
        }

        $this->render_authorize_page( $client_id, $redirect_uri, $state, $code_challenge, $code_challenge_method );
    }

    /* ── /oauth/token handler ────────────────────────────────────── */

    public function handle_token_direct() {
        header( 'Content-Type: application/json' );
        $cmcp_cors_origin = function_exists( 'claude_mcp_cors_allowed_origin' ) ? claude_mcp_cors_allowed_origin() : '';
        if ( $cmcp_cors_origin ) header( 'Access-Control-Allow-Origin: ' . $cmcp_cors_origin );
        header( 'Vary: Origin' );
        header( 'Access-Control-Allow-Methods: POST, GET, OPTIONS' );
        header( 'Access-Control-Allow-Headers: Content-Type, Authorization' );
        header( 'Cache-Control: no-store' );

        if ( $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {
            http_response_code( 204 );
            exit;
        }

        $params = array();

        if ( ! empty( $_POST ) ) {
            $params = $_POST;
        }

        if ( empty( $params['grant_type'] ) ) {
            $raw  = file_get_contents( 'php://input' );
            $json = json_decode( $raw, true );
            if ( is_array( $json ) ) $params = $json;
        }

        if ( empty( $params['grant_type'] ) ) {
            $raw = file_get_contents( 'php://input' );
            parse_str( $raw, $form );
            if ( ! empty( $form['grant_type'] ) ) $params = $form;
        }

        if ( empty( $params['grant_type'] ) ) {
            $params = array_merge( $_GET, $params );
        }

        $grant_type    = sanitize_text_field( $params['grant_type']    ?? '' );
        $code          = sanitize_text_field( $params['code']           ?? '' );
        $redirect_uri  = esc_url_raw(         $params['redirect_uri']  ?? '' );
        $code_verifier = sanitize_text_field( $params['code_verifier'] ?? '' );
        $content_type  = $_SERVER['CONTENT_TYPE'] ?? '';

        $this->log( "Token request: grant={$grant_type} code=" . substr( $code, 0, 8 ) . " ct={$content_type}" );

        if ( $grant_type !== 'authorization_code' ) {
            $this->json_error( 'unsupported_grant_type', 'Only authorization_code supported. Got: ' . $grant_type );
        }

        if ( empty( $code ) ) {
            $this->log( 'Token error: no code. Raw input: ' . substr( file_get_contents( 'php://input' ), 0, 500 ) );
            $this->json_error( 'invalid_request', 'Missing code.' );
        }

        $codes = get_option( self::AUTH_CODES_OPTION, array() );

        if ( ! isset( $codes[ $code ] ) ) {
            $this->log( 'Token error: code not found. Count=' . count( $codes ) );
            $this->json_error( 'invalid_grant', 'Invalid or expired authorization code.' );
        }

        $data = $codes[ $code ];

        if ( time() > $data['expires'] ) {
            unset( $codes[ $code ] );
            update_option( self::AUTH_CODES_OPTION, $codes );
            $this->json_error( 'invalid_grant', 'Code expired.' );
        }

        // v30.5.0+: PKCE verification is mandatory. The authorize step rejects
        // any flow without a challenge, so every stored code now carries one.
        if ( empty( $data['code_challenge'] ) ) {
            $this->log( 'Token error: stored code missing PKCE challenge (pre-30.5 code?).' );
            $this->json_error( 'invalid_grant', 'PKCE challenge missing from stored authorization code.' );
        }
        if ( empty( $code_verifier ) ) {
            $this->log( 'Token error: client sent no code_verifier.' );
            $this->json_error( 'invalid_grant', 'code_verifier is required.' );
        }
        if ( ! $this->verify_pkce( $code_verifier, $data['code_challenge'], $data['code_challenge_method'] ) ) {
            $this->log( 'Token error: PKCE failed.' );
            $this->json_error( 'invalid_grant', 'PKCE verification failed.' );
        }

        unset( $codes[ $code ] );
        update_option( self::AUTH_CODES_OPTION, $codes );

        // v30.5.1+: issue the raw token, store only the SHA-256 hash in the
        // dedicated token table (not wp_options). The raw token leaves the
        // server exactly once in the response below.
        $raw_token = wp_generate_password( 64, false );
        Claude_MCP_Token_Store::issue( $raw_token, $data['client_id'], 365 * DAY_IN_SECONDS );

        $this->log( 'Token issued! client=' . $data['client_id'] );

        echo json_encode( array(
            'access_token' => $raw_token,       // send raw to client, never stored
            'token_type'   => 'bearer',
            'expires_in'   => 365 * DAY_IN_SECONDS,
            'scope'        => 'wordpress',
        ) );
        exit;
    }

    /* ── Token validation ────────────────────────────────────────── */

    /**
     * Validates a raw Bearer token by hashing it and looking up the hash.
     * Also accepts the static API key directly (already compared with hash_equals upstream).
     */
    public function validate_token( $raw_token ) {
        if ( empty( $raw_token ) ) return false;

        // v30.5.1+: tokens live in the custom table.
        if ( class_exists( 'Claude_MCP_Token_Store' ) && Claude_MCP_Token_Store::validate( $raw_token ) ) {
            return true;
        }

        // Fallback: pre-migration wp_options store. Covers the single request
        // window on upgrade where init() has not yet run the migration.
        $token_hash = hash( 'sha256', $raw_token );
        $tokens     = get_option( self::TOKENS_OPTION, array() );
        if ( isset( $tokens[ $token_hash ] ) && time() <= $tokens[ $token_hash ]['expires'] ) {
            return true;
        }

        return false;
    }

    /* ── Helpers ─────────────────────────────────────────────────── */

    private function verify_pkce( $verifier, $challenge, $method ) {
        if ( $method === 'S256' ) {
            $computed = rtrim( strtr( base64_encode( hash( 'sha256', $verifier, true ) ), '+/', '-_' ), '=' );
            return hash_equals( $challenge, $computed );
        }
        return hash_equals( $challenge, $verifier );
    }

    private function json_error( $error, $description ) {
        $this->log( "OAuth error: {$error} — {$description}" );
        http_response_code( 400 );
        echo json_encode( array( 'error' => $error, 'error_description' => $description ) );
        exit;
    }

    public function log( $msg ) {
        $log   = get_option( self::DEBUG_OPTION, array() );
        $log[] = array( 'time' => date( 'H:i:s' ), 'msg' => $msg );
        if ( count( $log ) > 50 ) $log = array_slice( $log, -50 );
        update_option( self::DEBUG_OPTION, $log );
        error_log( 'Claude MCP: ' . $msg );
    }

    /* ── Authorization page HTML ─────────────────────────────────── */

    private function render_authorize_page( $client_id, $redirect_uri, $state, $code_challenge, $code_challenge_method ) {
        $site_name  = get_bloginfo( 'name' );
        $action_url = get_bloginfo( 'url' ) . '/authorize';
        ?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Authorize Claude – <?php echo esc_html( $site_name ); ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f0f2f5;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
.card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.12);padding:40px;max-width:440px;width:100%}
.logo{text-align:center;margin-bottom:20px;font-size:48px}
h1{font-size:22px;text-align:center;margin-bottom:8px;color:#1a1a2e}
.sub{text-align:center;color:#666;margin-bottom:24px;font-size:15px}
.site{background:#f6f8fa;border:1px solid #e0e0e0;border-radius:8px;padding:12px 16px;margin-bottom:20px}
.site strong{display:block;color:#333;font-size:16px}
.site span{font-size:13px;color:#888}
.perms{background:#f0fff4;border:1px solid #b7f0c8;border-radius:8px;padding:16px;margin-bottom:24px}
.perms h3{font-size:12px;color:#2d6a4f;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px}
.perms ul{padding-left:18px}
.perms li{font-size:14px;color:#444;margin-bottom:5px}
.btns{display:flex;gap:12px}
.btn{flex:1;padding:13px;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer}
.allow{background:#2563eb;color:#fff}
.deny{background:#f1f5f9;color:#555}
.note{font-size:12px;color:#999;text-align:center;margin-top:14px}
</style>
</head>
<body>
<div class="card">
  <div class="logo">🤖</div>
  <h1>Authorize Claude AI</h1>
  <p class="sub">Claude is requesting access to your WordPress site</p>
  <div class="site">
    <strong><?php echo esc_html( $site_name ); ?></strong>
    <span><?php echo esc_html( get_bloginfo( 'url' ) ); ?></span>
  </div>
  <div class="perms">
    <h3>Claude will be able to:</h3>
    <ul>
      <li>✅ Read and create posts &amp; pages</li>
      <li>✅ Manage media library</li>
      <li>✅ Manage categories &amp; tags</li>
      <li>✅ Moderate comments</li>
      <li>✅ Read site info &amp; plugins</li>
      <li>✅ Read &amp; write Elementor page data</li>
    </ul>
  </div>
  <form method="post" action="<?php echo esc_url( $action_url ); ?>">
    <?php wp_nonce_field( 'claude_mcp_oauth_authorize' ); ?>
    <input type="hidden" name="client_id"             value="<?php echo esc_attr( $client_id ); ?>">
    <input type="hidden" name="redirect_uri"          value="<?php echo esc_attr( $redirect_uri ); ?>">
    <input type="hidden" name="state"                 value="<?php echo esc_attr( $state ); ?>">
    <input type="hidden" name="code_challenge"        value="<?php echo esc_attr( $code_challenge ); ?>">
    <input type="hidden" name="code_challenge_method" value="<?php echo esc_attr( $code_challenge_method ); ?>">
    <div class="btns">
      <button type="submit" name="claude_action" value="deny"  class="btn deny">Deny</button>
      <button type="submit" name="claude_action" value="allow" class="btn allow">✅ Allow Access</button>
    </div>
  </form>
  <p class="note">Logged in as: <?php echo esc_html( wp_get_current_user()->user_login ); ?></p>
</div>
</body>
</html><?php
    }
}
