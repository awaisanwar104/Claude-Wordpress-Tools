<?php
/**
 * Claude_MCP_Token_Store
 *
 * Moves OAuth bearer tokens out of wp_options (where any plugin with
 * get_option() could read them) into a dedicated table protected by
 * capability checks on reads from the admin layer.
 *
 * Table: {$wpdb->prefix}claude_mcp_tokens
 *   id          BIGINT UNSIGNED, PK, auto-increment
 *   token_hash  CHAR(64), UNIQUE  (SHA-256 of the raw token)
 *   client_id   VARCHAR(128)
 *   created_at  DATETIME
 *   expires_at  DATETIME
 *   last_used   DATETIME NULL
 *   revoked     TINYINT(1) DEFAULT 0
 *
 * Migration is backward-compatible: the first time this loads with existing
 * wp_options tokens, they are copied into the table and the option is cleared.
 * Validate_token checks the table first; the option is no longer written to.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_Token_Store {

    const SCHEMA_VERSION_OPTION = 'claude_mcp_tokens_schema_v';
    const SCHEMA_VERSION        = 1;
    const MIGRATION_OPTION      = 'claude_mcp_tokens_migrated_v1';

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . 'claude_mcp_tokens';
    }

    public static function install_schema() {
        global $wpdb;
        if ( (int) get_option( self::SCHEMA_VERSION_OPTION ) >= self::SCHEMA_VERSION ) return;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table   = self::table_name();
        $charset = $wpdb->get_charset_collate();
        $sql     = "CREATE TABLE $table (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            token_hash CHAR(64) NOT NULL,
            client_id  VARCHAR(128) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            last_used  DATETIME NULL DEFAULT NULL,
            revoked    TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            KEY expires_at (expires_at)
        ) $charset;";
        dbDelta( $sql );
        update_option( self::SCHEMA_VERSION_OPTION, self::SCHEMA_VERSION );
    }

    /**
     * One-shot migration from wp_options['claude_mcp_tokens'] into the table.
     * Clears the option on success so future reads only touch the table.
     */
    public static function migrate_from_options() {
        if ( get_option( self::MIGRATION_OPTION ) ) return 0;

        $legacy = get_option( 'claude_mcp_tokens', array() );
        if ( ! is_array( $legacy ) || empty( $legacy ) ) {
            update_option( self::MIGRATION_OPTION, time() );
            return 0;
        }

        global $wpdb;
        $table    = self::table_name();
        $migrated = 0;
        foreach ( $legacy as $hash => $data ) {
            if ( ! is_string( $hash ) || strlen( $hash ) !== 64 ) continue;
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE token_hash = %s", $hash ) );
            if ( $exists ) continue;

            $wpdb->insert( $table, array(
                'token_hash' => $hash,
                'client_id'  => isset( $data['client_id'] ) ? substr( (string) $data['client_id'], 0, 128 ) : '',
                'created_at' => isset( $data['created'] ) ? gmdate( 'Y-m-d H:i:s', (int) $data['created'] ) : current_time( 'mysql', true ),
                'expires_at' => isset( $data['expires'] ) ? gmdate( 'Y-m-d H:i:s', (int) $data['expires'] ) : gmdate( 'Y-m-d H:i:s', time() + 365 * DAY_IN_SECONDS ),
                'last_used'  => null,
                'revoked'    => 0,
            ) );
            $migrated++;
        }

        // Clear the legacy option — tokens now live only in the table.
        update_option( 'claude_mcp_tokens', array() );
        update_option( self::MIGRATION_OPTION, time() );
        return $migrated;
    }

    public static function issue( $raw_token, $client_id, $ttl_seconds = null ) {
        global $wpdb;
        $ttl = $ttl_seconds ? (int) $ttl_seconds : 365 * DAY_IN_SECONDS;
        $wpdb->insert( self::table_name(), array(
            'token_hash' => hash( 'sha256', $raw_token ),
            'client_id'  => substr( (string) $client_id, 0, 128 ),
            'created_at' => current_time( 'mysql', true ),
            'expires_at' => gmdate( 'Y-m-d H:i:s', time() + $ttl ),
            'revoked'    => 0,
        ) );
        return (int) $wpdb->insert_id;
    }

    /**
     * Verify a raw token. Returns true if present, not expired, not revoked.
     * Also bumps last_used.
     */
    public static function validate( $raw_token ) {
        if ( ! $raw_token || ! is_string( $raw_token ) ) return false;
        global $wpdb;
        $hash  = hash( 'sha256', $raw_token );
        $table = self::table_name();
        $row   = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, expires_at, revoked FROM $table WHERE token_hash = %s LIMIT 1",
            $hash
        ) );
        if ( ! $row ) return false;
        if ( (int) $row->revoked === 1 ) return false;
        if ( strtotime( $row->expires_at ) < time() ) return false;

        // Bump last_used — best-effort, don't fail validation if the write fails.
        $wpdb->update( $table, array( 'last_used' => current_time( 'mysql', true ) ), array( 'id' => (int) $row->id ) );
        return true;
    }

    public static function all( $include_revoked = false ) {
        global $wpdb;
        $table = self::table_name();
        $sql   = $include_revoked ? "SELECT * FROM $table ORDER BY id DESC" : "SELECT * FROM $table WHERE revoked = 0 ORDER BY id DESC";
        return $wpdb->get_results( $sql, ARRAY_A ) ?: array();
    }

    public static function count_active() {
        global $wpdb;
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . self::table_name() . " WHERE revoked = 0 AND expires_at > UTC_TIMESTAMP()" );
    }

    public static function revoke_by_hash( $hash ) {
        global $wpdb;
        return (bool) $wpdb->update( self::table_name(), array( 'revoked' => 1 ), array( 'token_hash' => $hash ) );
    }

    public static function revoke_by_id( $id ) {
        global $wpdb;
        return (bool) $wpdb->update( self::table_name(), array( 'revoked' => 1 ), array( 'id' => (int) $id ) );
    }

    public static function revoke_all() {
        global $wpdb;
        return (int) $wpdb->query( "UPDATE " . self::table_name() . " SET revoked = 1 WHERE revoked = 0" );
    }

    public static function cleanup_expired() {
        global $wpdb;
        $wpdb->query( "DELETE FROM " . self::table_name() . " WHERE expires_at < UTC_TIMESTAMP() AND created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY)" );
    }
}
