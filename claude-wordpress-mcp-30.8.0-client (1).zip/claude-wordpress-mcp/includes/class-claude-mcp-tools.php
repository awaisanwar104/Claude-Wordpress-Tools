<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_Tools {

    /* ── Tool manifest ──────────────────────────────────────────── */

    public function get_tools() {
        return array(
            // ── Core ──
            array( 'name' => 'context_summary', 'description' => 'TOKEN-EFFICIENT: Full site overview in ONE call — pages, posts, plugins, theme, capability flags. Use at session start instead of 4+ separate calls.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'include_pages' => array( 'type' => 'boolean', 'default' => true ), 'include_posts' => array( 'type' => 'boolean', 'default' => true ), 'include_plugins' => array( 'type' => 'boolean', 'default' => true ), 'include_menus' => array( 'type' => 'boolean', 'default' => false ) ) ) ),
            array( 'name' => 'get_site_info', 'description' => 'Get WordPress site information: name, URL, theme, active plugins, WP version.', 'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ) ),
            array( 'name' => 'get_posts', 'description' => 'List WordPress posts. Use fields param to limit returned data.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'status' => array( 'type' => 'string', 'default' => 'publish' ), 'per_page' => array( 'type' => 'integer', 'default' => 10 ), 'page' => array( 'type' => 'integer', 'default' => 1 ), 'search' => array( 'type' => 'string' ), 'category' => array( 'type' => 'integer' ), 'orderby' => array( 'type' => 'string', 'default' => 'date' ), 'order' => array( 'type' => 'string', 'default' => 'DESC' ), 'fields' => array( 'type' => 'string', 'description' => 'Comma-separated fields: id,title,status,date,slug,link,excerpt. Default: id,title,status,date,slug.' ) ) ) ),
            array( 'name' => 'get_post', 'description' => 'Get a single post/page by ID. Returns metadata only by default. Set include_elementor=true for full Elementor JSON. Set include_content=true for rendered HTML.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'include_elementor' => array( 'type' => 'boolean', 'default' => false ), 'include_content' => array( 'type' => 'boolean', 'default' => false ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'create_post', 'description' => 'Create a WordPress post or page. IMPORTANT: When building an Elementor page, pass elementor_data and leave content empty. NEVER put raw HTML or CSS in the content field for Elementor pages — all styling must live inside Elementor widget settings. MANDATORY: any Elementor page you build must include real images — upload relevant Unsplash images via upload_media_from_url and reference them in image widgets or container backgrounds. Never publish pages with placeholder images or empty image widgets.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'title' => array( 'type' => 'string' ), 'content' => array( 'type' => 'string' ), 'status' => array( 'type' => 'string', 'default' => 'draft' ), 'post_type' => array( 'type' => 'string', 'default' => 'post' ), 'excerpt' => array( 'type' => 'string' ), 'categories' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ), 'tags' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ), 'slug' => array( 'type' => 'string' ), 'featured_media' => array( 'type' => 'integer' ), 'elementor_data' => array( 'type' => 'string' ), 'page_template' => array( 'type' => 'string' ), 'meta_title' => array( 'type' => 'string' ), 'meta_desc' => array( 'type' => 'string' ) ), 'required' => array( 'title' ) ) ),
            array( 'name' => 'update_post', 'description' => 'Update an existing post or page. IMPORTANT: For Elementor pages, update via elementor_data or update_elementor_widget — do not put HTML or CSS in the content field.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'title' => array( 'type' => 'string' ), 'content' => array( 'type' => 'string' ), 'status' => array( 'type' => 'string' ), 'excerpt' => array( 'type' => 'string' ), 'categories' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ), 'tags' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ), 'featured_media' => array( 'type' => 'integer' ), 'elementor_data' => array( 'type' => 'string' ), 'page_template' => array( 'type' => 'string' ), 'meta_title' => array( 'type' => 'string' ), 'meta_desc' => array( 'type' => 'string' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'delete_post', 'description' => 'Delete a post or page (trash by default).', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'force' => array( 'type' => 'boolean', 'default' => false ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'get_pages', 'description' => 'List WordPress pages.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'status' => array( 'type' => 'string', 'default' => 'publish' ), 'per_page' => array( 'type' => 'integer', 'default' => 20 ), 'search' => array( 'type' => 'string' ) ) ) ),
            array( 'name' => 'get_media', 'description' => 'List media library items.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'per_page' => array( 'type' => 'integer', 'default' => 20 ), 'media_type' => array( 'type' => 'string' ), 'search' => array( 'type' => 'string' ) ) ) ),
            array( 'name' => 'upload_media_from_url', 'description' => 'Upload a media file to WordPress from a public URL.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'url' => array( 'type' => 'string' ), 'title' => array( 'type' => 'string' ), 'alt' => array( 'type' => 'string' ), 'filename' => array( 'type' => 'string' ) ), 'required' => array( 'url' ) ) ),
            array( 'name' => 'get_categories', 'description' => 'List all categories.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'per_page' => array( 'type' => 'integer', 'default' => 50 ), 'hide_empty' => array( 'type' => 'boolean', 'default' => false ), 'search' => array( 'type' => 'string' ) ) ) ),
            array( 'name' => 'create_category', 'description' => 'Create a new category.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'name' => array( 'type' => 'string' ), 'description' => array( 'type' => 'string' ), 'slug' => array( 'type' => 'string' ), 'parent' => array( 'type' => 'integer' ) ), 'required' => array( 'name' ) ) ),
            array( 'name' => 'update_category', 'description' => 'Update an existing category name, slug, description, or parent.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'name' => array( 'type' => 'string' ), 'slug' => array( 'type' => 'string' ), 'description' => array( 'type' => 'string' ), 'parent' => array( 'type' => 'integer' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'get_tags', 'description' => 'List all tags.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'per_page' => array( 'type' => 'integer', 'default' => 50 ), 'hide_empty' => array( 'type' => 'boolean', 'default' => false ), 'search' => array( 'type' => 'string' ) ) ) ),
            array( 'name' => 'create_tag', 'description' => 'Create a new tag.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'name' => array( 'type' => 'string' ), 'description' => array( 'type' => 'string' ), 'slug' => array( 'type' => 'string' ) ), 'required' => array( 'name' ) ) ),
            array( 'name' => 'update_tag', 'description' => 'Update an existing tag name, slug, or description.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'name' => array( 'type' => 'string' ), 'slug' => array( 'type' => 'string' ), 'description' => array( 'type' => 'string' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'get_comments', 'description' => 'List comments, optionally filtered by post or status.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'status' => array( 'type' => 'string', 'default' => 'approve' ), 'post_id' => array( 'type' => 'integer' ), 'per_page' => array( 'type' => 'integer', 'default' => 20 ) ) ) ),
            array( 'name' => 'update_comment_status', 'description' => 'Approve, hold, spam or trash a comment.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'status' => array( 'type' => 'string' ) ), 'required' => array( 'id', 'status' ) ) ),

            // ── Options ──
            array( 'name' => 'get_option', 'description' => 'Read a WordPress option value by key. Only whitelisted safe options are accessible.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'option_name' => array( 'type' => 'string' ) ), 'required' => array( 'option_name' ) ) ),
            array( 'name' => 'update_option', 'description' => 'Update a WordPress option value. Only whitelisted safe options can be written.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'option_name' => array( 'type' => 'string' ), 'option_value' => array( 'type' => 'string', 'description' => 'String value to store. For arrays/objects, pass JSON-encoded string.' ) ), 'required' => array( 'option_name', 'option_value' ) ) ),

            // ── Search & Replace ──
            array( 'name' => 'search_replace', 'description' => 'Find and replace a string across all post titles, content, excerpts, and meta values (including Elementor data). Useful for sitewide brand renames. Processes posts in batches and returns a count of affected items. Dry-run mode available.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'search' => array( 'type' => 'string', 'description' => 'Exact string to find (case-sensitive).' ), 'replace' => array( 'type' => 'string', 'description' => 'String to replace with.' ), 'post_types' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'default' => array( 'post', 'page' ), 'description' => 'Post types to scan.' ), 'dry_run' => array( 'type' => 'boolean', 'default' => false, 'description' => 'If true, returns count of matches without making changes.' ), 'include_meta' => array( 'type' => 'boolean', 'default' => true, 'description' => 'Also search post meta values (includes Elementor JSON).' ) ), 'required' => array( 'search', 'replace' ) ) ),

            // ── Elementor ──
            array( 'name' => 'get_elementor_data', 'description' => 'Get Elementor JSON. WARNING: 50-200KB on large pages (high token cost). Pass summary=true for lightweight overview. Prefer get_page_structure for layout reading.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'summary' => array( 'type' => 'boolean', 'default' => false, 'description' => 'Return compact structure instead of full JSON. Much lower token cost.' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'get_page_structure', 'description' => 'Lightweight Elementor layout summary — section IDs, column counts, widget types only. Saves ~90% tokens vs get_elementor_data. Use this before deciding to read/edit a page.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'list_elementor_widgets', 'description' => 'REQUIRED FIRST STEP for any Elementor build. Returns every widget available on this site — Elementor core, Elementor Pro, and installed third-party addons — with name, title, category, and pro/free flag. Do not guess widget names from memory; the widget vocabulary differs between sites depending on which addons are active.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'category' => array( 'type' => 'string', 'description' => 'Optional filter: basic, general, pro, theme-elements, woocommerce-elements, or any custom category slug.' ) ) ) ),
            array( 'name' => 'get_widget_schema', 'description' => 'REQUIRED before using a widget you have not written recently. Returns the real settings shape for a widget type — control names, types, defaults, options — pulled live from the installed Elementor version. Setting keys are NOT stable across Elementor versions or between free/pro; do not invent them.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'widget_type' => array( 'type' => 'string', 'description' => 'Widget name as returned by list_elementor_widgets, e.g. heading, button, form, nav-menu.' ), 'section' => array( 'type' => 'string', 'description' => 'Optional filter: content (default), style, advanced. Content section is usually enough to build with.', 'default' => 'content' ) ), 'required' => array( 'widget_type' ) ) ),

            // ── Template library ──
            array( 'name' => 'list_templates', 'description' => 'STRONGLY PREFERRED workflow: before composing an Elementor page from primitives, call this to see the site\'s curated template library — hero sections, feature grids, CTAs, footers, etc. Templates are hand-authored layouts that already have correct widths, padding, typography, and responsive behavior. Apply a template with apply_template, then customize copy with update_elementor_widget. Returns slug, title, description, categories, thumbnail_url. Filter by category to narrow the list.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'category' => array( 'type' => 'string', 'description' => 'Optional category slug filter, e.g. hero, features, cta, footer.' ) ) ) ),
            array( 'name' => 'get_template', 'description' => 'Return one template\'s full Elementor JSON plus metadata (title, description, categories). Call this to inspect a template\'s structure before applying it, or when you need to understand what widget IDs a template contains.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'template' => array( 'type' => 'string', 'description' => 'Template slug (e.g. hero-centered) or numeric ID.' ) ), 'required' => array( 'template' ) ) ),
            array( 'name' => 'apply_template', 'description' => 'Append a template to an Elementor page. IDs are regenerated so the same template can be applied multiple times. Returns the new widget IDs — use those with update_elementor_widget to customize copy and images. IMAGES ARE MANDATORY: after applying a template that contains an image widget or a container background, upload a relevant Unsplash image via upload_media_from_url and update the widget/container with the real image. Never leave placeholder images or empty image widgets in the final page. Templates cannot smuggle html/shortcode widgets in unless allow_html_widget=true is passed.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'page_id' => array( 'type' => 'integer' ), 'template' => array( 'type' => 'string', 'description' => 'Template slug or numeric ID.' ), 'allow_html_widget' => array( 'type' => 'boolean', 'default' => false ) ), 'required' => array( 'page_id', 'template' ) ) ),
            array( 'name' => 'save_as_template', 'description' => 'Save a section from a page as a new reusable template in the library. Useful when the user says "save this as a template" after Claude built something they like. The user can then browse and edit it in WordPress admin under Claude MCP → Templates.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'page_id' => array( 'type' => 'integer' ), 'section_id' => array( 'type' => 'string', 'description' => 'The section (top-level container) ID from the page\'s Elementor data. Use get_page_structure to find it.' ), 'name' => array( 'type' => 'string' ), 'description' => array( 'type' => 'string' ), 'category' => array( 'type' => 'string', 'description' => 'Optional category slug, e.g. hero, features, cta, footer.' ) ), 'required' => array( 'page_id', 'section_id', 'name' ) ) ),
            array( 'name' => 'set_elementor_data', 'description' => 'Replace all Elementor data on a page. All styling must live inside widget settings using keys from get_widget_schema. The `html` widget is BLOCKED by the server — pass allow_html_widget=true only if the user explicitly requested a raw-HTML block.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'elementor_data' => array( 'type' => 'string' ), 'page_template' => array( 'type' => 'string', 'default' => 'elementor_canvas' ), 'allow_html_widget' => array( 'type' => 'boolean', 'default' => false, 'description' => 'Set true ONLY when the user explicitly asked for a raw HTML/shortcode widget. Otherwise the server rejects any widget of type html/raw-html/shortcode.' ) ), 'required' => array( 'id', 'elementor_data' ) ) ),
            array( 'name' => 'init_elementor_page', 'description' => 'Step 1 of chunked Elementor build. Clears existing data and sets the template. Always call before the first append_elementor_section. Call list_elementor_widgets before this to see what widgets are available on the site.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'page_template' => array( 'type' => 'string', 'default' => 'elementor_canvas' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'append_elementor_section', 'description' => 'Step 2: Append one Elementor section. Use native Elementor and Elementor Pro widgets only, with settings from get_widget_schema. The `html` widget is BLOCKED — pass allow_html_widget=true only if the user explicitly requested a raw-HTML block.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'section_data' => array( 'type' => 'string', 'description' => 'JSON string: single section object {...} or array [{...},{...}]' ), 'allow_html_widget' => array( 'type' => 'boolean', 'default' => false, 'description' => 'Set true ONLY when the user explicitly asked for a raw HTML/shortcode widget.' ) ), 'required' => array( 'id', 'section_data' ) ) ),
            array( 'name' => 'finalize_elementor_page', 'description' => 'Step 3: Call after all append_elementor_section calls. Regenerates CSS and purges caches. Returns section count and live URL.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'qa_page', 'description' => 'QA tool: fetches live rendered HTML and returns a structured report — sections, widgets, headings, text, colours, buttons, pass/fail issues. Call after finalize_elementor_page or set_elementor_data.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'expected_sections' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ) ), 'required' => array( 'id' ) ) ),

            // ── Plugins & Themes ──
            array( 'name' => 'list_plugins', 'description' => 'List all installed WordPress plugins with status, version, and description.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'status' => array( 'type' => 'string', 'default' => 'all' ) ) ) ),
            array( 'name' => 'install_plugin', 'description' => 'Install a plugin from WordPress.org by slug.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'slug' => array( 'type' => 'string' ), 'activate' => array( 'type' => 'boolean', 'default' => false ) ), 'required' => array( 'slug' ) ) ),
            array( 'name' => 'activate_plugin', 'description' => 'Activate a plugin by its plugin file path.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'plugin_file' => array( 'type' => 'string' ) ), 'required' => array( 'plugin_file' ) ) ),
            array( 'name' => 'deactivate_plugin', 'description' => 'Deactivate a plugin by its plugin file path.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'plugin_file' => array( 'type' => 'string' ) ), 'required' => array( 'plugin_file' ) ) ),
            array( 'name' => 'list_themes', 'description' => 'List all installed WordPress themes.', 'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ) ),
            array( 'name' => 'install_theme', 'description' => 'Install a theme from WordPress.org by slug.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'slug' => array( 'type' => 'string' ), 'activate' => array( 'type' => 'boolean', 'default' => false ) ), 'required' => array( 'slug' ) ) ),
            array( 'name' => 'activate_theme', 'description' => 'Activate an installed theme by slug.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'slug' => array( 'type' => 'string' ) ), 'required' => array( 'slug' ) ) ),
array( 'name' => 'get_scheduled_posts', 'description' => 'List scheduled (future) posts with their publish dates.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'post_type' => array( 'type' => 'string', 'default' => 'post' ), 'per_page' => array( 'type' => 'integer', 'default' => 20 ) ) ) ),
            array( 'name' => 'get_menus', 'description' => 'List all navigation menus with their items and theme location assignments.', 'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ) ),
            array( 'name' => 'create_menu', 'description' => 'Create a navigation menu and optionally assign to a theme location slug.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'name' => array( 'type' => 'string' ), 'location' => array( 'type' => 'string' ) ), 'required' => array( 'name' ) ) ),
            array( 'name' => 'update_menu', 'description' => 'Replace all items in a menu. items: [{title, url, parent_id (optional), target (optional)}].', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'menu_id' => array( 'type' => 'integer' ), 'items' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ) ), 'required' => array( 'menu_id', 'items' ) ) ),
            array( 'name' => 'get_customizer_settings', 'description' => 'Read all theme_mods (customizer settings) for the active theme.', 'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ) ),
            array( 'name' => 'update_customizer_settings', 'description' => 'Write one or more theme_mods. Pass {mods: {key: value}}.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'mods' => array( 'type' => 'object' ) ), 'required' => array( 'mods' ) ) ),
            array( 'name' => 'read_theme_file', 'description' => 'Read a file in the active theme. Path relative to theme root (e.g. functions.php). Backs up as .bak before any write.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'path' => array( 'type' => 'string' ), 'theme_slug' => array( 'type' => 'string', 'description' => 'Optional. Defaults to active theme.' ) ), 'required' => array( 'path' ) ) ),
            array( 'name' => 'write_theme_file', 'description' => 'Write a file in the active theme. Backs up original as .bak first. Use read_theme_file before editing.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'path' => array( 'type' => 'string' ), 'content' => array( 'type' => 'string' ), 'theme_slug' => array( 'type' => 'string' ) ), 'required' => array( 'path', 'content' ) ) ),
            array( 'name' => 'read_plugin_file', 'description' => 'Read a file inside a plugin directory. Path relative to plugin root.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'plugin_slug' => array( 'type' => 'string', 'description' => 'Plugin folder name e.g. woocommerce.' ), 'path' => array( 'type' => 'string' ) ), 'required' => array( 'plugin_slug', 'path' ) ) ),
            array( 'name' => 'write_plugin_file', 'description' => 'Write a file inside a plugin. Backs up original as .bak first.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'plugin_slug' => array( 'type' => 'string' ), 'path' => array( 'type' => 'string' ), 'content' => array( 'type' => 'string' ) ), 'required' => array( 'plugin_slug', 'path', 'content' ) ) ),
            array( 'name' => 'list_plugin_files', 'description' => 'List all files in a plugin directory recursively.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'plugin_slug' => array( 'type' => 'string' ) ), 'required' => array( 'plugin_slug' ) ) ),
            array( 'name' => 'get_acf_fields', 'description' => 'Get all ACF field values for a post. Requires ACF active.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'post_id' => array( 'type' => 'integer' ) ), 'required' => array( 'post_id' ) ) ),
            array( 'name' => 'update_acf_fields', 'description' => 'Update ACF field values. Pass {fields: {field_name: value}}. Requires ACF active.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'post_id' => array( 'type' => 'integer' ), 'fields' => array( 'type' => 'object' ) ), 'required' => array( 'post_id', 'fields' ) ) ),
            array( 'name' => 'get_acf_field_groups', 'description' => 'List all ACF field groups and their field definitions. Requires ACF active.', 'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ) ),
            array( 'name' => 'get_error_log', 'description' => 'Read last N lines of wp-content/debug.log. Newest first. Optional filter string.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'lines' => array( 'type' => 'integer', 'default' => 50 ), 'filter' => array( 'type' => 'string' ) ) ) ),
            array( 'name' => 'audit_seo', 'description' => 'Per-post SEO audit: meta title/desc, alt text, word count, headings. Sorted worst-first.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'post_type' => array( 'type' => 'string', 'default' => 'post' ), 'per_page' => array( 'type' => 'integer', 'default' => 20 ), 'status' => array( 'type' => 'string', 'default' => 'publish' ) ) ) ),
            array( 'name' => 'get_broken_links', 'description' => 'Scan posts for broken links (HTTP 4xx/5xx). Keep per_page low for speed.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'post_type' => array( 'type' => 'string', 'default' => 'post' ), 'per_page' => array( 'type' => 'integer', 'default' => 10 ) ) ) ),
            array( 'name' => 'send_email', 'description' => 'Send an email via wp_mail(). Useful for testing templates or admin notifications.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'to' => array( 'type' => 'string' ), 'subject' => array( 'type' => 'string' ), 'message' => array( 'type' => 'string' ), 'is_html' => array( 'type' => 'boolean', 'default' => false ) ), 'required' => array( 'to', 'subject', 'message' ) ) ),
            array( 'name' => 'backup_post', 'description' => 'Snapshot a post title, content and Elementor data before editing. Returns backup_id. Keeps last 10 per post.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'note' => array( 'type' => 'string' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'restore_post', 'description' => 'Restore a post from a saved backup snapshot.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'backup_id' => array( 'type' => 'string' ) ), 'required' => array( 'id', 'backup_id' ) ) ),
            array( 'name' => 'list_backups', 'description' => 'List all saved backups for a post.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ) ), 'required' => array( 'id' ) ) ),
            array( 'name' => 'update_elementor_widget', 'description' => 'Update a single Elementor widget settings by ID. Prefer this over full page replacement. Settings must use native Elementor properties — do not inject raw HTML or CSS strings into widget content fields.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'page_id' => array( 'type' => 'integer' ), 'widget_id' => array( 'type' => 'string' ), 'settings' => array( 'type' => 'object' ) ), 'required' => array( 'page_id', 'widget_id', 'settings' ) ) ),
            array( 'name' => 'copy_elementor_section', 'description' => 'Copy a section from one page and append it to another. Use get_page_structure to find section IDs. If the source section contains an html widget the copy is REJECTED unless allow_html_widget=true.', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'source_page_id' => array( 'type' => 'integer' ), 'section_id' => array( 'type' => 'string' ), 'target_page_id' => array( 'type' => 'integer' ), 'regenerate_ids' => array( 'type' => 'boolean', 'default' => true ), 'allow_html_widget' => array( 'type' => 'boolean', 'default' => false ) ), 'required' => array( 'source_page_id', 'section_id', 'target_page_id' ) ) ),
            array( 'name' => 'get_elementor_globals', 'description' => 'Read Elementor global colors and global fonts (design tokens).', 'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass() ) ),
            array( 'name' => 'update_elementor_globals', 'description' => 'Update Elementor global colors or fonts. colors: [{id, title, value (hex)}]. fonts: [{id, title, value (font-family)}].', 'inputSchema' => array( 'type' => 'object', 'properties' => array( 'colors' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ), 'fonts' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ) ) ) ),
        );
    }

    /* ── Tool dispatcher ────────────────────────────────────────── */

    public function execute_tool( $name, $args ) {
        // License gate (v30.7.3+). Must run on EVERY transport, not just the
        // REST route, so standalone mcp-server.php traffic is also blocked
        // when a managed license is expired or invalid. Unmanaged installs
        // (CLAUDE_MCP_LICENSE_SERVER undefined) short-circuit to allow.
        if ( class_exists( 'Claude_MCP_License' ) && Claude_MCP_License::is_blocked() ) {
            return new WP_Error(
                'license_blocked',
                'License check failed (' . Claude_MCP_License::status_label() . '). Open Claude MCP → License in wp-admin to resolve.',
                array( 'status' => 402, 'license_status' => Claude_MCP_License::status() )
            );
        }

        // Permission gate — a configured OFF toggle blocks the tool before dispatch.
        $gate = Claude_MCP_Permissions::check_tool( $name );
        if ( is_wp_error( $gate ) ) return $gate;

        $result = $this->dispatch_tool( $name, $args );

        // v30.5.1+: write an activity-log row for destructive tools, after
        // dispatch so the row carries any id or slug the handler returned.
        // Skip if the handler itself failed — we only log actual effects.
        if ( ! is_wp_error( $result ) && class_exists( 'Claude_MCP_Activity' ) ) {
            Claude_MCP_Activity::record( $name, is_array( $args ) ? $args : array(), is_array( $result ) ? $result : null );
        }

        return $result;
    }

    private function dispatch_tool( $name, $args ) {
        switch ( $name ) {
            case 'context_summary':             return $this->context_summary( $args );
            case 'get_site_info':               return $this->get_site_info();
            case 'get_posts':                   return $this->get_posts( $args );
            case 'get_post':                    return $this->get_post( $args );
            case 'create_post':                 return $this->create_post( $args );
            case 'update_post':                 return $this->update_post( $args );
            case 'delete_post':                 return $this->delete_post( $args );
            case 'get_pages':                   return $this->get_pages( $args );
            case 'get_media':                   return $this->get_media( $args );
            case 'upload_media_from_url':       return $this->upload_media_from_url( $args );
            case 'get_categories':              return $this->get_categories( $args );
            case 'create_category':             return $this->create_category( $args );
            case 'update_category':             return $this->update_category( $args );
            case 'get_tags':                    return $this->get_tags( $args );
            case 'create_tag':                  return $this->create_tag( $args );
            case 'update_tag':                  return $this->update_tag( $args );
            case 'get_comments':                return $this->get_comments( $args );
            case 'update_comment_status':       return $this->update_comment_status( $args );
            case 'get_option':                  return $this->get_option( $args );
            case 'update_option':               return $this->update_option( $args );
            case 'search_replace':              return $this->search_replace( $args );
            case 'list_elementor_widgets':      return $this->list_elementor_widgets( $args );
            case 'get_widget_schema':           return $this->get_widget_schema( $args );
            case 'list_templates':              return $this->list_templates( $args );
            case 'get_template':                return $this->get_template( $args );
            case 'apply_template':              return $this->apply_template( $args );
            case 'save_as_template':            return $this->save_as_template( $args );
            case 'get_elementor_data':          return $this->get_elementor_data( $args );
            case 'get_page_structure':          return $this->get_page_structure( $args );
            case 'set_elementor_data':          return $this->set_elementor_data( $args );
            case 'init_elementor_page':         return $this->init_elementor_page( $args );
            case 'append_elementor_section':    return $this->append_elementor_section( $args );
            case 'finalize_elementor_page':     return $this->finalize_elementor_page( $args );
            case 'qa_page':                     return $this->qa_page( $args );
            case 'list_plugins':                return $this->list_plugins( $args );
            case 'install_plugin':              return $this->install_plugin( $args );
            case 'activate_plugin':             return $this->activate_plugin( $args );
            case 'deactivate_plugin':           return $this->deactivate_plugin( $args );
            case 'list_themes':                 return $this->list_themes();
            case 'install_theme':               return $this->install_theme( $args );
            case 'activate_theme':              return $this->activate_theme( $args );
case 'get_scheduled_posts':        return $this->get_scheduled_posts( $args );
            case 'get_menus':                  return $this->get_menus();
            case 'create_menu':                return $this->create_menu( $args );
            case 'update_menu':                return $this->update_menu( $args );
            case 'get_customizer_settings':    return $this->get_customizer_settings();
            case 'update_customizer_settings': return $this->update_customizer_settings( $args );
            case 'read_theme_file':            return $this->read_theme_file( $args );
            case 'write_theme_file':           return $this->write_theme_file( $args );
            case 'read_plugin_file':           return $this->read_plugin_file( $args );
            case 'write_plugin_file':          return $this->write_plugin_file( $args );
            case 'list_plugin_files':          return $this->list_plugin_files( $args );
            case 'get_acf_fields':             return $this->get_acf_fields( $args );
            case 'update_acf_fields':          return $this->update_acf_fields( $args );
            case 'get_acf_field_groups':       return $this->get_acf_field_groups();
            case 'get_error_log':              return $this->get_error_log( $args );
            case 'audit_seo':                  return $this->audit_seo( $args );
            case 'get_broken_links':           return $this->get_broken_links( $args );
            case 'send_email':                 return $this->send_email( $args );
            case 'backup_post':                return $this->backup_post( $args );
            case 'restore_post':               return $this->restore_post( $args );
            case 'list_backups':               return $this->list_backups( $args );
            case 'update_elementor_widget':    return $this->update_elementor_widget( $args );
            case 'copy_elementor_section':     return $this->copy_elementor_section( $args );
            case 'get_elementor_globals':      return $this->get_elementor_globals();
            case 'update_elementor_globals':   return $this->update_elementor_globals( $args );
            case 'get_elementor_templates':    return $this->get_elementor_templates( $args );
            case 'create_elementor_template':  return $this->create_elementor_template( $args );
            case 'get_elementor_template':     return $this->get_elementor_template( $args );
            case 'apply_elementor_template':   return $this->apply_elementor_template( $args );
            case 'wc_get_products':            return $this->wc_get_products( $args );
            case 'wc_get_product':             return $this->wc_get_product( $args );
            case 'wc_update_product':          return $this->wc_update_product( $args );
            case 'wc_get_orders':              return $this->wc_get_orders( $args );
            case 'wc_get_order':               return $this->wc_get_order( $args );
            case 'wc_update_order_status':     return $this->wc_update_order_status( $args );
            default: throw new Exception( "Unknown tool: {$name}" );
        }
    }

    // =========================================================
    //  CORE WORDPRESS TOOLS
    // =========================================================

    private function get_site_info() {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $plugins = array();
        foreach ( get_option( 'active_plugins', array() ) as $p ) {
            $d = get_plugin_data( WP_PLUGIN_DIR . '/' . $p, false, false );
            if ( ! empty( $d['Name'] ) ) { $plugins[] = $d['Name']; }
        }
        $theme = wp_get_theme();
        return array(
            'name'           => get_bloginfo( 'name' ),
            'description'    => get_bloginfo( 'description' ),
            'url'            => get_bloginfo( 'url' ),
            'wp_version'     => get_bloginfo( 'version' ),
            'active_theme'   => $theme->get( 'Name' ),
            'active_plugins' => $plugins,
            'timezone'       => get_option( 'timezone_string' ),
            'admin_email'    => get_bloginfo( 'admin_email' ),
            'elementor_ver'  => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : null,
            'woocommerce'    => class_exists( 'WooCommerce' ) ? ( defined( 'WC_VERSION' ) ? WC_VERSION : 'active' ) : false,
            'acf'            => function_exists( 'get_field' ) ? ( defined( 'ACF_VERSION' ) ? ACF_VERSION : 'active' ) : false,
            'is_multisite'   => is_multisite(),
            'mcp_version'    => CLAUDE_MCP_VERSION,
            'capabilities'   => array(
                'woocommerce' => class_exists( 'WooCommerce' ),
                'acf'         => function_exists( 'get_field' ),
                'elementor'   => class_exists( 'Elementor\Plugin' ),
                'multisite'   => is_multisite(),
            ),
        );
    }

    private function get_posts( $a ) {
        $q = new WP_Query( array_filter( array(
            'post_type'      => 'post',
            'post_status'    => $a['status']   ?? 'publish',
            'posts_per_page' => intval( $a['per_page'] ?? 10 ),
            'paged'          => intval( $a['page'] ?? 1 ),
            'orderby'        => $a['orderby']  ?? 'date',
            'order'          => $a['order']    ?? 'DESC',
            's'              => $a['search']   ?? '',
            'cat'            => isset( $a['category'] ) ? intval( $a['category'] ) : null,
        ) ) );
        $defaults = array( 'id', 'title', 'status', 'date', 'slug' );
        $fields   = $this->parse_fields( isset( $a['fields'] ) ? $a['fields'] : '', $defaults );
        $posts    = array();
        foreach ( $q->posts as $p ) {
            $row = array();
            if ( in_array( 'id',         $fields ) ) { $row['id']         = $p->ID; }
            if ( in_array( 'title',      $fields ) ) { $row['title']      = $p->post_title; }
            if ( in_array( 'status',     $fields ) ) { $row['status']     = $p->post_status; }
            if ( in_array( 'date',       $fields ) ) { $row['date']       = $p->post_date; }
            if ( in_array( 'slug',       $fields ) ) { $row['slug']       = $p->post_name; }
            if ( in_array( 'link',       $fields ) ) { $row['link']       = get_permalink( $p->ID ); }
            if ( in_array( 'excerpt',    $fields ) ) { $row['excerpt']    = $p->post_excerpt; }
            if ( in_array( 'categories', $fields ) ) { $row['categories'] = wp_get_post_categories( $p->ID ); }
            if ( in_array( 'tags',       $fields ) ) { $row['tags']       = wp_get_post_tags( $p->ID, array( 'fields' => 'ids' ) ); }
            $posts[] = $row;
        }
        return array( 'total' => $q->found_posts, 'posts' => $posts );
    }

    private function get_post( $a ) {
        $p = get_post( intval( $a['id'] ) );
        if ( ! $p ) throw new Exception( 'Post not found.' );
        $result = array(
            'id'             => $p->ID,
            'title'          => $p->post_title,
            'status'         => $p->post_status,
            'type'           => $p->post_type,
            'date'           => $p->post_date,
            'slug'           => $p->post_name,
            'link'           => get_permalink( $p->ID ),
            'excerpt'        => $p->post_excerpt,
            'featured_media' => get_post_thumbnail_id( $p->ID ),
            'template'       => get_page_template_slug( $p->ID ),
            'has_elementor'  => (bool) get_post_meta( $p->ID, '_elementor_data', true ),
            'categories'     => wp_get_post_categories( $p->ID ),
            'tags'           => wp_get_post_tags( $p->ID, array( 'fields' => 'ids' ) ),
        );
        if ( ! empty( $a['include_content'] ) ) {
            $result['content'] = $p->post_content;
        }
        if ( ! empty( $a['include_elementor'] ) ) {
            $raw = get_post_meta( $p->ID, '_elementor_data', true );
            $result['elementor_data']   = $raw ?: null;
            $result['section_count']    = $raw ? count( (array) json_decode( $raw, true ) ) : 0;
            $result['data_size_bytes']  = strlen( $raw ?: '' );
        }
        return $result;
    }

    private function create_post( $a ) {
        $data = array(
            'post_title'   => sanitize_text_field( $a['title'] ),
            // Use wp_unslash + wp_kses_post for content — allows full HTML (Elementor shortcodes, custom attrs)
            'post_content' => isset( $a['content'] ) ? wp_kses_post( wp_unslash( $a['content'] ) ) : '',
            'post_status'  => $a['status']    ?? 'draft',
            'post_type'    => $a['post_type'] ?? 'post',
        );
        if ( ! empty( $a['excerpt'] ) )    $data['post_excerpt']  = sanitize_text_field( $a['excerpt'] );
        if ( ! empty( $a['slug'] ) )       $data['post_name']     = sanitize_title( $a['slug'] );
        if ( ! empty( $a['categories'] ) ) $data['post_category'] = array_map( 'intval', $a['categories'] );
        $id = wp_insert_post( $data, true );
        if ( is_wp_error( $id ) ) throw new Exception( $id->get_error_message() );
        $this->save_meta( $id, $a );
        return array( 'success' => true, 'id' => $id, 'link' => get_permalink( $id ), 'message' => "Post created with ID {$id}." );
    }

    private function update_post( $a ) {
        $id   = intval( $a['id'] );
        $data = array( 'ID' => $id );
        if ( isset( $a['title'] ) )      $data['post_title']   = sanitize_text_field( $a['title'] );
        if ( isset( $a['content'] ) )    $data['post_content'] = wp_kses_post( wp_unslash( $a['content'] ) );
        if ( isset( $a['status'] ) )     $data['post_status']  = $a['status'];
        if ( isset( $a['excerpt'] ) )    $data['post_excerpt'] = sanitize_text_field( $a['excerpt'] );
        if ( isset( $a['categories'] ) ) $data['post_category']= array_map( 'intval', $a['categories'] );
        $r = wp_update_post( $data, true );
        if ( is_wp_error( $r ) ) throw new Exception( $r->get_error_message() );
        $this->save_meta( $id, $a );
        return array( 'success' => true, 'id' => $id, 'link' => get_permalink( $id ), 'message' => "Post {$id} updated." );
    }

    private function save_meta( $id, $a ) {
        if ( ! empty( $a['featured_media'] ) ) set_post_thumbnail( $id, intval( $a['featured_media'] ) );
        if ( ! empty( $a['tags'] ) )           wp_set_post_tags( $id, array_map( 'intval', $a['tags'] ) );

        if ( ! empty( $a['elementor_data'] ) ) {
            update_post_meta( $id, '_elementor_data',      $a['elementor_data'] );
            update_post_meta( $id, '_elementor_edit_mode', 'builder' );
            // Use actual Elementor version if available, not hardcoded 3.0.0.
            $el_ver = defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0';
            update_post_meta( $id, '_elementor_version', $el_ver );
            $this->regenerate_elementor_css( $id );
            $this->purge_page_cache( $id );
        }

        if ( ! empty( $a['page_template'] ) ) {
            update_post_meta( $id, '_wp_page_template', $a['page_template'] );
            wp_update_post( array( 'ID' => $id, 'page_template' => $a['page_template'] ) );
        } else {
            $existing_tpl = get_post_meta( $id, '_wp_page_template', true );
            if ( ! empty( $existing_tpl ) ) {
                wp_update_post( array( 'ID' => $id, 'page_template' => $existing_tpl ) );
            }
        }

        if ( ! empty( $a['meta_title'] ) ) {
            update_post_meta( $id, '_yoast_wpseo_title', $a['meta_title'] );
            update_post_meta( $id, 'rank_math_title',    $a['meta_title'] );
        }
        if ( ! empty( $a['meta_desc'] ) ) {
            update_post_meta( $id, '_yoast_wpseo_metadesc',  $a['meta_desc'] );
            update_post_meta( $id, 'rank_math_description',  $a['meta_desc'] );
        }
    }

    private function delete_post( $a ) {
        $r = wp_delete_post( intval( $a['id'] ), $a['force'] ?? false );
        if ( ! $r ) throw new Exception( 'Failed to delete post.' );
        return array( 'success' => true, 'message' => "Post {$a['id']} deleted." );
    }

    private function get_pages( $a ) {
        $q = new WP_Query( array(
            'post_type'      => 'page',
            'post_status'    => $a['status']  ?? 'publish',
            'posts_per_page' => intval( $a['per_page'] ?? 20 ),
            's'              => $a['search']  ?? '',
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ) );
        $pages = array();
        foreach ( $q->posts as $p ) {
            $pages[] = array( 'id' => $p->ID, 'title' => $p->post_title, 'status' => $p->post_status, 'slug' => $p->post_name, 'link' => get_permalink( $p->ID ), 'template' => get_page_template_slug( $p->ID ) );
        }
        return array( 'total' => $q->found_posts, 'pages' => $pages );
    }

    private function get_media( $a ) {
        $q = new WP_Query( array_filter( array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => intval( $a['per_page'] ?? 20 ),
            'post_mime_type' => $a['media_type'] ?? null,
            's'              => $a['search'] ?? '',
        ) ) );
        $items = array();
        foreach ( $q->posts as $p ) {
            $items[] = array( 'id' => $p->ID, 'title' => $p->post_title, 'url' => wp_get_attachment_url( $p->ID ), 'type' => $p->post_mime_type, 'alt' => get_post_meta( $p->ID, '_wp_attachment_image_alt', true ) );
        }
        return array( 'total' => $q->found_posts, 'media' => $items );
    }

    private function upload_media_from_url( $a ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $url = esc_url_raw( $a['url'] );

        if ( ! empty( $a['filename'] ) ) {
            $filename = sanitize_file_name( $a['filename'] );
        } else {
            $filename = basename( parse_url( $url, PHP_URL_PATH ) );
            if ( empty( $filename ) || strlen( $filename ) < 3 ) {
                $filename = 'figma-asset-' . time() . '.jpg';
            }
        }

        $tmp = download_url( $url );
        if ( is_wp_error( $tmp ) ) throw new Exception( 'Download failed: ' . $tmp->get_error_message() );

        $file = array( 'name' => $filename, 'tmp_name' => $tmp );
        $id   = media_handle_sideload( $file, 0 );
        if ( is_wp_error( $id ) ) { @unlink( $tmp ); throw new Exception( 'Upload failed: ' . $id->get_error_message() ); }

        if ( ! empty( $a['title'] ) ) wp_update_post( array( 'ID' => $id, 'post_title' => sanitize_text_field( $a['title'] ) ) );
        if ( ! empty( $a['alt'] ) )   update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $a['alt'] ) );

        return array( 'success' => true, 'id' => $id, 'url' => wp_get_attachment_url( $id ), 'filename' => $filename, 'message' => "Media uploaded with ID {$id}." );
    }

    private function get_categories( $a ) {
        $terms = get_terms( array( 'taxonomy' => 'category', 'number' => intval( $a['per_page'] ?? 50 ), 'hide_empty' => $a['hide_empty'] ?? false, 'search' => $a['search'] ?? '' ) );
        if ( is_wp_error( $terms ) ) throw new Exception( $terms->get_error_message() );
        return array( 'categories' => array_map( fn( $t ) => array( 'id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug, 'count' => $t->count, 'parent' => $t->parent ), $terms ) );
    }

    private function create_category( $a ) {
        $r = wp_insert_term( $a['name'], 'category', array_filter( array( 'description' => $a['description'] ?? '', 'slug' => $a['slug'] ?? '', 'parent' => isset( $a['parent'] ) ? intval( $a['parent'] ) : 0 ) ) );
        if ( is_wp_error( $r ) ) throw new Exception( $r->get_error_message() );
        return array( 'success' => true, 'id' => $r['term_id'], 'message' => "Category created with ID {$r['term_id']}." );
    }

    private function update_category( $a ) {
        $id   = intval( $a['id'] );
        $args = array_filter( array(
            'name'        => isset( $a['name'] )        ? sanitize_text_field( $a['name'] ) : null,
            'slug'        => isset( $a['slug'] )        ? sanitize_title( $a['slug'] )      : null,
            'description' => $a['description'] ?? null,
            'parent'      => isset( $a['parent'] )      ? intval( $a['parent'] )            : null,
        ), fn( $v ) => ! is_null( $v ) );
        $r = wp_update_term( $id, 'category', $args );
        if ( is_wp_error( $r ) ) throw new Exception( $r->get_error_message() );
        return array( 'success' => true, 'id' => $id, 'message' => "Category {$id} updated." );
    }

    private function get_tags( $a ) {
        $terms = get_terms( array( 'taxonomy' => 'post_tag', 'number' => intval( $a['per_page'] ?? 50 ), 'hide_empty' => $a['hide_empty'] ?? false, 'search' => $a['search'] ?? '' ) );
        if ( is_wp_error( $terms ) ) throw new Exception( $terms->get_error_message() );
        return array( 'tags' => array_map( fn( $t ) => array( 'id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug, 'count' => $t->count ), $terms ) );
    }

    private function create_tag( $a ) {
        $r = wp_insert_term( $a['name'], 'post_tag', array_filter( array( 'description' => $a['description'] ?? '', 'slug' => $a['slug'] ?? '' ) ) );
        if ( is_wp_error( $r ) ) throw new Exception( $r->get_error_message() );
        return array( 'success' => true, 'id' => $r['term_id'], 'message' => "Tag created with ID {$r['term_id']}." );
    }

    private function update_tag( $a ) {
        $id   = intval( $a['id'] );
        $args = array_filter( array(
            'name'        => isset( $a['name'] )        ? sanitize_text_field( $a['name'] ) : null,
            'slug'        => isset( $a['slug'] )        ? sanitize_title( $a['slug'] )      : null,
            'description' => $a['description'] ?? null,
        ), fn( $v ) => ! is_null( $v ) );
        $r = wp_update_term( $id, 'post_tag', $args );
        if ( is_wp_error( $r ) ) throw new Exception( $r->get_error_message() );
        return array( 'success' => true, 'id' => $id, 'message' => "Tag {$id} updated." );
    }

    private function get_comments( $a ) {
        $comments = get_comments( array_filter( array( 'status' => $a['status'] ?? 'approve', 'number' => intval( $a['per_page'] ?? 20 ), 'post_id' => isset( $a['post_id'] ) ? intval( $a['post_id'] ) : null ) ) );
        return array( 'comments' => array_map( fn( $c ) => array( 'id' => $c->comment_ID, 'post_id' => $c->comment_post_ID, 'author' => $c->comment_author, 'content' => $c->comment_content, 'status' => $c->comment_approved, 'date' => $c->comment_date ), $comments ) );
    }

    private function update_comment_status( $a ) {
        if ( ! wp_set_comment_status( intval( $a['id'] ), $a['status'] ) ) throw new Exception( 'Failed to update comment.' );
        return array( 'success' => true, 'message' => "Comment {$a['id']} updated to {$a['status']}." );
    }

    // =========================================================
    //  OPTIONS TOOLS
    // =========================================================

    /**
     * Whitelist of option keys that are safe to read/write via the MCP.
     * Keeps auth keys, secret keys, and critical settings out of Claude's reach.
     */
    private function options_whitelist() {
        return array(
            // Site identity
            'blogname', 'blogdescription', 'siteurl', 'home', 'admin_email',
            'blogpublic', 'date_format', 'time_format', 'timezone_string',
            'start_of_week', 'default_category', 'default_post_format',
            // Reading / discussion
            'posts_per_page', 'posts_per_rss', 'rss_use_excerpt',
            'default_comment_status', 'default_ping_status',
            'comment_moderation', 'comment_max_links', 'moderation_notify',
            'comments_notify', 'close_comments_for_old_posts', 'close_comments_days_old',
            // Media
            'thumbnail_size_w', 'thumbnail_size_h', 'medium_size_w', 'medium_size_h',
            'large_size_w', 'large_size_h', 'uploads_use_yearmonth_folders',
            // Permalink / misc
            'permalink_structure', 'tag_base', 'category_base',
            // Common plugin options (safe ones)
            'elementor_cpt_support', 'elementor_disable_color_schemes',
            'elementor_disable_typography_schemes', 'elementor_editor_break_lines',
            'rank_math_modules', 'woocommerce_store_address', 'woocommerce_currency',
            'woocommerce_price_decimal_sep', 'woocommerce_price_thousand_sep',
        );
    }

    private function get_option( $a ) {
        $key = sanitize_key( $a['option_name'] );
        if ( ! in_array( $key, $this->options_whitelist(), true ) ) {
            throw new Exception( "Option '{$key}' is not in the allowed list. Allowed: " . implode( ', ', $this->options_whitelist() ) );
        }
        $value = get_option( $key );
        return array( 'option_name' => $key, 'value' => $value );
    }

    private function update_option( $a ) {
        $key = sanitize_key( $a['option_name'] );
        if ( ! in_array( $key, $this->options_whitelist(), true ) ) {
            throw new Exception( "Option '{$key}' is not in the allowed list." );
        }
        $value = $a['option_value'];
        // Attempt JSON decode if the string looks like an object/array.
        if ( is_string( $value ) && ( $value[0] === '{' || $value[0] === '[' ) ) {
            $decoded = json_decode( $value, true );
            if ( json_last_error() === JSON_ERROR_NONE ) $value = $decoded;
        }
        update_option( $key, $value );
        return array( 'success' => true, 'option_name' => $key, 'message' => "Option '{$key}' updated." );
    }

    // =========================================================
    //  SEARCH & REPLACE
    // =========================================================

    private function search_replace( $a ) {
        $search      = $a['search']       ?? '';
        $replace     = $a['replace']      ?? '';
        $post_types  = $a['post_types']   ?? array( 'post', 'page' );
        $dry_run     = (bool) ( $a['dry_run']     ?? false );
        $include_meta= (bool) ( $a['include_meta'] ?? true );

        if ( $search === '' ) throw new Exception( 'search cannot be empty.' );

        global $wpdb;
        $affected_posts = 0;
        $affected_meta  = 0;
        $log            = array();

        // Sanitize post types
        $post_types = array_map( 'sanitize_key', (array) $post_types );

        $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
        $posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, post_content, post_excerpt FROM {$wpdb->posts}
             WHERE post_type IN ({$placeholders}) AND post_status NOT IN ('trash','auto-draft')",
            ...$post_types
        ) );

        foreach ( $posts as $post ) {
            $changed     = false;
            $new_title   = str_replace( $search, $replace, $post->post_title );
            $new_content = str_replace( $search, $replace, $post->post_content );
            $new_excerpt = str_replace( $search, $replace, $post->post_excerpt );

            if ( $new_title !== $post->post_title || $new_content !== $post->post_content || $new_excerpt !== $post->post_excerpt ) {
                $changed = true;
                if ( ! $dry_run ) {
                    $wpdb->update( $wpdb->posts, array(
                        'post_title'   => $new_title,
                        'post_content' => $new_content,
                        'post_excerpt' => $new_excerpt,
                    ), array( 'ID' => $post->ID ) );
                    clean_post_cache( $post->ID );
                }
                $log[] = "post:{$post->ID} title/content/excerpt";
                $affected_posts++;
            }

            if ( $include_meta ) {
                $metas = $wpdb->get_results( $wpdb->prepare(
                    "SELECT meta_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_value LIKE %s",
                    $post->ID,
                    '%' . $wpdb->esc_like( $search ) . '%'
                ) );
                foreach ( $metas as $meta ) {
                    $new_val = str_replace( $search, $replace, $meta->meta_value );
                    if ( $new_val !== $meta->meta_value ) {
                        if ( ! $dry_run ) {
                            $wpdb->update( $wpdb->postmeta, array( 'meta_value' => $new_val ), array( 'meta_id' => $meta->meta_id ) );
                            wp_cache_delete( $post->ID, 'post_meta' );
                        }
                        $log[] = "post:{$post->ID} meta:{$meta->meta_key}";
                        $affected_meta++;
                    }
                }
            }
        }

        $total = $affected_posts + $affected_meta;
        return array(
            'success'          => true,
            'dry_run'          => $dry_run,
            'search'           => $search,
            'replace'          => $replace,
            'affected_posts'   => $affected_posts,
            'affected_meta'    => $affected_meta,
            'total_changes'    => $total,
            'sample_log'       => array_slice( $log, 0, 20 ),
            'message'          => $dry_run
                ? "DRY RUN: {$total} replacement(s) would be made across {$affected_posts} post(s) and {$affected_meta} meta row(s)."
                : "Done: {$total} replacement(s) made. {$affected_posts} post(s), {$affected_meta} meta row(s) updated.",
        );
    }

    // =========================================================
    //  ELEMENTOR TOOLS
    // =========================================================

    private function get_page_structure( $a ) {
        $id  = intval( $a['id'] );
        $raw = get_post_meta( $id, '_elementor_data', true );
        if ( ! $raw ) {
            return array( 'id' => $id, 'has_elementor' => false, 'section_count' => 0, 'sections' => array() );
        }
        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) ) {
            throw new Exception( 'Elementor data is not valid JSON.' );
        }
        $sections = array();
        foreach ( $data as $section ) {
            $elType   = $section['elType'] ?? 'unknown';
            $secId    = $section['id'] ?? '';
            $cols     = 0;
            $widgets  = array();
            $children = $section['elements'] ?? array();
            foreach ( $children as $col ) {
                $cols++;
                foreach ( $col['elements'] ?? array() as $widget ) {
                    $wtype     = $widget['widgetType'] ?? $widget['elType'] ?? 'unknown';
                    $widgets[] = $wtype;
                    if ( ! empty( $widget['elements'] ) ) {
                        foreach ( $widget['elements'] as $nested ) {
                            $widgets[] = $nested['widgetType'] ?? $nested['elType'] ?? 'unknown';
                        }
                    }
                }
            }
            $sections[] = array( 'id' => $secId, 'elType' => $elType, 'columns' => $cols, 'widgets' => $widgets );
        }
        return array( 'id' => $id, 'has_elementor' => true, 'template' => get_page_template_slug( $id ), 'section_count' => count( $sections ), 'data_size_bytes' => strlen( $raw ), 'sections' => $sections );
    }

    private function get_elementor_data( $a ) {
        $id  = intval( $a['id'] );
        if ( ! empty( $a['summary'] ) ) { return $this->get_page_structure( $a ); }
        $raw = get_post_meta( $id, '_elementor_data', true );
        $sections = 0;
        if ( $raw ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) $sections = count( $decoded );
        }
        return array( 'id' => $id, 'edit_mode' => get_post_meta( $id, '_elementor_edit_mode', true ), 'template' => get_page_template_slug( $id ), 'elementor_data' => $raw ?: null, 'has_elementor' => (bool) $raw, 'section_count' => $sections, 'data_size_bytes' => strlen( $raw ?: '' ) );
    }

    // =========================================================
    //  ELEMENTOR — HTML-widget guard
    // =========================================================

    /**
     * List of widget types that inject raw markup and bypass the widget system.
     * Server-side hard block. The model must not create these unless the user
     * explicitly asks and passes allow_html_widget=true.
     */
    private function forbidden_widget_types() {
        return array( 'html', 'raw-html', 'shortcode' );
    }

    /**
     * Walk an Elementor JSON tree and throw if any forbidden widget type is
     * present. Called before writing to _elementor_data.
     *
     * @param array $elements   Decoded Elementor array (top-level or subtree).
     * @param bool  $allow_html If true, guard is skipped.
     * @param array $path       Internal — breadcrumb of ids for the error message.
     */
    private function assert_no_html_widgets( $elements, $allow_html, $path = array() ) {
        if ( $allow_html ) return;
        if ( ! is_array( $elements ) ) return;
        $forbidden = $this->forbidden_widget_types();
        foreach ( $elements as $el ) {
            if ( ! is_array( $el ) ) continue;
            $wtype = isset( $el['widgetType'] ) ? $el['widgetType'] : '';
            $id    = isset( $el['id'] )         ? $el['id']         : '?';
            if ( $wtype && in_array( $wtype, $forbidden, true ) ) {
                $trail = implode( ' > ', array_merge( $path, array( "{$wtype}#{$id}" ) ) );
                throw new Exception(
                    "Blocked: widget type '{$wtype}' is forbidden (found at {$trail}). " .
                    "Use a native Elementor or Elementor Pro widget instead — call list_elementor_widgets to see options and get_widget_schema for its settings. " .
                    "If the user explicitly asked for a raw HTML/shortcode widget, re-send this call with allow_html_widget=true."
                );
            }
            if ( ! empty( $el['elements'] ) ) {
                $sub_path = array_merge( $path, array( ( $wtype ?: 'section' ) . "#{$id}" ) );
                $this->assert_no_html_widgets( $el['elements'], $allow_html, $sub_path );
            }
        }
    }

    // =========================================================
    //  ELEMENTOR — widget catalog & schema
    // =========================================================

    private function require_elementor() {
        if ( ! class_exists( '\Elementor\Plugin' ) ) {
            throw new Exception( 'Elementor is not active on this site.' );
        }
        // Elementor lazy-loads widgets — force registration before we enumerate.
        \Elementor\Plugin::instance()->widgets_manager->get_widget_types();
    }

    private function list_elementor_widgets( $a ) {
        $this->require_elementor();
        $filter  = isset( $a['category'] ) ? sanitize_key( $a['category'] ) : '';
        $has_pro = defined( 'ELEMENTOR_PRO_VERSION' );

        $types = \Elementor\Plugin::instance()->widgets_manager->get_widget_types();
        $out   = array();
        foreach ( $types as $name => $widget ) {
            $cats = method_exists( $widget, 'get_categories' ) ? (array) $widget->get_categories() : array();
            if ( $filter && ! in_array( $filter, $cats, true ) ) continue;
            $keywords = method_exists( $widget, 'get_keywords' ) ? (array) $widget->get_keywords() : array();
            // Heuristic for "is this a Pro widget" — Elementor Pro widget class namespace.
            $class = get_class( $widget );
            $is_pro = ( strpos( $class, 'ElementorPro' ) !== false ) || ( strpos( $class, 'Elementor\\Pro' ) !== false );
            $out[] = array(
                'name'       => $name,
                'title'      => method_exists( $widget, 'get_title' ) ? $widget->get_title() : $name,
                'categories' => $cats,
                'keywords'   => array_slice( $keywords, 0, 6 ),
                'is_pro'     => $is_pro,
            );
        }
        usort( $out, function( $x, $y ) { return strcmp( $x['name'], $y['name'] ); } );

        return array(
            'elementor_version' => defined( 'ELEMENTOR_VERSION' )     ? ELEMENTOR_VERSION     : null,
            'elementor_pro'     => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : false,
            'total_widgets'     => count( $out ),
            'category_filter'   => $filter ?: null,
            'note'              => 'Call get_widget_schema(widget_type) before using a widget you have not written recently. The `html` widget is server-blocked; do not use it.',
            'widgets'           => $out,
        );
    }

    private function get_widget_schema( $a ) {
        $this->require_elementor();
        $name    = sanitize_text_field( $a['widget_type'] );
        $section = isset( $a['section'] ) ? sanitize_key( $a['section'] ) : 'content';

        $widget = \Elementor\Plugin::instance()->widgets_manager->get_widget_types( $name );
        if ( ! $widget ) {
            throw new Exception( "Widget '{$name}' not found. Call list_elementor_widgets to see available types." );
        }
        if ( in_array( $name, $this->forbidden_widget_types(), true ) ) {
            throw new Exception( "Widget '{$name}' is server-blocked and cannot be used in generated pages." );
        }

        // Elementor controls are keyed on tab: 'content', 'style', 'advanced'.
        $tab_map = array(
            'content'  => 'content',
            'style'    => 'style',
            'advanced' => 'advanced',
            'all'      => null,
        );
        if ( ! array_key_exists( $section, $tab_map ) ) $section = 'content';
        $wanted_tab = $tab_map[ $section ];

        $controls = $widget->get_controls();
        $out      = array();
        foreach ( $controls as $key => $ctrl ) {
            $tab = isset( $ctrl['tab'] ) ? $ctrl['tab'] : 'content';
            if ( $wanted_tab && $tab !== $wanted_tab ) continue;
            // Skip UI-only section dividers.
            if ( isset( $ctrl['type'] ) && $ctrl['type'] === 'section' ) continue;

            $row = array(
                'key'  => $key,
                'type' => isset( $ctrl['type'] ) ? $ctrl['type'] : 'text',
            );
            if ( isset( $ctrl['label'] )   && $ctrl['label']   !== '' ) $row['label']   = wp_strip_all_tags( $ctrl['label'] );
            if ( isset( $ctrl['default'] ) )                            $row['default'] = $ctrl['default'];
            if ( ! empty( $ctrl['options'] ) && is_array( $ctrl['options'] ) ) {
                $row['options'] = array_slice( $ctrl['options'], 0, 20, true );
            }
            if ( ! empty( $ctrl['placeholder'] ) ) $row['placeholder'] = $ctrl['placeholder'];
            $out[] = $row;
        }

        return array(
            'widget_type'   => $name,
            'title'         => method_exists( $widget, 'get_title' ) ? $widget->get_title() : $name,
            'section'       => $section,
            'control_count' => count( $out ),
            'note'          => 'Use these keys inside the widget "settings" object. Never inject raw HTML or <style> tags into text fields.',
            'controls'      => $out,
        );
    }

    // =========================================================
    //  TEMPLATE LIBRARY
    // =========================================================

    private function list_templates( $a ) {
        $category = isset( $a['category'] ) ? sanitize_title( $a['category'] ) : null;
        $items    = Claude_MCP_Templates::list_all( $category, 200 );

        // Return only summary fields — don't ship full JSON in the list call.
        return array(
            'total'        => count( $items ),
            'category'     => $category,
            'admin_url'    => admin_url( 'edit.php?post_type=' . Claude_MCP_Templates::CPT ),
            'note'         => 'Call get_template(slug) to inspect one, or apply_template(page_id, slug) to add it to a page. After applying, use update_elementor_widget to swap in the user\'s copy and images.',
            'templates'    => $items,
        );
    }

    private function get_template( $a ) {
        $ref = isset( $a['template'] ) ? $a['template'] : '';
        if ( $ref === '' ) throw new Exception( 'template (slug or id) is required.' );
        $tpl = Claude_MCP_Templates::get_by_slug_or_id( $ref );
        if ( ! $tpl ) throw new Exception( "Template '{$ref}' not found. Call list_templates to see available templates." );

        // Include a size hint so the model can decide whether to fetch or apply directly.
        $tpl['size_bytes']    = strlen( wp_json_encode( $tpl['elementor_data'] ) );
        $tpl['section_count'] = count( $tpl['elementor_data'] );
        return $tpl;
    }

    private function apply_template( $a ) {
        $page_id = intval( $a['page_id'] );
        $ref     = isset( $a['template'] ) ? $a['template'] : '';
        if ( $ref === '' ) throw new Exception( 'template (slug or id) is required.' );

        $tpl = Claude_MCP_Templates::get_by_slug_or_id( $ref );
        if ( ! $tpl ) throw new Exception( "Template '{$ref}' not found. Call list_templates to see available templates." );

        $sections = $tpl['elementor_data'];
        if ( empty( $sections ) || ! is_array( $sections ) ) {
            throw new Exception( "Template '{$ref}' has no Elementor data. Edit it under Claude MCP → Templates and paste valid JSON." );
        }

        // Guard: templates can't smuggle html/shortcode widgets unless explicitly allowed.
        $this->assert_no_html_widgets( $sections, ! empty( $a['allow_html_widget'] ) );

        // Regenerate IDs on every section so the same template can be applied multiple times.
        foreach ( $sections as &$section ) {
            $section = $this->_regen_el_ids( $section );
        }
        unset( $section );

        // Append to existing page data using the same DELETE+INSERT pattern as append_elementor_section.
        global $wpdb;
        wp_cache_delete( $page_id, 'post_meta' );
        $existing_raw = $wpdb->get_var( $wpdb->prepare(
            "SELECT SQL_NO_CACHE meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data' ORDER BY meta_id DESC LIMIT 1",
            $page_id
        ) );
        $existing = array();
        if ( ! empty( $existing_raw ) ) {
            $decoded = json_decode( $existing_raw, true );
            if ( is_array( $decoded ) ) $existing = $decoded;
        }

        $merged      = array_merge( $existing, $sections );
        $merged_json = wp_json_encode( $merged, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

        $wpdb->delete( $wpdb->postmeta, array( 'post_id' => $page_id, 'meta_key' => '_elementor_data' ) );
        $wpdb->insert( $wpdb->postmeta, array( 'post_id' => $page_id, 'meta_key' => '_elementor_data', 'meta_value' => $merged_json ) );

        // Make sure Elementor knows this page is being built with it.
        update_post_meta( $page_id, '_elementor_edit_mode',     'builder' );
        update_post_meta( $page_id, '_elementor_version',       defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0' );
        update_post_meta( $page_id, '_elementor_template_type', 'wp-page' );

        wp_cache_delete( $page_id, 'post_meta' );
        clean_post_cache( $page_id );
        $this->regenerate_elementor_css( $page_id );
        $this->purge_page_cache( $page_id );

        // Collect the new top-level section IDs so the caller can customize them.
        $new_ids = array();
        foreach ( $sections as $s ) {
            if ( isset( $s['id'] ) ) $new_ids[] = $s['id'];
        }

        return array(
            'success'         => true,
            'page_id'         => $page_id,
            'template_slug'   => $tpl['slug'],
            'template_title'  => $tpl['title'],
            'sections_added'  => count( $sections ),
            'new_section_ids' => $new_ids,
            'total_sections'  => count( $merged ),
            'link'            => get_permalink( $page_id ),
            'message'         => 'Template applied. Use get_page_structure to see all widget IDs, then update_elementor_widget to swap in the user\'s copy and images.',
        );
    }

    private function save_as_template( $a ) {
        $page_id    = intval( $a['page_id'] );
        $section_id = sanitize_text_field( $a['section_id'] );
        $name       = sanitize_text_field( $a['name'] );
        $desc       = isset( $a['description'] ) ? sanitize_textarea_field( $a['description'] ) : '';
        $category   = isset( $a['category'] )    ? sanitize_title( $a['category'] )             : '';

        $raw = get_post_meta( $page_id, '_elementor_data', true );
        if ( ! $raw ) throw new Exception( "Page {$page_id} has no Elementor data." );
        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) ) throw new Exception( 'Page Elementor JSON is invalid.' );

        $section = null;
        foreach ( $data as $el ) {
            if ( isset( $el['id'] ) && $el['id'] === $section_id ) { $section = $el; break; }
        }
        if ( ! $section ) {
            throw new Exception( "Section '{$section_id}' not found on page {$page_id}. Use get_page_structure to get valid section IDs." );
        }

        $categories = $category ? array( $category ) : array();
        $post_id    = Claude_MCP_Templates::create( $name, array( $section ), $desc, $categories );

        return array(
            'success'       => true,
            'template_id'   => $post_id,
            'template_slug' => get_post_field( 'post_name', $post_id ),
            'edit_url'      => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
            'message'       => "Template '{$name}' saved. Edit it under Claude MCP → Templates.",
        );
    }

    // =========================================================
    //  ELEMENTOR — data writers (guarded)
    // =========================================================

    private function set_elementor_data( $a ) {
        $id     = intval( $a['id'] );
        $tpl    = $a['page_template'] ?? 'elementor_canvas';
        $el_ver = defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0';

        // HTML-widget guard — reject before writing.
        $decoded_check = json_decode( $a['elementor_data'], true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            throw new Exception( 'elementor_data is not valid JSON: ' . json_last_error_msg() );
        }
        $this->assert_no_html_widgets( $decoded_check, ! empty( $a['allow_html_widget'] ) );

        update_post_meta( $id, '_elementor_data',          $a['elementor_data'] );
        update_post_meta( $id, '_elementor_edit_mode',     'builder' );
        update_post_meta( $id, '_elementor_version',       $el_ver );
        update_post_meta( $id, '_elementor_template_type', 'wp-page' );
        update_post_meta( $id, '_wp_page_template',        $tpl );
        wp_update_post( array( 'ID' => $id, 'page_template' => $tpl ) );

        $this->regenerate_elementor_css( $id );
        $this->purge_page_cache( $id );

        $decoded  = json_decode( $a['elementor_data'], true );
        $sections = is_array( $decoded ) ? count( $decoded ) : 0;

        return array( 'success' => true, 'id' => $id, 'link' => get_permalink( $id ), 'section_count' => $sections, 'message' => "Elementor data set for post {$id}. {$sections} section(s). Template: {$tpl}. CSS regenerated. Cache purged." );
    }

    private function init_elementor_page( $a ) {
        $id     = intval( $a['id'] );
        $tpl    = $a['page_template'] ?? 'elementor_canvas';
        $el_ver = defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0';

        update_post_meta( $id, '_elementor_data',          '[]' );
        update_post_meta( $id, '_elementor_edit_mode',     'builder' );
        update_post_meta( $id, '_elementor_version',       $el_ver );
        update_post_meta( $id, '_elementor_template_type', 'wp-page' );
        update_post_meta( $id, '_wp_page_template',        $tpl );
        wp_update_post( array( 'ID' => $id, 'page_template' => $tpl ) );
        delete_post_meta( $id, '_elementor_css' );
        $this->purge_page_cache( $id );

        return array( 'success' => true, 'id' => $id, 'section_count' => 0, 'message' => "Page {$id} initialised for chunked Elementor build. Template: {$tpl}. Ready for append_elementor_section calls." );
    }

    private function append_elementor_section( $a ) {
        $id = intval( $a['id'] );

        $new_raw     = $a['section_data'];
        $new_decoded = json_decode( $new_raw, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            throw new Exception( 'section_data is not valid JSON: ' . json_last_error_msg() );
        }
        if ( isset( $new_decoded['elType'] ) ) {
            $new_sections = array( $new_decoded );
        } elseif ( is_array( $new_decoded ) ) {
            $new_sections = $new_decoded;
        } else {
            throw new Exception( 'section_data must be a section object or array of section objects.' );
        }

        // HTML-widget guard — reject before writing.
        $this->assert_no_html_widgets( $new_sections, ! empty( $a['allow_html_widget'] ) );

        global $wpdb;
        wp_cache_delete( $id, 'post_meta' );
        $existing_raw = $wpdb->get_var( $wpdb->prepare(
            "SELECT SQL_NO_CACHE meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data' ORDER BY meta_id DESC LIMIT 1",
            $id
        ) );
        $existing = array();
        if ( ! empty( $existing_raw ) ) {
            $decoded = json_decode( $existing_raw, true );
            if ( is_array( $decoded ) ) $existing = $decoded;
        }

        $merged      = array_merge( $existing, $new_sections );
        $merged_json = wp_json_encode( $merged, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

        // DELETE + INSERT to avoid duplicate meta rows accumulating.
        $wpdb->delete( $wpdb->postmeta, array( 'post_id' => $id, 'meta_key' => '_elementor_data' ) );
        $wpdb->insert( $wpdb->postmeta, array( 'post_id' => $id, 'meta_key' => '_elementor_data', 'meta_value' => $merged_json ) );
        wp_cache_delete( $id, 'post_meta' );
        clean_post_cache( $id );

        $total = count( $merged );
        return array( 'success' => true, 'id' => $id, 'sections_added' => count( $new_sections ), 'total_sections' => $total, 'total_size_bytes' => strlen( $merged_json ), 'message' => "Appended " . count( $new_sections ) . " section(s) to post {$id}. Total: {$total}. Call finalize_elementor_page when done." );
    }

    private function finalize_elementor_page( $a ) {
        $id = intval( $a['id'] );

        global $wpdb;
        $raw = $wpdb->get_var( $wpdb->prepare(
            "SELECT SQL_NO_CACHE meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data' ORDER BY meta_id DESC LIMIT 1",
            $id
        ) );

        $decoded  = json_decode( $raw, true );
        $sections = is_array( $decoded ) ? count( $decoded ) : 0;
        $size     = strlen( $raw ?: '' );

        if ( $size > 100 && $sections === 0 ) {
            throw new Exception( "Elementor data exists ({$size} bytes) but JSON is invalid. Check for unescaped quotes in HTML widget content." );
        }

        wp_cache_delete( $id, 'post_meta' );
        wp_cache_delete( $id, 'posts' );
        clean_post_cache( $id );

        $this->regenerate_elementor_css( $id );
        $this->purge_page_cache( $id );

        return array( 'success' => true, 'id' => $id, 'link' => get_permalink( $id ), 'section_count' => $sections, 'data_size_bytes' => $size, 'message' => "Page {$id} finalised. {$sections} section(s), {$size} bytes. CSS regenerated. Caches purged. Ready for qa_page." );
    }

    private function qa_page( $a ) {
        $id   = intval( $a['id'] );
        $post = get_post( $id );
        if ( ! $post ) throw new Exception( "Post {$id} not found." );

        $url      = get_permalink( $id );
        $response = wp_remote_get( $url, array( 'timeout' => 25, 'user-agent' => 'Claude-MCP-QA/1.0', 'headers' => array( 'Cache-Control' => 'no-cache, no-store', 'Pragma' => 'no-cache' ) ) );
        if ( is_wp_error( $response ) ) throw new Exception( 'Could not fetch page: ' . $response->get_error_message() );

        $http_status = wp_remote_retrieve_response_code( $response );
        $html        = wp_remote_retrieve_body( $response );
        $body_html   = '';
        if ( preg_match( '/<body[^>]*>(.*?)<\/body>/si', $html, $bm ) ) $body_html = $bm[1];
        $visible_text = trim( strip_tags( $body_html ) );
        $is_blank     = strlen( $visible_text ) < 50;

        $page_title = '';
        if ( preg_match( '/<title[^>]*>(.*?)<\/title>/si', $html, $tm ) ) $page_title = html_entity_decode( trim( strip_tags( $tm[1] ) ) );

        $elementor_sections   = substr_count( $html, 'elementor-top-section' );
        $elementor_containers = substr_count( $html, 'e-con-inner' );

        preg_match_all( '/elementor-widget-([\w-]+)/', $html, $wm );
        $widget_counts = array();
        foreach ( $wm[1] as $wt ) {
            if ( in_array( $wt, array( 'wrap', 'container', 'inner' ) ) ) continue;
            $widget_counts[ $wt ] = ( $widget_counts[ $wt ] ?? 0 ) + 1;
        }
        arsort( $widget_counts );

        $headings = array();
        preg_match_all( '/<h([1-4])[^>]*>(.*?)<\/h\1>/si', $html, $hm );
        foreach ( $hm[2] as $i => $htxt ) {
            $clean = trim( html_entity_decode( strip_tags( $htxt ) ) );
            if ( $clean !== '' ) $headings[] = 'H' . $hm[1][ $i ] . ': ' . $clean;
        }
        $headings = array_slice( $headings, 0, 30 );

        $no_scripts   = preg_replace( '/<(script|style)[^>]*>.*?<\/\1>/si', '', $body_html );
        $text_snippet = substr( trim( preg_replace( '/\s+/', ' ', html_entity_decode( strip_tags( $no_scripts ) ) ) ), 0, 600 );

        preg_match_all( '/background(?:-color)?\s*:\s*(#[0-9a-fA-F]{3,8}|rgba?\([^)]+\))/i', $html, $bgm );
        $bg_colors = array_slice( array_values( array_unique( $bgm[1] ) ), 0, 20 );

        $buttons = array();
        preg_match_all( '/<(?:a|button)[^>]*>(.*?)<\/(?:a|button)>/si', $html, $btnm );
        foreach ( $btnm[1] as $btxt ) {
            $clean = trim( html_entity_decode( strip_tags( $btxt ) ) );
            if ( $clean !== '' && strlen( $clean ) < 80 ) $buttons[] = $clean;
        }
        $buttons = array_slice( array_values( array_unique( $buttons ) ), 0, 20 );

        preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $html, $imgm );
        $images_found = count( $imgm[1] );

        $expected       = $a['expected_sections'] ?? array();
        $found_expected = array();
        $missing        = array();
        foreach ( $expected as $needle ) {
            if ( stripos( $html, $needle ) !== false ) $found_expected[] = $needle;
            else $missing[] = $needle;
        }

        $issues = array();
        if ( $http_status !== 200 ) $issues[] = "HTTP {$http_status}: page did not return 200 OK.";
        if ( $is_blank ) $issues[] = 'BLANK PAGE: body is empty. Check _elementor_edit_mode=builder, valid JSON, and elementor_canvas template.';
        if ( ! $is_blank && $elementor_sections === 0 && $elementor_containers === 0 ) $issues[] = 'No Elementor sections or containers rendered.';
        if ( empty( $headings ) && ! $is_blank ) $issues[] = 'No H1-H4 headings found on page.';
        foreach ( $missing as $m ) $issues[] = "Expected text not found: \"{$m}\"";

        $qa_passed  = empty( $issues );
        $qa_summary = $qa_passed
            ? "PASS — {$elementor_sections} section(s), " . count( $widget_counts ) . " widget type(s), " . count( $headings ) . " heading(s), {$images_found} image(s). All expected content present."
            : "FAIL — " . count( $issues ) . " issue(s): " . implode( ' | ', $issues );

        return array( 'page_title' => $page_title, 'url' => $url, 'http_status' => $http_status, 'is_blank' => $is_blank, 'elementor_sections' => $elementor_sections, 'elementor_widgets' => $widget_counts, 'images_found' => $images_found, 'headings' => $headings, 'text_snippet' => $text_snippet, 'background_colors' => $bg_colors, 'buttons' => $buttons, 'expected_sections' => $expected, 'found_expected' => $found_expected, 'missing_expected' => $missing, 'issues' => $issues, 'qa_passed' => $qa_passed, 'qa_summary' => $qa_summary );
    }

    // =========================================================
    //  PRIVATE HELPERS
    // =========================================================

    private function regenerate_elementor_css( $id ) {
        delete_post_meta( $id, '_elementor_css' );
        if ( ! class_exists( '\Elementor\Plugin' ) ) return;
        try {
            $el = \Elementor\Plugin::$instance;
            wp_cache_delete( $id, 'post_meta' );
            clean_post_cache( $id );
            if ( isset( $el->documents ) && method_exists( $el->documents, 'clear_cache' ) ) {
                $el->documents->clear_cache();
            }
            if ( isset( $el->posts_css_manager ) ) {
                $css = $el->posts_css_manager->get_post_css( $id );
                if ( $css && method_exists( $css, 'update' ) ) {
                    $css->update();
                    if ( isset( $el->files_manager ) ) $el->files_manager->clear_cache();
                    return;
                }
            }
            if ( method_exists( $el, 'get_component' ) ) {
                $assets = $el->get_component( 'assets-manager' );
                if ( $assets && method_exists( $assets, 'clear_cache' ) ) $assets->clear_cache();
            }
            if ( isset( $el->files_manager ) ) $el->files_manager->clear_cache();
            if ( isset( $el->documents ) ) {
                $document = $el->documents->get( $id, false );
                if ( $document && method_exists( $document, 'save' ) ) {
                    @set_time_limit( 120 );
                    $document->save( array() );
                }
            }
        } catch ( \Exception $e ) {
            error_log( 'Claude MCP: CSS regen failed for post ' . $id . ': ' . $e->getMessage() );
        }
    }

    private function purge_page_cache( $id ) {
        $url = get_permalink( $id );

        do_action( 'litespeed_purge_post', $id );
        do_action( 'litespeed_purge_url',  $url );
        if ( function_exists( 'rocket_clean_post' ) )    rocket_clean_post( $id );
        if ( function_exists( 'w3tc_flush_post' ) )      w3tc_flush_post( $id );
        if ( function_exists( 'wp_cache_post_change' ) ) wp_cache_post_change( $id );
        if ( function_exists( 'wpsc_delete_post_cache' ) ) wpsc_delete_post_cache( $id );
        // WpFastestCache wrapped in try/catch — constructor can throw on some hosts.
        if ( class_exists( 'WpFastestCache' ) && method_exists( 'WpFastestCache', 'deleteCache' ) ) {
            try { ( new WpFastestCache() )->deleteCache( true ); } catch ( \Exception $e ) {}
        }
        do_action( 'kinsta_cache_purge_post', $id );
        if ( function_exists( 'sg_cachepress_purge_cache' ) ) sg_cachepress_purge_cache();
        do_action( 'rt_nginx_helper_purge_url', $url );
        do_action( 'cloudflare_purge_by_url', array( $url ) );
        if ( class_exists( 'autoptimizeCache' ) ) autoptimizeCache::clearall();
        wp_cache_delete( $id, 'posts' );
        wp_cache_delete( $id, 'post_meta' );
        clean_post_cache( $id );
    }

    // =========================================================
    //  PLUGIN & THEME MANAGEMENT
    // =========================================================

    private function list_plugins( $a ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $all    = get_plugins();
        $active = get_option( 'active_plugins', array() );
        $filter = $a['status'] ?? 'all';
        $list   = array();
        foreach ( $all as $file => $data ) {
            $is_active = in_array( $file, $active );
            if ( $filter === 'active'   && ! $is_active ) continue;
            if ( $filter === 'inactive' &&   $is_active ) continue;
            $list[] = array( 'plugin_file' => $file, 'name' => $data['Name'], 'version' => $data['Version'], 'description' => $data['Description'], 'author' => $data['Author'], 'status' => $is_active ? 'active' : 'inactive' );
        }
        return array( 'total' => count( $list ), 'plugins' => $list );
    }

    private function install_plugin( $a ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';

        // Initialize WP_Filesystem — required on shared/managed hosts, otherwise install silently fails.
        if ( ! function_exists( 'WP_Filesystem' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        WP_Filesystem();

        $slug = sanitize_key( $a['slug'] );
        $api  = plugins_api( 'plugin_information', array( 'slug' => $slug, 'fields' => array( 'short_description' => true ) ) );
        if ( is_wp_error( $api ) ) throw new Exception( 'Plugin not found: ' . $api->get_error_message() );

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );
        $result   = $upgrader->install( $api->download_link );
        if ( is_wp_error( $result ) ) throw new Exception( 'Install failed: ' . $result->get_error_message() );
        if ( $result === false || $result === null ) {
            $errors = $skin->get_errors();
            $msg    = is_wp_error( $errors ) ? $errors->get_error_message() : 'Unknown filesystem error — check WP_Filesystem credentials or file permissions.';
            throw new Exception( 'Install failed: ' . $msg );
        }

        $plugin_file = $upgrader->plugin_info();
        $activated   = false;
        if ( ! empty( $a['activate'] ) && $plugin_file ) {
            $act       = activate_plugin( $plugin_file );
            $activated = ! is_wp_error( $act );
        }
        return array( 'success' => true, 'plugin_file' => $plugin_file, 'name' => $api->name, 'version' => $api->version, 'activated' => $activated, 'message' => "Plugin \"{$api->name}\" installed." . ( $activated ? ' Activated.' : '' ) );
    }

    private function activate_plugin( $a ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $result = activate_plugin( $a['plugin_file'] );
        if ( is_wp_error( $result ) ) throw new Exception( 'Activation failed: ' . $result->get_error_message() );
        return array( 'success' => true, 'plugin_file' => $a['plugin_file'], 'message' => "Plugin \"{$a['plugin_file']}\" activated." );
    }

    private function deactivate_plugin( $a ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        deactivate_plugins( $a['plugin_file'] );
        return array( 'success' => true, 'plugin_file' => $a['plugin_file'], 'message' => "Plugin \"{$a['plugin_file']}\" deactivated." );
    }

    private function list_themes() {
        $active = get_stylesheet();
        $themes = array();
        foreach ( wp_get_themes() as $slug => $theme ) {
            $themes[] = array( 'slug' => $slug, 'name' => $theme->get( 'Name' ), 'version' => $theme->get( 'Version' ), 'description' => $theme->get( 'Description' ), 'author' => $theme->get( 'Author' ), 'status' => ( $slug === $active ) ? 'active' : 'inactive' );
        }
        return array( 'total' => count( $themes ), 'active_theme' => $active, 'themes' => $themes );
    }

    private function install_theme( $a ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/theme-install.php';

        // Initialize WP_Filesystem.
        WP_Filesystem();

        $slug = sanitize_key( $a['slug'] );
        $api  = themes_api( 'theme_information', array( 'slug' => $slug, 'fields' => array( 'description' => true ) ) );
        if ( is_wp_error( $api ) ) throw new Exception( 'Theme not found: ' . $api->get_error_message() );

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Theme_Upgrader( $skin );
        $result   = $upgrader->install( $api->download_link );
        if ( is_wp_error( $result ) ) throw new Exception( 'Install failed: ' . $result->get_error_message() );
        if ( $result === false || $result === null ) {
            $errors = $skin->get_errors();
            $msg    = is_wp_error( $errors ) ? $errors->get_error_message() : 'Unknown filesystem error.';
            throw new Exception( 'Install failed: ' . $msg );
        }

        $activated = false;
        if ( ! empty( $a['activate'] ) ) {
            switch_theme( $slug );
            $activated = ( get_stylesheet() === $slug );
        }
        return array( 'success' => true, 'slug' => $slug, 'name' => $api->name, 'activated' => $activated, 'message' => "Theme \"{$api->name}\" installed." . ( $activated ? ' Activated.' : '' ) );
    }

    private function activate_theme( $a ) {
        $slug  = sanitize_key( $a['slug'] );
        $theme = wp_get_theme( $slug );
        if ( ! $theme->exists() ) throw new Exception( "Theme \"{$slug}\" is not installed." );
        switch_theme( $slug );
        if ( get_stylesheet() !== $slug ) throw new Exception( "Failed to activate theme \"{$slug}\"." );
        return array( 'success' => true, 'slug' => $slug, 'name' => $theme->get( 'Name' ), 'message' => "Theme \"{$theme->get('Name')}\" activated." );
    }

// =========================================================
    //  V27 NEW TOOLS
    // =========================================================

    private function get_scheduled_posts( $a ) {
        $post_type = isset( $a['post_type'] ) ? $a['post_type'] : 'post';
        $per_page  = isset( $a['per_page'] )  ? intval( $a['per_page'] ) : 20;
        $q    = new WP_Query( array( 'post_type' => $post_type, 'post_status' => 'future', 'posts_per_page' => $per_page, 'orderby' => 'date', 'order' => 'ASC' ) );
        $posts = array();
        foreach ( $q->posts as $p ) {
            $posts[] = array( 'id' => $p->ID, 'title' => $p->post_title, 'scheduled_date' => $p->post_date, 'slug' => $p->post_name );
        }
        return array( 'total' => $q->found_posts, 'posts' => $posts );
    }

    // ── Menus ──────────────────────────────────────────────────

    private function get_menus() {
        $locations    = get_nav_menu_locations();
        $location_map = array_flip( $locations );
        $all_menus    = wp_get_nav_menus();
        $result       = array();
        foreach ( $all_menus as $menu ) {
            $items_raw = wp_get_nav_menu_items( $menu->term_id );
            $items     = array();
            if ( is_array( $items_raw ) ) {
                foreach ( $items_raw as $item ) {
                    $items[] = array(
                        'id'        => $item->ID,
                        'title'     => $item->title,
                        'url'       => $item->url,
                        'target'    => $item->target,
                        'parent_id' => (int) $item->menu_item_parent,
                        'order'     => $item->menu_order,
                    );
                }
            }
            $loc = isset( $location_map[ $menu->term_id ] ) ? $location_map[ $menu->term_id ] : null;
            $result[] = array( 'id' => $menu->term_id, 'name' => $menu->name, 'slug' => $menu->slug, 'location' => $loc, 'items' => $items );
        }
        return array( 'menus' => $result, 'registered_locations' => array_keys( get_registered_nav_menus() ) );
    }

    private function create_menu( $a ) {
        $id = wp_create_nav_menu( sanitize_text_field( $a['name'] ) );
        if ( is_wp_error( $id ) ) { throw new Exception( $id->get_error_message() ); }
        if ( ! empty( $a['location'] ) ) {
            $locs = get_theme_mod( 'nav_menu_locations', array() );
            $locs[ sanitize_key( $a['location'] ) ] = $id;
            set_theme_mod( 'nav_menu_locations', $locs );
        }
        return array( 'success' => true, 'id' => $id, 'message' => "Menu '{$a['name']}' created." );
    }

    private function update_menu( $a ) {
        $menu_id  = intval( $a['menu_id'] );
        $items    = isset( $a['items'] ) ? $a['items'] : array();
        $existing = wp_get_nav_menu_items( $menu_id );
        if ( is_array( $existing ) ) {
            foreach ( $existing as $item ) { wp_delete_post( $item->ID, true ); }
        }
        $id_map = array();
        $added  = array();
        foreach ( $items as $idx => $item ) {
            $parent_db_id = 0;
            if ( ! empty( $item['parent_id'] ) && isset( $id_map[ $item['parent_id'] ] ) ) {
                $parent_db_id = $id_map[ $item['parent_id'] ];
            }
            $title  = isset( $item['title'] )  ? sanitize_text_field( $item['title'] )  : '';
            $url    = isset( $item['url'] )    ? esc_url_raw( $item['url'] )            : '#';
            $target = isset( $item['target'] ) ? $item['target']                        : '';
            $item_id = wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'     => $title,
                'menu-item-url'       => $url,
                'menu-item-status'    => 'publish',
                'menu-item-position'  => $idx + 1,
                'menu-item-parent-id' => $parent_db_id,
                'menu-item-target'    => $target,
            ) );
            if ( ! is_wp_error( $item_id ) ) {
                $id_map[ $idx ] = $item_id;
                $added[] = array( 'index' => $idx, 'id' => $item_id, 'title' => $title );
            }
        }
        return array( 'success' => true, 'menu_id' => $menu_id, 'items_added' => count( $added ), 'message' => 'Menu updated with ' . count( $added ) . ' item(s).' );
    }

    // ── Customizer ─────────────────────────────────────────────

    private function get_customizer_settings() {
        $mods = get_theme_mods();
        return array( 'theme' => get_stylesheet(), 'mods' => $mods ? $mods : new stdClass() );
    }

    private function update_customizer_settings( $a ) {
        $mods    = isset( $a['mods'] ) ? $a['mods'] : array();
        $updated = array();
        foreach ( $mods as $key => $value ) {
            set_theme_mod( sanitize_key( $key ), $value );
            $updated[] = $key;
        }
        return array( 'success' => true, 'updated' => $updated, 'message' => count( $updated ) . ' theme mod(s) updated.' );
    }

    // ── Theme Files ────────────────────────────────────────────

    private function resolve_theme_path( $path, $theme_slug ) {
        $slug      = $theme_slug ? sanitize_key( $theme_slug ) : get_stylesheet();
        $theme_dir = WP_CONTENT_DIR . '/themes/' . $slug;
        if ( ! is_dir( $theme_dir ) ) { throw new Exception( "Theme '{$slug}' not found." ); }
        $real_base = realpath( $theme_dir );
        $full      = $theme_dir . '/' . ltrim( $path, '/' );
        $real_dir  = realpath( dirname( $full ) );
        if ( $real_dir === false || strpos( $real_dir, $real_base ) !== 0 ) {
            throw new Exception( 'Path traversal detected.' );
        }
        return $full;
    }

    private function read_theme_file( $a ) {
        $slug = isset( $a['theme_slug'] ) ? $a['theme_slug'] : null;
        $full = $this->resolve_theme_path( $a['path'], $slug );
        if ( ! file_exists( $full ) ) { throw new Exception( 'File not found: ' . $a['path'] ); }
        $content = file_get_contents( $full );
        return array( 'path' => $a['path'], 'content' => $content, 'size_bytes' => strlen( $content ), 'lines' => substr_count( $content, "\n" ) + 1 );
    }

    private function write_theme_file( $a ) {
        $slug = isset( $a['theme_slug'] ) ? $a['theme_slug'] : null;
        $full = $this->resolve_theme_path( $a['path'], $slug );
        if ( file_exists( $full ) ) { copy( $full, $full . '.bak' ); }
        $dir = dirname( $full );
        if ( ! is_dir( $dir ) ) { wp_mkdir_p( $dir ); }
        $bytes = file_put_contents( $full, $a['content'] );
        if ( $bytes === false ) { throw new Exception( 'Failed to write ' . $a['path'] . '. Check permissions.' ); }
        return array( 'success' => true, 'path' => $a['path'], 'bytes_written' => $bytes, 'backup_created' => file_exists( $full . '.bak' ) );
    }

    // ── Plugin Files ───────────────────────────────────────────

    private function resolve_plugin_path( $plugin_slug, $path ) {
        // Allow spaces and mixed case (e.g. 'Claude MCP') — only strip dangerous chars
        $slug       = preg_replace( '/[^a-zA-Z0-9\-_ ]/', '', $plugin_slug );
        $plugin_dir = WP_PLUGIN_DIR . '/' . $slug;
        if ( ! is_dir( $plugin_dir ) ) { throw new Exception( "Plugin '{$slug}' not found." ); }
        $real_base  = realpath( $plugin_dir );
        if ( empty( $path ) ) { return $plugin_dir; }
        $full      = $plugin_dir . '/' . ltrim( $path, '/' );
        $real_dir  = realpath( dirname( $full ) );
        if ( $real_dir === false || strpos( $real_dir, $real_base ) !== 0 ) {
            throw new Exception( 'Path traversal detected.' );
        }
        return $full;
    }

    private function read_plugin_file( $a ) {
        $full = $this->resolve_plugin_path( $a['plugin_slug'], $a['path'] );
        if ( ! file_exists( $full ) ) { throw new Exception( 'File not found: ' . $a['path'] ); }
        $content = file_get_contents( $full );
        return array( 'plugin_slug' => $a['plugin_slug'], 'path' => $a['path'], 'content' => $content, 'size_bytes' => strlen( $content ), 'lines' => substr_count( $content, "\n" ) + 1 );
    }

    private function write_plugin_file( $a ) {
        $full = $this->resolve_plugin_path( $a['plugin_slug'], $a['path'] );
        if ( file_exists( $full ) ) { copy( $full, $full . '.bak' ); }
        $dir = dirname( $full );
        if ( ! is_dir( $dir ) ) { wp_mkdir_p( $dir ); }
        $bytes = file_put_contents( $full, $a['content'] );
        if ( $bytes === false ) { throw new Exception( 'Failed to write. Check permissions.' ); }
        return array( 'success' => true, 'plugin_slug' => $a['plugin_slug'], 'path' => $a['path'], 'bytes_written' => $bytes, 'backup_created' => file_exists( $full . '.bak' ) );
    }

    private function list_plugin_files( $a ) {
        $base     = $this->resolve_plugin_path( $a['plugin_slug'], '' );
        $ext_filter = isset( $a['ext'] ) ? strtolower( $a['ext'] ) : null;
        $iter  = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base, RecursiveDirectoryIterator::SKIP_DOTS ) );
        $files = array();
        foreach ( $iter as $file ) {
            if ( ! $file->isFile() ) { continue; }
            if ( $ext_filter && strtolower( $file->getExtension() ) !== $ext_filter ) { continue; }
            $rel     = str_replace( $base . DIRECTORY_SEPARATOR, '', $file->getPathname() );
            $files[] = array( 'path' => $rel, 'size_bytes' => $file->getSize(), 'ext' => $file->getExtension() );
        }
        usort( $files, array( $this, '_sort_by_path' ) );
        // Cap at 200 files to stay under response limit — use ext param to filter
        $total   = count( $files );
        $limited = array_slice( $files, 0, 200 );
        return array( 'plugin_slug' => $a['plugin_slug'], 'total_files' => $total, 'showing' => count( $limited ), 'note' => $total > 200 ? "Showing 200 of {$total} files. Use ext param (e.g. ext=php) to filter." : null, 'files' => $limited );
    }

    public function _sort_by_path( $a, $b ) {
        return strcmp( $a['path'], $b['path'] );
    }

    // ── ACF ────────────────────────────────────────────────────

    private function acf_require() {
        if ( ! function_exists( 'get_field' ) ) { throw new Exception( 'ACF is not active on this site.' ); }
    }

    private function get_acf_fields( $a ) {
        $this->acf_require();
        $post_id = intval( $a['post_id'] );
        $raw     = get_fields( $post_id );
        return array( 'post_id' => $post_id, 'fields' => $raw ? $raw : new stdClass() );
    }

    private function update_acf_fields( $a ) {
        $this->acf_require();
        $post_id = intval( $a['post_id'] );
        $fields  = isset( $a['fields'] ) ? $a['fields'] : array();
        $updated = array();
        foreach ( $fields as $key => $value ) {
            update_field( $key, $value, $post_id );
            $updated[] = $key;
        }
        return array( 'success' => true, 'post_id' => $post_id, 'updated_fields' => $updated );
    }

    private function get_acf_field_groups() {
        $this->acf_require();
        $groups = acf_get_field_groups();
        $result = array();
        foreach ( $groups as $group ) {
            $fields_raw = acf_get_fields( $group['key'] );
            $fields     = array();
            if ( is_array( $fields_raw ) ) {
                foreach ( $fields_raw as $f ) {
                    $fields[] = array( 'key' => $f['key'], 'name' => $f['name'], 'label' => $f['label'], 'type' => $f['type'] );
                }
            }
            $result[] = array( 'key' => $group['key'], 'title' => $group['title'], 'active' => $group['active'], 'fields' => $fields );
        }
        return array( 'field_groups' => $result );
    }

    // ── Diagnostics ────────────────────────────────────────────

    private function get_error_log( $a ) {
        $limit  = min( intval( isset( $a['lines'] ) ? $a['lines'] : 50 ), 500 );
        $filter = isset( $a['filter'] ) ? $a['filter'] : '';
        $candidates = array( WP_CONTENT_DIR . '/debug.log', ini_get( 'error_log' ) );
        $log_file   = null;
        foreach ( $candidates as $c ) {
            if ( $c && file_exists( $c ) && is_readable( $c ) ) { $log_file = $c; break; }
        }
        if ( ! $log_file ) {
            return array( 'found' => false, 'message' => 'No readable log file. Enable WP_DEBUG_LOG in wp-config.php.' );
        }
        $file = new SplFileObject( $log_file, 'r' );
        $file->seek( PHP_INT_MAX );
        $total = $file->key();
        $start = max( 0, $total - $limit * 4 );
        $lines = array();
        $file->seek( $start );
        while ( ! $file->eof() ) {
            $line = rtrim( $file->current() );
            $file->next();
            if ( $line === '' ) { continue; }
            if ( $filter && stripos( $line, $filter ) === false ) { continue; }
            $lines[] = $line;
        }
        $lines = array_reverse( array_slice( $lines, -$limit ) );
        return array( 'log_file' => $log_file, 'total_lines' => $total, 'lines_returned' => count( $lines ), 'filter' => $filter ? $filter : null, 'lines' => $lines );
    }

    private function audit_seo( $a ) {
        $post_type = isset( $a['post_type'] ) ? $a['post_type'] : 'post';
        $per_page  = isset( $a['per_page'] )  ? intval( $a['per_page'] ) : 20;
        $status    = isset( $a['status'] )    ? $a['status']             : 'publish';
        $q      = new WP_Query( array( 'post_type' => $post_type, 'post_status' => $status, 'posts_per_page' => $per_page ) );
        $report = array();
        foreach ( $q->posts as $p ) {
            $issues = array();
            $mt = get_post_meta( $p->ID, '_yoast_wpseo_title', true );
            if ( ! $mt ) { $mt = get_post_meta( $p->ID, 'rank_math_title', true ); }
            $md = get_post_meta( $p->ID, '_yoast_wpseo_metadesc', true );
            if ( ! $md ) { $md = get_post_meta( $p->ID, 'rank_math_description', true ); }
            if ( ! $mt )                  { $issues[] = 'Missing meta title'; }
            elseif ( strlen( $mt ) > 60 ) { $issues[] = 'Meta title too long (' . strlen( $mt ) . ' chars)'; }
            elseif ( strlen( $mt ) < 30 ) { $issues[] = 'Meta title too short (' . strlen( $mt ) . ' chars)'; }
            if ( ! $md )                  { $issues[] = 'Missing meta description'; }
            elseif ( strlen( $md ) > 160 ){ $issues[] = 'Meta desc too long (' . strlen( $md ) . ' chars)'; }
            $thumb_id = get_post_thumbnail_id( $p->ID );
            if ( $thumb_id ) {
                $alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
                if ( ! $alt ) { $issues[] = 'Featured image missing alt text'; }
            } else {
                $issues[] = 'No featured image';
            }
            $wc = str_word_count( wp_strip_all_tags( $p->post_content ) );
            if ( $wc < 300 ) { $issues[] = 'Thin content (' . $wc . ' words)'; }
            if ( stripos( $p->post_content, '<h1' ) === false && stripos( $p->post_content, '<h2' ) === false ) {
                $issues[] = 'No headings in content';
            }
            $report[] = array(
                'id'         => $p->ID,
                'title'      => $p->post_title,
                'url'        => get_permalink( $p->ID ),
                'word_count' => $wc,
                'meta_title' => $mt ? $mt : null,
                'meta_desc'  => $md ? $md : null,
                'score'      => max( 0, 100 - count( $issues ) * 15 ),
                'issues'     => $issues,
                'pass'       => empty( $issues ),
            );
        }
        usort( $report, array( $this, '_sort_by_score' ) );
        $fail = array();
        foreach ( $report as $r ) { if ( ! $r['pass'] ) { $fail[] = $r; } }
        return array( 'total' => count( $report ), 'passing' => count( $report ) - count( $fail ), 'failing' => count( $fail ), 'posts' => $report );
    }

    public function _sort_by_score( $a, $b ) {
        return $a['score'] - $b['score'];
    }

    private function get_broken_links( $a ) {
        $post_type = isset( $a['post_type'] ) ? $a['post_type'] : 'post';
        $per_page  = isset( $a['per_page'] )  ? intval( $a['per_page'] ) : 10;
        $q       = new WP_Query( array( 'post_type' => $post_type, 'post_status' => 'publish', 'posts_per_page' => $per_page ) );
        $results = array();
        foreach ( $q->posts as $p ) {
            preg_match_all( '/<a[^>]+href=["\']([^"\'#][^"\']*)["\'][^>]*>/i', $p->post_content, $m );
            $broken = array();
            foreach ( array_unique( $m[1] ) as $url ) {
                if ( strpos( $url, 'http' ) !== 0 ) { continue; }
                $resp = wp_remote_head( $url, array( 'timeout' => 8, 'redirection' => 3 ) );
                $code = is_wp_error( $resp ) ? 0 : wp_remote_retrieve_response_code( $resp );
                if ( $code === 0 || $code >= 400 ) { $broken[] = array( 'url' => $url, 'status' => $code ); }
            }
            if ( ! empty( $broken ) ) {
                $results[] = array( 'post_id' => $p->ID, 'title' => $p->post_title, 'url' => get_permalink( $p->ID ), 'broken_links' => $broken );
            }
        }
        return array( 'posts_scanned' => $q->post_count, 'posts_with_broken_links' => count( $results ), 'results' => $results );
    }

    // ── Utilities ──────────────────────────────────────────────

    private function send_email( $a ) {
        $headers = array();
        if ( ! empty( $a['is_html'] ) ) { $headers[] = 'Content-Type: text/html; charset=UTF-8'; }
        $sent = wp_mail( sanitize_email( $a['to'] ), sanitize_text_field( $a['subject'] ), $a['message'], $headers );
        return array( 'success' => $sent, 'to' => $a['to'], 'message' => $sent ? 'Email sent.' : 'wp_mail() returned false. Check mail config.' );
    }

    private function backup_post( $a ) {
        $id   = intval( $a['id'] );
        $post = get_post( $id );
        if ( ! $post ) { throw new Exception( 'Post ' . $id . ' not found.' ); }
        $backup_id = 'bak_' . time() . '_' . substr( md5( rand() ), 0, 6 );
        $snapshot  = array(
            'backup_id'      => $backup_id,
            'created'        => date( 'Y-m-d H:i:s' ),
            'note'           => sanitize_text_field( isset( $a['note'] ) ? $a['note'] : '' ),
            'post_title'     => $post->post_title,
            'post_content'   => $post->post_content,
            'post_status'    => $post->post_status,
            'elementor_data' => get_post_meta( $id, '_elementor_data', true ),
            'page_template'  => get_post_meta( $id, '_wp_page_template', true ),
        );
        $all = get_post_meta( $id, '_claude_mcp_backups', true );
        if ( ! is_array( $all ) ) { $all = array(); }
        $all[ $backup_id ] = $snapshot;
        if ( count( $all ) > 10 ) { $all = array_slice( $all, -10, null, true ); }
        update_post_meta( $id, '_claude_mcp_backups', $all );
        return array( 'success' => true, 'backup_id' => $backup_id, 'created' => $snapshot['created'] );
    }

    private function restore_post( $a ) {
        $id        = intval( $a['id'] );
        $backup_id = sanitize_text_field( $a['backup_id'] );
        $all       = get_post_meta( $id, '_claude_mcp_backups', true );
        if ( ! is_array( $all ) || ! isset( $all[ $backup_id ] ) ) {
            throw new Exception( "Backup '{$backup_id}' not found for post {$id}." );
        }
        $snap = $all[ $backup_id ];
        wp_update_post( array( 'ID' => $id, 'post_title' => $snap['post_title'], 'post_content' => $snap['post_content'], 'post_status' => $snap['post_status'] ) );
        if ( ! empty( $snap['elementor_data'] ) ) {
            update_post_meta( $id, '_elementor_data', $snap['elementor_data'] );
            update_post_meta( $id, '_elementor_edit_mode', 'builder' );
            $this->regenerate_elementor_css( $id );
        }
        if ( ! empty( $snap['page_template'] ) ) { update_post_meta( $id, '_wp_page_template', $snap['page_template'] ); }
        $this->purge_page_cache( $id );
        return array( 'success' => true, 'backup_id' => $backup_id, 'restored_from' => $snap['created'], 'link' => get_permalink( $id ) );
    }

    private function list_backups( $a ) {
        $id  = intval( $a['id'] );
        $all = get_post_meta( $id, '_claude_mcp_backups', true );
        if ( ! is_array( $all ) ) { $all = array(); }
        $list = array();
        foreach ( $all as $bak ) {
            $list[] = array( 'backup_id' => $bak['backup_id'], 'created' => $bak['created'], 'note' => $bak['note'], 'has_elementor' => ! empty( $bak['elementor_data'] ) );
        }
        return array( 'post_id' => $id, 'total' => count( $list ), 'backups' => array_reverse( $list ) );
    }

    // ── Elementor New ──────────────────────────────────────────

    private function update_elementor_widget( $a ) {
        $page_id   = intval( $a['page_id'] );
        $widget_id = sanitize_text_field( $a['widget_id'] );
        $settings  = isset( $a['settings'] ) ? $a['settings'] : array();
        global $wpdb;
        wp_cache_delete( $page_id, 'post_meta' );
        $raw = $wpdb->get_var( $wpdb->prepare( "SELECT SQL_NO_CACHE meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data' ORDER BY meta_id DESC LIMIT 1", $page_id ) );
        if ( ! $raw ) { throw new Exception( 'No Elementor data on page ' . $page_id . '.' ); }
        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) ) { throw new Exception( 'Elementor JSON is invalid.' ); }
        $found = false;
        $data  = $this->_walk_el_tree( $data, $widget_id, $settings, $found );
        if ( ! $found ) { throw new Exception( "Widget '{$widget_id}' not found. Use get_page_structure to get valid IDs." ); }
        $new_json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $wpdb->delete( $wpdb->postmeta, array( 'post_id' => $page_id, 'meta_key' => '_elementor_data' ) );
        $wpdb->insert( $wpdb->postmeta, array( 'post_id' => $page_id, 'meta_key' => '_elementor_data', 'meta_value' => $new_json ) );
        wp_cache_delete( $page_id, 'post_meta' );
        clean_post_cache( $page_id );
        $this->regenerate_elementor_css( $page_id );
        $this->purge_page_cache( $page_id );
        return array( 'success' => true, 'page_id' => $page_id, 'widget_id' => $widget_id, 'settings_updated' => array_keys( $settings ) );
    }

    private function _walk_el_tree( $elements, $target_id, $settings, &$found ) {
        foreach ( $elements as &$el ) {
            if ( isset( $el['id'] ) && $el['id'] === $target_id ) {
                $existing       = isset( $el['settings'] ) ? $el['settings'] : array();
                $el['settings'] = array_merge( $existing, $settings );
                $found = true;
                return $elements;
            }
            if ( ! empty( $el['elements'] ) ) {
                $el['elements'] = $this->_walk_el_tree( $el['elements'], $target_id, $settings, $found );
                if ( $found ) { return $elements; }
            }
        }
        return $elements;
    }

    private function copy_elementor_section( $a ) {
        $src_id    = intval( $a['source_page_id'] );
        $target_id = intval( $a['target_page_id'] );
        $sec_id    = sanitize_text_field( $a['section_id'] );
        $regen_ids = ! isset( $a['regenerate_ids'] ) || $a['regenerate_ids'];
        $raw_src   = get_post_meta( $src_id, '_elementor_data', true );
        if ( ! $raw_src ) { throw new Exception( 'No Elementor data on source page ' . $src_id . '.' ); }
        $src_data = json_decode( $raw_src, true );
        if ( ! is_array( $src_data ) ) { throw new Exception( 'Source Elementor JSON is invalid.' ); }
        $section = null;
        foreach ( $src_data as $el ) {
            if ( isset( $el['id'] ) && $el['id'] === $sec_id ) { $section = $el; break; }
        }
        if ( ! $section ) { throw new Exception( "Section '{$sec_id}' not found on page {$src_id}." ); }

        // HTML-widget guard — reject copying sections that contain html/shortcode widgets.
        $this->assert_no_html_widgets( array( $section ), ! empty( $a['allow_html_widget'] ) );

        if ( $regen_ids ) { $section = $this->_regen_el_ids( $section ); }
        global $wpdb;
        wp_cache_delete( $target_id, 'post_meta' );
        $raw_target  = $wpdb->get_var( $wpdb->prepare( "SELECT SQL_NO_CACHE meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data' ORDER BY meta_id DESC LIMIT 1", $target_id ) );
        $target_data = array();
        if ( $raw_target ) { $d = json_decode( $raw_target, true ); if ( is_array( $d ) ) { $target_data = $d; } }
        $target_data[] = $section;
        $new_json = wp_json_encode( $target_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $wpdb->delete( $wpdb->postmeta, array( 'post_id' => $target_id, 'meta_key' => '_elementor_data' ) );
        $wpdb->insert( $wpdb->postmeta, array( 'post_id' => $target_id, 'meta_key' => '_elementor_data', 'meta_value' => $new_json ) );
        wp_cache_delete( $target_id, 'post_meta' );
        clean_post_cache( $target_id );
        $this->regenerate_elementor_css( $target_id );
        $this->purge_page_cache( $target_id );
        return array( 'success' => true, 'source_page_id' => $src_id, 'target_page_id' => $target_id, 'new_section_id' => $section['id'], 'ids_regenerated' => $regen_ids, 'link' => get_permalink( $target_id ) );
    }

    private function _regen_el_ids( $el ) {
        $el['id'] = substr( md5( uniqid( rand(), true ) ), 0, 7 );
        if ( ! empty( $el['elements'] ) ) {
            foreach ( $el['elements'] as &$child ) { $child = $this->_regen_el_ids( $child ); }
        }
        return $el;
    }

    private function get_elementor_globals() {
        $colors = get_option( 'elementor_system_colors', array() );
        $fonts  = get_option( 'elementor_system_typography', array() );
        $kit_id = get_option( 'elementor_active_kit' );
        $kit_globals = array();
        if ( $kit_id ) {
            $raw     = get_post_meta( $kit_id, '_elementor_page_settings', true );
            $decoded = is_array( $raw ) ? $raw : ( is_string( $raw ) ? json_decode( $raw, true ) : null );
            if ( is_array( $decoded ) ) {
                $kit_globals['custom_colors']     = isset( $decoded['system_colors'] )     ? $decoded['system_colors']     : array();
                $kit_globals['custom_typography'] = isset( $decoded['system_typography'] ) ? $decoded['system_typography'] : array();
            }
        }
        return array( 'system_colors' => $colors, 'system_typography' => $fonts, 'kit_id' => $kit_id, 'kit_globals' => $kit_globals );
    }

    private function update_elementor_globals( $a ) {
        $updated = array();
        if ( ! empty( $a['colors'] ) ) {
            $current = get_option( 'elementor_system_colors', array() );
            foreach ( $a['colors'] as $c ) {
                $found = false;
                foreach ( $current as &$existing ) {
                    if ( isset( $existing['_id'] ) && $existing['_id'] === $c['id'] ) {
                        $existing['color'] = sanitize_hex_color( $c['value'] );
                        if ( ! empty( $c['title'] ) ) { $existing['title'] = sanitize_text_field( $c['title'] ); }
                        $found = true;
                        break;
                    }
                }
                unset( $existing );
                if ( ! $found ) {
                    $title     = isset( $c['title'] ) ? $c['title'] : $c['id'];
                    $current[] = array( '_id' => $c['id'], 'title' => sanitize_text_field( $title ), 'color' => sanitize_hex_color( $c['value'] ) );
                }
                $updated[] = 'color:' . $c['id'];
            }
            update_option( 'elementor_system_colors', $current );
        }
        if ( ! empty( $a['fonts'] ) ) {
            $current = get_option( 'elementor_system_typography', array() );
            foreach ( $a['fonts'] as $f ) {
                $found = false;
                foreach ( $current as &$existing ) {
                    if ( isset( $existing['_id'] ) && $existing['_id'] === $f['id'] ) {
                        $existing['typography_font_family'] = sanitize_text_field( $f['value'] );
                        if ( ! empty( $f['title'] ) ) { $existing['title'] = sanitize_text_field( $f['title'] ); }
                        $found = true;
                        break;
                    }
                }
                unset( $existing );
                if ( ! $found ) {
                    $title     = isset( $f['title'] ) ? $f['title'] : $f['id'];
                    $current[] = array( '_id' => $f['id'], 'title' => sanitize_text_field( $title ), 'typography_font_family' => sanitize_text_field( $f['value'] ) );
                }
                $updated[] = 'font:' . $f['id'];
            }
            update_option( 'elementor_system_typography', $current );
        }
        if ( class_exists( 'Elementor\Plugin' ) ) {
            try { Elementor\Plugin::$instance->files_manager->clear_cache(); } catch ( Exception $e ) {}
        }
        return array( 'success' => true, 'updated' => $updated, 'message' => count( $updated ) . ' global(s) updated.' );
    }

    // ── WooCommerce (conditional) ───────────────────────────────

    private function wc_require() {
        if ( ! class_exists( 'WooCommerce' ) ) { throw new Exception( 'WooCommerce is not active.' ); }
    }

    private function wc_get_products( $a ) {
        $this->wc_require();
        $args = array( 'limit' => isset( $a['per_page'] ) ? intval( $a['per_page'] ) : 20, 'status' => isset( $a['status'] ) ? $a['status'] : 'publish' );
        if ( ! empty( $a['search'] ) )   { $args['s']        = $a['search']; }
        if ( ! empty( $a['category'] ) ) { $args['category'] = array( $a['category'] ); }
        $products = wc_get_products( $args );
        $list     = array();
        foreach ( $products as $p ) {
            $list[] = array( 'id' => $p->get_id(), 'name' => $p->get_name(), 'status' => $p->get_status(), 'price' => $p->get_price(), 'regular_price' => $p->get_regular_price(), 'sale_price' => $p->get_sale_price(), 'stock_status' => $p->get_stock_status(), 'stock_quantity' => $p->get_stock_quantity(), 'sku' => $p->get_sku() );
        }
        return array( 'total' => count( $list ), 'products' => $list );
    }

    private function wc_get_product( $a ) {
        $this->wc_require();
        $p = wc_get_product( intval( $a['id'] ) );
        if ( ! $p ) { throw new Exception( 'Product not found.' ); }
        return array( 'id' => $p->get_id(), 'name' => $p->get_name(), 'description' => $p->get_description(), 'short_description' => $p->get_short_description(), 'status' => $p->get_status(), 'price' => $p->get_price(), 'regular_price' => $p->get_regular_price(), 'sale_price' => $p->get_sale_price(), 'stock_status' => $p->get_stock_status(), 'stock_quantity' => $p->get_stock_quantity(), 'sku' => $p->get_sku(), 'type' => $p->get_type() );
    }

    private function wc_update_product( $a ) {
        $this->wc_require();
        $p = wc_get_product( intval( $a['id'] ) );
        if ( ! $p ) { throw new Exception( 'Product not found.' ); }
        if ( isset( $a['name'] ) )              { $p->set_name( sanitize_text_field( $a['name'] ) ); }
        if ( isset( $a['regular_price'] ) )     { $p->set_regular_price( $a['regular_price'] ); }
        if ( isset( $a['sale_price'] ) )        { $p->set_sale_price( $a['sale_price'] ); }
        if ( isset( $a['stock_quantity'] ) )    { $p->set_stock_quantity( intval( $a['stock_quantity'] ) ); }
        if ( isset( $a['manage_stock'] ) )      { $p->set_manage_stock( (bool) $a['manage_stock'] ); }
        if ( isset( $a['status'] ) )            { $p->set_status( $a['status'] ); }
        if ( isset( $a['description'] ) )       { $p->set_description( wp_kses_post( $a['description'] ) ); }
        if ( isset( $a['short_description'] ) ) { $p->set_short_description( wp_kses_post( $a['short_description'] ) ); }
        $p->save();
        return array( 'success' => true, 'id' => $p->get_id() );
    }

    private function wc_get_orders( $a ) {
        $this->wc_require();
        $args = array( 'limit' => isset( $a['per_page'] ) ? intval( $a['per_page'] ) : 20, 'status' => isset( $a['status'] ) ? $a['status'] : 'any' );
        if ( ! empty( $a['customer_email'] ) ) { $args['customer'] = $a['customer_email']; }
        $orders = wc_get_orders( $args );
        $list   = array();
        foreach ( $orders as $o ) {
            $date   = $o->get_date_created();
            $list[] = array( 'id' => $o->get_id(), 'status' => $o->get_status(), 'total' => $o->get_total(), 'currency' => $o->get_currency(), 'date' => $date ? $date->date( 'Y-m-d H:i:s' ) : '', 'customer_email' => $o->get_billing_email(), 'items' => $o->get_item_count() );
        }
        return array( 'total' => count( $list ), 'orders' => $list );
    }

    private function wc_get_order( $a ) {
        $this->wc_require();
        $o = wc_get_order( intval( $a['id'] ) );
        if ( ! $o ) { throw new Exception( 'Order not found.' ); }
        $items = array();
        foreach ( $o->get_items() as $item ) {
            $items[] = array( 'product_id' => $item->get_product_id(), 'name' => $item->get_name(), 'quantity' => $item->get_quantity(), 'total' => $item->get_total() );
        }
        $date = $o->get_date_created();
        return array( 'id' => $o->get_id(), 'status' => $o->get_status(), 'date' => $date ? $date->date( 'Y-m-d H:i:s' ) : '', 'total' => $o->get_total(), 'currency' => $o->get_currency(), 'billing_email' => $o->get_billing_email(), 'billing_name' => trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ), 'items' => $items );
    }

    private function wc_update_order_status( $a ) {
        $this->wc_require();
        $o = wc_get_order( intval( $a['id'] ) );
        if ( ! $o ) { throw new Exception( 'Order not found.' ); }
        $o->update_status( $a['status'], 'Updated via Claude MCP.', true );
        return array( 'success' => true, 'id' => $o->get_id(), 'new_status' => $o->get_status() );
    }


    // =========================================================
    //  V28 — TOKEN EFFICIENCY TOOLS
    // =========================================================

    private function context_summary( $a ) {
        $result = array();
        $theme  = wp_get_theme();
        $result['site'] = array(
            'name'         => get_bloginfo( 'name' ),
            'url'          => get_bloginfo( 'url' ),
            'wp_version'   => get_bloginfo( 'version' ),
            'active_theme' => $theme->get( 'Name' ),
            'elementor'    => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : false,
            'woocommerce'  => class_exists( 'WooCommerce' ) ? ( defined( 'WC_VERSION' ) ? WC_VERSION : true ) : false,
            'acf'          => function_exists( 'get_field' ) ? ( defined( 'ACF_VERSION' ) ? ACF_VERSION : true ) : false,
            'mcp_version'  => CLAUDE_MCP_VERSION,
        );

        if ( ! isset( $a['include_pages'] ) || $a['include_pages'] ) {
            $q = new WP_Query( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 50, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
            $result['pages'] = array();
            foreach ( $q->posts as $p ) {
                $result['pages'][] = array(
                    'id'       => $p->ID,
                    'title'    => $p->post_title,
                    'slug'     => $p->post_name,
                    'template' => get_page_template_slug( $p->ID ) ? get_page_template_slug( $p->ID ) : 'default',
                    'el'       => (bool) get_post_meta( $p->ID, '_elementor_data', true ),
                );
            }
        }

        if ( ! isset( $a['include_posts'] ) || $a['include_posts'] ) {
            $q2 = new WP_Query( array( 'post_type' => 'post', 'post_status' => array( 'publish', 'draft', 'future' ), 'posts_per_page' => 20, 'orderby' => 'date', 'order' => 'DESC' ) );
            $result['recent_posts'] = array();
            foreach ( $q2->posts as $p ) {
                $result['recent_posts'][] = array(
                    'id'     => $p->ID,
                    'title'  => $p->post_title,
                    'status' => $p->post_status,
                    'date'   => substr( $p->post_date, 0, 10 ),
                );
            }
        }

        if ( ! isset( $a['include_plugins'] ) || $a['include_plugins'] ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            $all    = get_plugins();
            $active = get_option( 'active_plugins', array() );
            $result['active_plugins'] = array();
            foreach ( $active as $file ) {
                if ( isset( $all[ $file ] ) ) {
                    $result['active_plugins'][] = array(
                        'name'    => $all[ $file ]['Name'],
                        'version' => $all[ $file ]['Version'],
                    );
                }
            }
        }

        if ( ! empty( $a['include_menus'] ) ) {
            $menus = wp_get_nav_menus();
            $locs  = array_flip( get_nav_menu_locations() );
            $result['menus'] = array();
            foreach ( $menus as $m ) {
                $loc = isset( $locs[ $m->term_id ] ) ? $locs[ $m->term_id ] : null;
                $result['menus'][] = array( 'id' => $m->term_id, 'name' => $m->name, 'location' => $loc );
            }
        }

        $result['_tip'] = 'Use get_page_structure(id) before any Elementor edit. Use update_elementor_widget for targeted changes.';
        return $result;
    }

    private function parse_fields( $fields_str, $defaults ) {
        if ( empty( $fields_str ) ) { return $defaults; }
        $parts      = array_map( 'trim', explode( ',', $fields_str ) );
        $has_append = false;
        foreach ( $parts as $p ) {
            if ( strpos( $p, '+' ) === 0 ) { $has_append = true; break; }
        }
        if ( $has_append ) {
            $extra = array();
            foreach ( $parts as $p ) { $extra[] = ltrim( $p, '+' ); }
            return array_values( array_unique( array_merge( $defaults, $extra ) ) );
        }
        return array_filter( $parts );
    }



    // =========================================================
    //  ELEMENTOR TEMPLATE LIBRARY
    // =========================================================

    private function get_elementor_templates( $a ) {
        $args = array(
            'post_type'      => 'elementor_library',
            'post_status'    => 'publish',
            'posts_per_page' => isset( $a['per_page'] ) ? intval( $a['per_page'] ) : 50,
            'orderby'        => 'title',
            'order'          => 'ASC',
        );
        if ( ! empty( $a['template_type'] ) ) {
            $args['meta_query'] = array(
                array( 'key' => '_elementor_template_type', 'value' => sanitize_text_field( $a['template_type'] ) )
            );
        }
        $q         = new WP_Query( $args );
        $templates = array();
        foreach ( $q->posts as $p ) {
            $type = get_post_meta( $p->ID, '_elementor_template_type', true );
            $raw  = get_post_meta( $p->ID, '_elementor_data', true );
            $templates[] = array(
                'id'            => $p->ID,
                'title'         => $p->post_title,
                'type'          => $type ? $type : 'page',
                'status'        => $p->post_status,
                'has_data'      => ! empty( $raw ),
                'data_size'     => strlen( $raw ? $raw : '' ),
                'section_count' => $raw ? count( (array) json_decode( $raw, true ) ) : 0,
                'modified'      => $p->post_modified,
            );
        }
        // Group by type for easier reading
        $by_type = array();
        foreach ( $templates as $t ) {
            $by_type[ $t['type'] ][] = $t;
        }
        return array(
            'total'     => $q->found_posts,
            'templates' => $templates,
            'by_type'   => $by_type,
        );
    }

    private function create_elementor_template( $a ) {
        $type   = isset( $a['template_type'] ) ? sanitize_text_field( $a['template_type'] ) : 'page';
        $status = isset( $a['status'] )        ? $a['status']                                : 'publish';

        $valid_types = array( 'page', 'section', 'widget', 'popup', 'header', 'footer', 'kit' );
        if ( ! in_array( $type, $valid_types, true ) ) {
            throw new Exception( "Invalid template_type '{$type}'. Use: " . implode( ', ', $valid_types ) );
        }

        $post_id = wp_insert_post( array(
            'post_title'  => sanitize_text_field( $a['title'] ),
            'post_type'   => 'elementor_library',
            'post_status' => $status,
        ), true );

        if ( is_wp_error( $post_id ) ) {
            throw new Exception( $post_id->get_error_message() );
        }

        update_post_meta( $post_id, '_elementor_template_type', $type );
        update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
        update_post_meta( $post_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0' );

        // Set the template category taxonomy
        $term = get_term_by( 'slug', $type, 'elementor_library_type' );
        if ( $term ) {
            wp_set_post_terms( $post_id, array( $term->term_id ), 'elementor_library_type' );
        }

        $section_count = 0;
        if ( ! empty( $a['elementor_data'] ) ) {
            update_post_meta( $post_id, '_elementor_data', $a['elementor_data'] );
            $decoded = json_decode( $a['elementor_data'], true );
            if ( is_array( $decoded ) ) { $section_count = count( $decoded ); }
            $this->regenerate_elementor_css( $post_id );
        }

        return array(
            'success'       => true,
            'id'            => $post_id,
            'title'         => $a['title'],
            'type'          => $type,
            'section_count' => $section_count,
            'message'       => "Template '{$a['title']}' created as type '{$type}' with ID {$post_id}. Find it in Elementor > Templates library.",
        );
    }

    private function get_elementor_template( $a ) {
        $id   = intval( $a['id'] );
        $post = get_post( $id );
        if ( ! $post || $post->post_type !== 'elementor_library' ) {
            throw new Exception( "Template {$id} not found. Use get_elementor_templates to list available templates." );
        }
        $raw     = get_post_meta( $id, '_elementor_data', true );
        $type    = get_post_meta( $id, '_elementor_template_type', true );
        $decoded = $raw ? json_decode( $raw, true ) : array();
        return array(
            'id'            => $id,
            'title'         => $post->post_title,
            'type'          => $type ? $type : 'page',
            'status'        => $post->post_status,
            'modified'      => $post->post_modified,
            'has_data'      => ! empty( $raw ),
            'section_count' => is_array( $decoded ) ? count( $decoded ) : 0,
            'data_size'     => strlen( $raw ? $raw : '' ),
            'elementor_data'=> $raw ? $raw : null,
        );
    }

    private function apply_elementor_template( $a ) {
        $template_id   = intval( $a['template_id'] );
        $target_id     = intval( $a['target_page_id'] );
        $regen_ids     = ! isset( $a['regenerate_ids'] ) || $a['regenerate_ids'];
        $page_template = isset( $a['page_template'] ) ? $a['page_template'] : 'elementor_canvas';

        // Validate template
        $tpl = get_post( $template_id );
        if ( ! $tpl || $tpl->post_type !== 'elementor_library' ) {
            throw new Exception( "Template {$template_id} not found in Elementor library." );
        }

        $raw = get_post_meta( $template_id, '_elementor_data', true );
        if ( empty( $raw ) ) {
            throw new Exception( "Template {$template_id} has no Elementor data." );
        }

        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) ) {
            throw new Exception( "Template {$template_id} Elementor data is invalid JSON." );
        }

        // Regenerate IDs to avoid collisions on the target page
        if ( $regen_ids ) {
            $new_data = array();
            foreach ( $data as $section ) {
                $new_data[] = $this->_regen_el_ids( $section );
            }
            $data = $new_data;
        }

        $new_json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

        // Write to target
        global $wpdb;
        wp_cache_delete( $target_id, 'post_meta' );
        $wpdb->delete( $wpdb->postmeta, array( 'post_id' => $target_id, 'meta_key' => '_elementor_data' ) );
        $wpdb->insert( $wpdb->postmeta, array( 'post_id' => $target_id, 'meta_key' => '_elementor_data', 'meta_value' => $new_json ) );
        update_post_meta( $target_id, '_elementor_edit_mode', 'builder' );
        update_post_meta( $target_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0' );
        update_post_meta( $target_id, '_elementor_template_type', 'wp-page' );
        update_post_meta( $target_id, '_wp_page_template', $page_template );
        wp_update_post( array( 'ID' => $target_id, 'page_template' => $page_template ) );
        wp_cache_delete( $target_id, 'post_meta' );
        clean_post_cache( $target_id );
        $this->regenerate_elementor_css( $target_id );
        $this->purge_page_cache( $target_id );

        return array(
            'success'        => true,
            'template_id'    => $template_id,
            'template_title' => $tpl->post_title,
            'target_page_id' => $target_id,
            'section_count'  => count( $data ),
            'ids_regenerated'=> $regen_ids,
            'link'           => get_permalink( $target_id ),
            'message'        => "Template '{$tpl->post_title}' applied to page {$target_id}. {$section_count} section(s). CSS regenerated.",
        );
    }


}