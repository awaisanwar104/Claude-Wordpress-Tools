<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Max bytes per tool response — prevents token bleed on large payloads.
if ( ! defined( 'CLAUDE_MCP_MAX_RESPONSE_BYTES' ) ) define( 'CLAUDE_MCP_MAX_RESPONSE_BYTES', 30000 );

class Claude_MCP_Server {

    private $oauth;
    private $tools;

    public function __construct() {
        $this->oauth = new Claude_MCP_OAuth();
        $this->tools = new Claude_MCP_Tools();
    }

    public function register_routes() {
        register_rest_route( 'claude-mcp/v1', '/mcp', array(
            array(
                'methods'             => 'OPTIONS',
                'callback'            => array( $this, 'handle_options' ),
                'permission_callback' => '__return_true',
            ),
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'handle_sse' ),
                'permission_callback' => '__return_true',
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'handle_post' ),
                'permission_callback' => '__return_true',
            ),
        ) );

        register_rest_route( 'claude-mcp/v1', '/health', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'handle_health' ),
            'permission_callback' => '__return_true',
        ) );

        // /debug is auth-gated — no sensitive data exposed to the public.
        register_rest_route( 'claude-mcp/v1', '/debug', array(
            'methods'             => 'GET',
            'callback'            => array( $this, 'handle_debug' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function handle_options() {
        return $this->cors( new WP_REST_Response( null, 204 ) );
    }

    /**
     * Authenticates a request via Bearer token (OAuth or static API key).
     * Query-string api_key is intentionally NOT supported — it leaks the key
     * into server logs, browser history, and referrer headers.
     * Returns true on success, false on failure.
     */
    private function do_auth( WP_REST_Request $request ) {
        $api_key = get_option( 'claude_mcp_api_key', '' );

        // Grab Authorization header — WP sometimes strips it, fall back to server vars.
        $auth = $request->get_header( 'Authorization' ) ?? '';
        if ( empty( $auth ) ) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        }

        if ( strpos( $auth, 'Bearer ' ) === 0 ) {
            $token = trim( substr( $auth, 7 ) );
            // OAuth token (stored hashed)
            if ( $this->oauth->validate_token( $token ) ) return true;
            // Static API key (compared directly with constant-time function)
            if ( $api_key && hash_equals( $api_key, $token ) ) return true;
        }

        // X-API-Key header fallback
        $xkey = $request->get_header( 'X-API-Key' ) ?? '';
        if ( $xkey && $api_key && hash_equals( $api_key, $xkey ) ) return true;

        // v30.5.0+: log only 10 chars (previously 50, which exposed full tokens).
        // Enough to tell "Bearer xxx" from "Basic xxx" without leaking credentials.
        error_log( 'Claude MCP: auth failed. header=' . substr( $auth, 0, 10 ) . ( strlen( $auth ) > 10 ? '...' : '' ) );
        return false;
    }

    /**
     * Rate limiting: max CLAUDE_MCP_RATE_LIMIT tool calls per minute per token hash.
     * Uses transients — no extra DB table needed.
     */
    private function check_rate_limit( WP_REST_Request $request ) {
        $limit = defined( 'CLAUDE_MCP_RATE_LIMIT' ) ? (int) CLAUDE_MCP_RATE_LIMIT : 120;
        if ( $limit <= 0 ) return true;

        $auth = $request->get_header( 'Authorization' ) ?? '';
        if ( empty( $auth ) ) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        }
        $token_id = hash( 'sha256', $auth );
        $key      = 'cmcp_rl_' . substr( $token_id, 0, 16 );

        $count = (int) get_transient( $key );
        if ( $count >= $limit ) return false;

        set_transient( $key, $count + 1, 60 );
        return true;
    }

    /* ── SSE endpoint ───────────────────────────────────────────── */

    public function handle_sse( WP_REST_Request $request ) {
        if ( ! $this->do_auth( $request ) ) {
            status_header( 401 );
            header( 'WWW-Authenticate: Bearer' );
            header( 'Content-Type: application/json' );
            echo json_encode( array( 'error' => 'unauthorized' ) );
            exit;
        }

        @set_time_limit( 0 );
        @ini_set( 'output_buffering', 'off' );
        @ini_set( 'zlib.output_compression', false );
        @ini_set( 'implicit_flush', true );
        if ( function_exists( 'apache_setenv' ) ) {
            @apache_setenv( 'no-gzip', 1 );
        }
        while ( ob_get_level() > 0 ) {
            @ob_end_clean();
        }
        @ob_implicit_flush( true );

        header( 'X-LiteSpeed-Cache-Control: no-cache, no-store' );
        header( 'X-LiteSpeed-Tag: ' );
        header( 'Content-Type: text/event-stream; charset=utf-8' );
        header( 'Cache-Control: no-cache, no-store, must-revalidate' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );
        header( 'X-Accel-Buffering: no' );
        $cmcp_cors_origin = function_exists( 'claude_mcp_cors_allowed_origin' ) ? claude_mcp_cors_allowed_origin() : '';
        if ( $cmcp_cors_origin ) header( 'Access-Control-Allow-Origin: ' . $cmcp_cors_origin );
        header( 'Vary: Origin' );
        header( 'Access-Control-Allow-Headers: Authorization, Content-Type' );
        header( 'Connection: keep-alive' );

        $post_url = rest_url( 'claude-mcp/v1/mcp' );

        echo "event: endpoint\n";
        echo "data: " . $post_url . "\n\n";
        @flush();

        $timeout = defined( 'CLAUDE_MCP_SSE_TIMEOUT' ) ? (int) CLAUDE_MCP_SSE_TIMEOUT : 55;
        $start   = time();
        while ( ( time() - $start ) < $timeout ) {
            if ( connection_aborted() ) break;
            echo ": ping\n\n";
            @flush();
            sleep( 15 );   // increased from 3s — reduces noise, still keeps connection alive
        }

        exit;
    }

    /* ── POST endpoint (JSON-RPC) ───────────────────────────────── */

    public function handle_post( WP_REST_Request $request ) {
        if ( ! $this->do_auth( $request ) ) {
            return $this->cors( new WP_REST_Response(
                array( 'error' => 'unauthorized', 'error_description' => 'Invalid or missing Bearer token.' ),
                401
            ) );
        }

        $payload = json_decode( $request->get_body(), true );

        if ( json_last_error() !== JSON_ERROR_NONE || empty( $payload ) ) {
            return $this->cors( new WP_REST_Response(
                array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32700, 'message' => 'Parse error' ) ),
                200
            ) );
        }

        $id     = $payload['id']     ?? null;
        $method = $payload['method'] ?? '';
        $params = $payload['params'] ?? array();

        error_log( 'Claude MCP method: ' . $method );

        try {
            switch ( $method ) {
                case 'initialize':
                    $result = array(
                        'protocolVersion' => '2024-11-05',
                        'capabilities'    => array(
                            'tools'     => array( 'listChanged' => false ),
                            'resources' => array( 'subscribe' => false, 'listChanged' => false ),
                            'prompts'   => array( 'listChanged' => false ),
                            'logging'   => new stdClass(),
                        ),
                        'serverInfo' => array(
                            'name'    => 'Claude WordPress MCP',
                            'version' => CLAUDE_MCP_VERSION,
                        ),
                        'instructions' => "ELEMENTOR RULES — follow strictly on every page build.\n\nMANDATORY IMAGES: Every page you build MUST include real images. Never leave placeholder images (via.placeholder.com, dummyimage.com, etc.) in the final page, and never publish a page with empty image widgets. If a template contains an image widget or a container with a background image, you MUST call upload_media_from_url with a relevant free Unsplash image (https://images.unsplash.com/...) and then update the widget/container to point at the uploaded media. This applies to hero backgrounds, split-hero photos, feature icons where a photo fits better, gallery widgets, and any image widget the template exposes. Pick images that match the page's subject (clothing store → clothing/fashion photos, restaurant → food photos, SaaS → workspace/product photos). Do not skip this step. Do not ask the user for images unless they explicitly said they will provide their own.\n\nHARD BLOCK: The `html` widget is FORBIDDEN. The server will REJECT any set_elementor_data, append_elementor_section, apply_template, or copy_elementor_section call that contains a widget with widgetType='html'. This is enforced in PHP, not a suggestion. The only way past it is passing allow_html_widget=true, which you must ONLY do when the user has explicitly typed a request for a raw-HTML widget in this conversation.\n\nPREFERRED WORKFLOW — templates first:\n1. Call list_templates FIRST for any page build. The site has a curated library of section templates (heroes, features, CTAs, footers, etc.) that already have correct layout, widths, padding, typography, and responsive behavior.\n2. Assemble the page by calling apply_template several times with different section templates.\n3. After each apply_template, use update_elementor_widget with the returned widget IDs to swap in the user's copy, colors, and images.\n4. Fall back to composing from primitives ONLY when no template fits — and if you do, follow the widget-catalog workflow below.\n5. If the user says something like \"save this as a template\", call save_as_template with the section ID.\n\nFALLBACK WORKFLOW — when composing from primitives:\n1. Call list_elementor_widgets to see every widget available on this site — core Elementor, Elementor Pro, and any third-party addon widgets. Do not guess widget names from memory.\n2. For each widget type you plan to use, call get_widget_schema(widget_type) for real setting keys and defaults.\n3. Call get_page_structure(id) before editing an existing page.\n4. Call backup_post(id) before any destructive operation.\n5. Build with native widgets only. All styling — colors, typography, spacing, backgrounds, borders — goes inside the widget's `settings` object using keys from get_widget_schema. NEVER in <style> tags, inline style attributes, or HTML embedded in text fields.\n6. Layout rules: every section is a flex Container. Row layouts use flex_direction=row with a gap. Every top-level container needs content_width=boxed (~1200px) and vertical padding (~80px). Every heading needs typography_font_size set per breakpoint (desktop/tablet/mobile) — do not rely on defaults.\n7. The post `content` field must be empty when the page has Elementor data. Never put HTML or CSS there.\n8. For targeted edits use update_elementor_widget with the widget ID, not full-page replacement.",
                    );
                    break;

                case 'notifications/initialized':
                    return $this->cors( new WP_REST_Response( null, 200 ) );

                case 'ping':
                    $result = array();
                    break;

                case 'tools/list':
                    $result = array( 'tools' => $this->tools->get_tools() );
                    break;

                case 'tools/call':
                    // Rate-limit tool calls only (not handshake methods).
                    if ( ! $this->check_rate_limit( $request ) ) {
                        return $this->cors( new WP_REST_Response(
                            array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => -32000, 'message' => 'Rate limit exceeded. Max ' . CLAUDE_MCP_RATE_LIMIT . ' calls/minute.' ) ),
                            429
                        ) );
                    }
                    return $this->cors( $this->handle_tool_call( $id, $params ) );

                case 'resources/list':
                    $result = array( 'resources' => array() );
                    break;

                case 'prompts/list':
                    $result = array( 'prompts' => array() );
                    break;

                default:
                    return $this->cors( new WP_REST_Response(
                        array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => -32601, 'message' => "Method not found: {$method}" ) ),
                        200
                    ) );
            }
        } catch ( Exception $e ) {
            return $this->cors( new WP_REST_Response(
                array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => -32000, 'message' => $e->getMessage() ) ),
                200
            ) );
        }

        return $this->cors( new WP_REST_Response(
            array( 'jsonrpc' => '2.0', 'id' => $id, 'result' => $result ),
            200
        ) );
    }

    private function handle_tool_call( $id, $params ) {
        @set_time_limit( 0 );
        @ignore_user_abort( true );

        $name      = isset( $params['name'] )      ? $params['name']      : null;
        $arguments = isset( $params['arguments'] ) ? $params['arguments'] : array();

        if ( ! $name ) {
            return $this->cors( new WP_REST_Response(
                array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => -32602, 'message' => 'Missing tool name' ) ),
                200
            ) );
        }

        // v30.6.0+: license gate. Blocks tool dispatch when the plugin is
        // managed by a license server and the current license is invalid or
        // the grace period has elapsed. Unmanaged installs skip this entirely.
        if ( class_exists( 'Claude_MCP_License' ) && Claude_MCP_License::is_blocked() ) {
            $status_label = Claude_MCP_License::status_label();
            return $this->cors( new WP_REST_Response(
                array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array(
                    'code'    => -32010,
                    'message' => 'License check failed (' . $status_label . '). Open Claude MCP → License in wp-admin to resolve.',
                ) ),
                200
            ) );
        }

        try {
            $result    = $this->tools->execute_tool( $name, $arguments );
            // v30.7.3+: license and permission denials return WP_Error, not
            // exceptions. Surface those as isError responses so Claude sees
            // the actual reason instead of an "error object as text" blob.
            if ( is_wp_error( $result ) ) {
                return $this->cors( new WP_REST_Response( array(
                    'jsonrpc' => '2.0',
                    'id'      => $id,
                    'result'  => array(
                        'content' => array( array( 'type' => 'text', 'text' => $result->get_error_message() ) ),
                        'isError' => true,
                    ),
                ), 200 ) );
            }
            $result    = $this->trim_response( $result );
            $text      = wp_json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
            $max_bytes = defined( 'CLAUDE_MCP_MAX_RESPONSE_BYTES' ) ? (int) CLAUDE_MCP_MAX_RESPONSE_BYTES : 30000;
            if ( strlen( $text ) > $max_bytes ) {
                $truncated = mb_substr( $text, 0, $max_bytes );
                $last_nl   = strrpos( $truncated, "
" );
                if ( $last_nl !== false ) { $truncated = substr( $truncated, 0, $last_nl ); }
                $text = $truncated . "

[TRUNCATED — response exceeded {$max_bytes} bytes. Use more specific parameters, e.g. per_page=5, include_elementor=false, or summary=true.]";
            }
            return new WP_REST_Response( array(
                'jsonrpc' => '2.0',
                'id'      => $id,
                'result'  => array(
                    'content' => array( array( 'type' => 'text', 'text' => $text ) ),
                    'isError' => false,
                ),
            ), 200 );
        } catch ( Exception $e ) {
            return new WP_REST_Response( array(
                'jsonrpc' => '2.0',
                'id'      => $id,
                'result'  => array(
                    'content' => array( array( 'type' => 'text', 'text' => 'Error: ' . $e->getMessage() ) ),
                    'isError' => true,
                ),
            ), 200 );
        }
    }

    private function trim_response( $data ) {
        if ( ! is_array( $data ) ) { return $data; }
        $out = array();
        foreach ( $data as $k => $v ) {
            if ( is_null( $v ) ) { continue; }
            if ( is_array( $v ) ) { $v = $this->trim_response( $v ); }
            $out[ $k ] = $v;
        }
        return $out;
    }

    private function cors( WP_REST_Response $r ) {
        $origin = function_exists( 'claude_mcp_cors_allowed_origin' ) ? claude_mcp_cors_allowed_origin() : '';
        if ( $origin ) $r->header( 'Access-Control-Allow-Origin', $origin );
        $r->header( 'Vary', 'Origin' );
        $r->header( 'Access-Control-Allow-Methods', 'GET, POST, OPTIONS' );
        $r->header( 'Access-Control-Allow-Headers', 'Authorization, Content-Type, X-API-Key' );
        return $r;
    }

    public function handle_health() {
        $tokens = get_option( 'claude_mcp_tokens', array() );
        $codes  = get_option( 'claude_mcp_auth_codes', array() );
        return new WP_REST_Response( array(
            'status'        => 'ok',
            'version'       => CLAUDE_MCP_VERSION,
            'wp_version'    => get_bloginfo( 'version' ),
            'site_url'      => get_bloginfo( 'url' ),
            'active_tokens' => count( $tokens ),
            'pending_codes' => count( $codes ),
            'mcp_url'       => rest_url( 'claude-mcp/v1/mcp' ),
        ), 200 );
    }

    public function handle_debug( WP_REST_Request $request ) {
        // /debug is auth-gated to prevent leaking token counts and log entries.
        if ( ! $this->do_auth( $request ) ) {
            return new WP_REST_Response( array( 'error' => 'unauthorized' ), 401 );
        }
        $tokens = get_option( 'claude_mcp_tokens', array() );
        $codes  = get_option( 'claude_mcp_auth_codes', array() );
        $log    = get_option( 'claude_mcp_debug_log', array() );
        return new WP_REST_Response( array(
            'active_tokens'  => count( $tokens ),
            'pending_codes'  => count( $codes ),
            'recent_log'     => array_slice( $log, -20 ),
            'rate_limit'     => CLAUDE_MCP_RATE_LIMIT,
            'sse_timeout'    => CLAUDE_MCP_SSE_TIMEOUT,
        ), 200 );
    }
}
