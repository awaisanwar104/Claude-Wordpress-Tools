<?php
/**
 * Claude_MCP_License
 *
 * Phone-home license verification for distributed copies.
 *
 * Design:
 *  - If CLAUDE_MCP_LICENSE_SERVER constant is not defined (or empty),
 *    the plugin runs unrestricted. This is the author's own-site mode:
 *    their builds leave the constant undefined.
 *  - If CLAUDE_MCP_LICENSE_SERVER is defined (set in a per-customer
 *    build or wp-config.php), the plugin must verify a license key on
 *    activation, once per day, and refuses to serve MCP requests after
 *    a GRACE_DAYS window of failed verifications.
 *
 * The admin UI stays functional in all states so the operator can
 * enter a new key, review activity, or revoke tokens.
 *
 * Watermarking: every install gets a random install_id baked into
 * verification requests. If a leaked copy appears in the wild, the
 * install_id in the server's logs identifies the leaker.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_License {

    const OPTION_KEY         = 'claude_mcp_license_key';
    const OPTION_STATUS      = 'claude_mcp_license_status';
    const OPTION_EXPIRES     = 'claude_mcp_license_expires_at';
    const OPTION_LAST_CHECK  = 'claude_mcp_license_last_check';
    const OPTION_GRACE_START = 'claude_mcp_license_grace_start';
    const OPTION_INSTALL_ID  = 'claude_mcp_install_id';
    const OPTION_LAST_ERROR  = 'claude_mcp_license_last_error';
    const OPTION_TIER        = 'claude_mcp_license_tier';

    const GRACE_DAYS         = 7;
    const CHECK_INTERVAL     = DAY_IN_SECONDS;   // Minimum time between verifications
    const REQUEST_TIMEOUT    = 10;               // Seconds for the HTTP request

    const STATUS_OK          = 'active';
    const STATUS_EXPIRED     = 'expired';
    const STATUS_INVALID     = 'invalid';
    const STATUS_UNSET       = 'not_set';
    const STATUS_GRACE       = 'grace';
    const STATUS_UNREACHABLE = 'unreachable';
    const STATUS_UNMANAGED   = 'unmanaged';

    /* ── Configuration ──────────────────────────────────────────── */

    /** URL of the license server, from the build-time constant. Empty = unmanaged. */
    public static function server_url() {
        if ( defined( 'CLAUDE_MCP_LICENSE_SERVER' ) ) {
            return rtrim( (string) CLAUDE_MCP_LICENSE_SERVER, '/' );
        }
        return '';
    }

    public static function is_managed() {
        return self::server_url() !== '';
    }

    /** True if the plugin should block MCP calls right now. */
    public static function is_blocked() {
        if ( ! self::is_managed() ) return false;
        $status = self::status();
        if ( in_array( $status, array( self::STATUS_OK, self::STATUS_GRACE, self::STATUS_UNMANAGED ), true ) ) {
            return false;
        }
        return true;
    }

    /* ── Install ID (watermark) ─────────────────────────────────── */

    public static function install_id() {
        $id = get_option( self::OPTION_INSTALL_ID );
        if ( ! $id ) {
            $id = 'wp-' . substr( md5( home_url() . wp_generate_password( 32, false ) . microtime( true ) ), 0, 24 );
            update_option( self::OPTION_INSTALL_ID, $id );
        }
        return $id;
    }

    /* ── Key management ─────────────────────────────────────────── */

    public static function key() {
        return (string) get_option( self::OPTION_KEY, '' );
    }

    public static function set_key( $raw ) {
        $raw = trim( (string) $raw );
        $raw = preg_replace( '/[^A-Za-z0-9\-_]/', '', $raw );
        update_option( self::OPTION_KEY, $raw );
        // New key resets any grace period so verification runs cleanly.
        delete_option( self::OPTION_GRACE_START );
        delete_option( self::OPTION_LAST_ERROR );
        return $raw;
    }

    /* ── Status ─────────────────────────────────────────────────── */

    public static function status() {
        if ( ! self::is_managed() ) return self::STATUS_UNMANAGED;
        if ( ! self::key() )        return self::STATUS_UNSET;

        $stored  = get_option( self::OPTION_STATUS );
        $expires = (int) get_option( self::OPTION_EXPIRES );

        // Server previously said expired.
        if ( $stored === self::STATUS_EXPIRED ) return self::STATUS_EXPIRED;
        if ( $stored === self::STATUS_INVALID ) return self::STATUS_INVALID;

        // No successful check in GRACE_DAYS → grace or hard block.
        $grace_start = (int) get_option( self::OPTION_GRACE_START );
        if ( $grace_start > 0 ) {
            $elapsed = time() - $grace_start;
            if ( $elapsed > ( self::GRACE_DAYS * DAY_IN_SECONDS ) ) {
                return self::STATUS_UNREACHABLE;
            }
            return self::STATUS_GRACE;
        }

        // Server-side expiry claim.
        if ( $expires > 0 && time() > $expires ) return self::STATUS_EXPIRED;

        return $stored ?: self::STATUS_UNSET;
    }

    public static function status_label( $status = null ) {
        $status = $status ?: self::status();
        $labels = array(
            self::STATUS_OK          => 'Active',
            self::STATUS_EXPIRED     => 'Expired',
            self::STATUS_INVALID     => 'Invalid',
            self::STATUS_UNSET       => 'Key not set',
            self::STATUS_GRACE       => 'In grace period',
            self::STATUS_UNREACHABLE => 'Server unreachable',
            self::STATUS_UNMANAGED   => 'Not required',
        );
        return $labels[ $status ] ?? $status;
    }

    public static function status_color( $status = null ) {
        $status = $status ?: self::status();
        $colors = array(
            self::STATUS_OK          => '#16a34a',
            self::STATUS_EXPIRED     => '#dc2626',
            self::STATUS_INVALID     => '#dc2626',
            self::STATUS_UNSET       => '#64748b',
            self::STATUS_GRACE       => '#f59e0b',
            self::STATUS_UNREACHABLE => '#dc2626',
            self::STATUS_UNMANAGED   => '#64748b',
        );
        return $colors[ $status ] ?? '#64748b';
    }

    public static function expires_at() {
        return (int) get_option( self::OPTION_EXPIRES );
    }

    public static function last_check() {
        return (int) get_option( self::OPTION_LAST_CHECK );
    }

    public static function last_error() {
        return (string) get_option( self::OPTION_LAST_ERROR, '' );
    }

    public static function tier() {
        return (string) get_option( self::OPTION_TIER, '' );
    }

    /* ── Verification ───────────────────────────────────────────── */

    /**
     * POST to the license server. Updates stored status/expiry on success,
     * records an error and starts the grace clock on failure.
     *
     * @return array {status, expires, tier, raw}
     */
    public static function verify_now() {
        if ( ! self::is_managed() ) {
            return array( 'status' => self::STATUS_UNMANAGED );
        }
        if ( ! self::key() ) {
            update_option( self::OPTION_STATUS, self::STATUS_UNSET );
            return array( 'status' => self::STATUS_UNSET );
        }

        $url  = self::server_url() . '/api/verify';
        $body = array(
            'license_key' => self::key(),
            'install_id'  => self::install_id(),
            'site_url'    => home_url(),
            'version'     => defined( 'CLAUDE_MCP_VERSION' ) ? CLAUDE_MCP_VERSION : 'unknown',
        );
        $resp = wp_remote_post( $url, array(
            'timeout'     => self::REQUEST_TIMEOUT,
            'body'        => wp_json_encode( $body ),
            'headers'     => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
            'redirection' => 2,
            'sslverify'   => true,
        ) );

        update_option( self::OPTION_LAST_CHECK, time() );

        if ( is_wp_error( $resp ) ) {
            self::note_failure( $resp->get_error_message() );
            return array( 'status' => self::STATUS_UNREACHABLE, 'error' => $resp->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $resp );
        $raw  = wp_remote_retrieve_body( $resp );
        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) ) {
            self::note_failure( 'Malformed response from license server (HTTP ' . $code . ').' );
            return array( 'status' => self::STATUS_UNREACHABLE, 'error' => 'Bad response', 'http' => $code );
        }

        $status  = isset( $data['status'] ) ? sanitize_text_field( $data['status'] ) : self::STATUS_UNREACHABLE;
        $expires = isset( $data['expires_at'] ) ? (int) $data['expires_at'] : 0;
        $tier    = isset( $data['tier'] )       ? sanitize_text_field( $data['tier'] ) : '';

        update_option( self::OPTION_STATUS,  $status );
        update_option( self::OPTION_EXPIRES, $expires );
        update_option( self::OPTION_TIER,    $tier );

        if ( $status === self::STATUS_OK ) {
            // Successful check clears any grace timer and error.
            delete_option( self::OPTION_GRACE_START );
            delete_option( self::OPTION_LAST_ERROR );
        } else {
            self::note_failure( isset( $data['message'] ) ? sanitize_text_field( $data['message'] ) : 'Status: ' . $status );
        }

        return array(
            'status'  => $status,
            'expires' => $expires,
            'tier'    => $tier,
            'raw'     => $data,
        );
    }

    protected static function note_failure( $message ) {
        update_option( self::OPTION_LAST_ERROR, substr( $message, 0, 500 ) );
        if ( ! get_option( self::OPTION_GRACE_START ) ) {
            update_option( self::OPTION_GRACE_START, time() );
        }
    }

    /**
     * Called from the daily cron. Skips if a successful verify ran within
     * the last CHECK_INTERVAL window.
     */
    public static function daily_check() {
        if ( ! self::is_managed() || ! self::key() ) return;
        $last = self::last_check();
        if ( $last && ( time() - $last ) < self::CHECK_INTERVAL ) return;
        self::verify_now();
    }

    /* ── Admin notice ───────────────────────────────────────────── */

    public static function maybe_render_admin_notice() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $status = self::status();
        if ( in_array( $status, array( self::STATUS_OK, self::STATUS_UNMANAGED ), true ) ) return;

        $url = admin_url( 'admin.php?page=claude-mcp#tab-license' );
        $msg = '';
        switch ( $status ) {
            case self::STATUS_UNSET:
                $msg = 'Claude WordPress MCP: enter your license key to activate this plugin.';
                break;
            case self::STATUS_GRACE:
                $grace_start = (int) get_option( self::OPTION_GRACE_START );
                $days_left   = max( 0, self::GRACE_DAYS - (int) floor( ( time() - $grace_start ) / DAY_IN_SECONDS ) );
                $msg = sprintf( 'Claude WordPress MCP: license could not be verified. %d day(s) grace period remaining before MCP calls are blocked.', $days_left );
                break;
            case self::STATUS_EXPIRED:
                $msg = 'Claude WordPress MCP: license has expired. MCP calls are now blocked. Renew to restore service.';
                break;
            case self::STATUS_INVALID:
                $msg = 'Claude WordPress MCP: license key is invalid. MCP calls are now blocked.';
                break;
            case self::STATUS_UNREACHABLE:
                $msg = 'Claude WordPress MCP: license server has been unreachable for more than the grace period. MCP calls are now blocked.';
                break;
        }
        if ( ! $msg ) return;
        $class = $status === self::STATUS_GRACE ? 'notice-warning' : 'notice-error';
        echo '<div class="notice ' . esc_attr( $class ) . '"><p><strong>' . esc_html( $msg ) . '</strong> <a href="' . esc_url( $url ) . '">Open License settings</a></p></div>';
    }
}
