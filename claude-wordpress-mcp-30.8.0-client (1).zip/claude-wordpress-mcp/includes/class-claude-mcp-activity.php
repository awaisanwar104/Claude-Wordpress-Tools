<?php
/**
 * Claude_MCP_Activity
 *
 * Append-only log of what Claude did — captures tool, actor, target, IP,
 * timestamp, and arbitrary meta per row. Powers the Activity tab and the
 * email-alert trigger.
 *
 * Table: {$wpdb->prefix}claude_mcp_activity
 *   id         BIGINT UNSIGNED, PK, auto-increment
 *   created_at DATETIME, indexed
 *   user_id    BIGINT UNSIGNED, indexed
 *   user_login VARCHAR(60)
 *   tool       VARCHAR(64), indexed
 *   action     VARCHAR(32)   write | delete | install | activate | option | search_replace
 *   target     VARCHAR(500)  file path, post id, option name, etc.
 *   ip         VARCHAR(45)   IPv4 or IPv6
 *   meta       TEXT          JSON blob for extra context
 *
 * Only destructive tools are logged by default; reads are not.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_Activity {

    const SCHEMA_VERSION_OPTION = 'claude_mcp_activity_schema_v';
    const SCHEMA_VERSION        = 1;

    /** Tools we log, with the action verb and a target-extractor for each. */
    public static function logged_tools() {
        return array(
            // File writes — HIGH
            'write_theme_file'          => array( 'action' => 'write',   'target_arg' => 'path',    'alert' => true ),
            'write_plugin_file'         => array( 'action' => 'write',   'target_arg' => 'path',    'alert' => true ),
            // Plugin / theme management — HIGH
            'install_plugin'            => array( 'action' => 'install', 'target_arg' => 'slug',    'alert' => true ),
            'install_theme'             => array( 'action' => 'install', 'target_arg' => 'slug',    'alert' => true ),
            'activate_plugin'           => array( 'action' => 'activate','target_arg' => 'plugin',  'alert' => true ),
            'deactivate_plugin'         => array( 'action' => 'deactivate','target_arg' => 'plugin','alert' => true ),
            'activate_theme'            => array( 'action' => 'activate','target_arg' => 'slug',    'alert' => true ),
            // Options — MEDIUM
            'update_option'             => array( 'action' => 'option',  'target_arg' => 'name',    'alert' => false ),
            'update_customizer_settings'=> array( 'action' => 'option',  'target_arg' => null,      'alert' => false ),
            'update_elementor_globals'  => array( 'action' => 'option',  'target_arg' => null,      'alert' => false ),
            // Bulk changes — MEDIUM
            'search_replace'            => array( 'action' => 'search_replace', 'target_arg' => 'search', 'alert' => true ),
            // Content writes — LOW (logged but no alert)
            'create_post'               => array( 'action' => 'write',   'target_arg' => 'title',   'alert' => false ),
            'update_post'               => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            'delete_post'               => array( 'action' => 'delete',  'target_arg' => 'id',      'alert' => false ),
            'set_elementor_data'        => array( 'action' => 'write',   'target_arg' => 'page_id', 'alert' => false ),
            'append_elementor_section'  => array( 'action' => 'write',   'target_arg' => 'page_id', 'alert' => false ),
            'copy_elementor_section'    => array( 'action' => 'write',   'target_arg' => null,      'alert' => false ),
            'apply_template'            => array( 'action' => 'write',   'target_arg' => 'page_id', 'alert' => false ),
            'save_as_template'          => array( 'action' => 'write',   'target_arg' => 'name',    'alert' => false ),
            'update_elementor_widget'   => array( 'action' => 'write',   'target_arg' => 'page_id', 'alert' => false ),
            'init_elementor_page'       => array( 'action' => 'write',   'target_arg' => 'page_id', 'alert' => false ),
            'finalize_elementor_page'   => array( 'action' => 'write',   'target_arg' => 'page_id', 'alert' => false ),
            'upload_media_from_url'     => array( 'action' => 'write',   'target_arg' => 'url',     'alert' => false ),
            'send_email'                => array( 'action' => 'write',   'target_arg' => 'to',      'alert' => false ),
            // Menus
            'create_menu'               => array( 'action' => 'write',   'target_arg' => 'name',    'alert' => false ),
            'update_menu'               => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            // ACF
            'update_acf_fields'         => array( 'action' => 'write',   'target_arg' => 'post_id', 'alert' => false ),
            // Taxonomies
            'create_category'           => array( 'action' => 'write',   'target_arg' => 'name',    'alert' => false ),
            'update_category'           => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            'create_tag'                => array( 'action' => 'write',   'target_arg' => 'name',    'alert' => false ),
            'update_tag'                => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            // Comments
            'update_comment_status'     => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            // Backups
            'backup_post'               => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            'restore_post'              => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => true  ),
            // WooCommerce
            'wc_update_product'         => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            'wc_update_order_status'    => array( 'action' => 'write',   'target_arg' => 'id',      'alert' => false ),
            // Elementor templates (WP native)
            'create_elementor_template' => array( 'action' => 'write',   'target_arg' => 'title',   'alert' => false ),
            'apply_elementor_template'  => array( 'action' => 'write',   'target_arg' => 'page_id', 'alert' => false ),
        );
    }

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . 'claude_mcp_activity';
    }

    /** Called from the plugin's activation hook — idempotent via dbDelta. */
    public static function install_schema() {
        global $wpdb;
        if ( (int) get_option( self::SCHEMA_VERSION_OPTION ) >= self::SCHEMA_VERSION ) return;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table   = self::table_name();
        $charset = $wpdb->get_charset_collate();
        $sql     = "CREATE TABLE $table (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            created_at DATETIME NOT NULL,
            user_id    BIGINT UNSIGNED NOT NULL DEFAULT 0,
            user_login VARCHAR(60) NOT NULL DEFAULT '',
            tool       VARCHAR(64) NOT NULL,
            action     VARCHAR(32) NOT NULL,
            target     VARCHAR(500) NOT NULL DEFAULT '',
            ip         VARCHAR(45) NOT NULL DEFAULT '',
            meta       TEXT NULL,
            PRIMARY KEY  (id),
            KEY created_at (created_at),
            KEY user_id (user_id),
            KEY tool (tool)
        ) $charset;";
        dbDelta( $sql );
        update_option( self::SCHEMA_VERSION_OPTION, self::SCHEMA_VERSION );
    }

    /**
     * Record one event. Called from Claude_MCP_Tools::execute_tool() right
     * after a successful dispatch of a logged tool.
     */
    public static function record( $tool, $args, $result = null ) {
        $catalogue = self::logged_tools();
        if ( ! isset( $catalogue[ $tool ] ) ) return;

        global $wpdb;
        $table = self::table_name();
        $user  = wp_get_current_user();
        $def   = $catalogue[ $tool ];

        $target_arg = $def['target_arg'];
        $target = '';
        if ( $target_arg && isset( $args[ $target_arg ] ) ) {
            $target = is_scalar( $args[ $target_arg ] ) ? (string) $args[ $target_arg ] : wp_json_encode( $args[ $target_arg ] );
        }

        $row = array(
            'created_at' => current_time( 'mysql', true ),
            'user_id'    => $user ? (int) $user->ID : 0,
            'user_login' => $user ? substr( $user->user_login, 0, 60 ) : '',
            'tool'       => $tool,
            'action'     => $def['action'],
            'target'     => substr( (string) $target, 0, 500 ),
            'ip'         => self::client_ip(),
            'meta'       => $result && is_array( $result ) ? wp_json_encode( array_intersect_key( $result, array_flip( array( 'success', 'id', 'template_slug' ) ) ) ) : null,
        );
        $wpdb->insert( $table, $row );

        // Email alert for high-risk actions, if enabled.
        if ( ! empty( $def['alert'] ) && self::alerts_enabled() ) {
            self::send_alert( $row );
        }
    }

    /** Latest N rows, newest first. */
    public static function recent( $limit = 100, $tool = '' ) {
        global $wpdb;
        $table = self::table_name();
        $limit = max( 1, min( 500, (int) $limit ) );

        if ( $tool ) {
            $sql = $wpdb->prepare( "SELECT * FROM $table WHERE tool = %s ORDER BY id DESC LIMIT %d", $tool, $limit );
        } else {
            $sql = $wpdb->prepare( "SELECT * FROM $table ORDER BY id DESC LIMIT %d", $limit );
        }
        return $wpdb->get_results( $sql, ARRAY_A ) ?: array();
    }

    /** Row count — for the Dashboard header stat. */
    public static function count_all() {
        global $wpdb;
        return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table_name() );
    }

    /** Prune: keep most recent 10,000 rows OR 90 days, whichever is older. */
    public static function prune() {
        global $wpdb;
        $table = self::table_name();

        $wpdb->query( "DELETE FROM $table WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 90 DAY)" );

        $total = self::count_all();
        if ( $total > 10000 ) {
            $cut = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table ORDER BY id DESC LIMIT 1 OFFSET %d",
                10000
            ) );
            if ( $cut > 0 ) {
                $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE id <= %d", $cut ) );
            }
        }
    }

    public static function clear_all() {
        global $wpdb;
        $wpdb->query( 'TRUNCATE TABLE ' . self::table_name() );
    }

    /* ── Email alerts ───────────────────────────────────────────── */

    const ALERT_ENABLED_OPTION = 'claude_mcp_alerts_enabled';
    const ALERT_RECIPIENT_OPTION = 'claude_mcp_alerts_recipient';
    const ALERT_THROTTLE_TRANSIENT = 'claude_mcp_alert_throttle';

    public static function alerts_enabled() {
        $opt = get_option( self::ALERT_ENABLED_OPTION, '1' );
        return $opt === '1' || $opt === 1 || $opt === true;
    }

    public static function alert_recipient() {
        $r = get_option( self::ALERT_RECIPIENT_OPTION );
        return $r ?: get_option( 'admin_email' );
    }

    protected static function send_alert( $row ) {
        // Throttle: at most one email per minute per tool, to avoid storms
        // when Claude does a batch of writes in quick succession.
        $throttle_key = self::ALERT_THROTTLE_TRANSIENT . '_' . $row['tool'];
        if ( get_transient( $throttle_key ) ) return;
        set_transient( $throttle_key, 1, 60 );

        $to      = self::alert_recipient();
        if ( ! $to ) return;

        $site    = parse_url( home_url(), PHP_URL_HOST );
        $subject = sprintf( '[Claude MCP · %s] %s on %s', $site, $row['tool'], $row['target'] );
        $time    = $row['created_at'] . ' UTC';
        $actor   = $row['user_login'] ? $row['user_login'] : 'unknown';
        $ip      = $row['ip'] ?: 'unknown';

        $body  = "Claude just did this on your site:\n\n";
        $body .= "  Tool:     {$row['tool']}\n";
        $body .= "  Action:   {$row['action']}\n";
        $body .= "  Target:   {$row['target']}\n";
        $body .= "  When:     {$time}\n";
        $body .= "  WP user:  {$actor}\n";
        $body .= "  IP:       {$ip}\n\n";
        $body .= "If this wasn't expected, revoke the token in Claude MCP → Auth and check the activity log.\n\n";
        $body .= "Activity log: " . admin_url( 'admin.php?page=claude-mcp#tab-activity' ) . "\n";

        wp_mail( $to, $subject, $body );
    }

    protected static function client_ip() {
        $candidates = array( 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' );
        foreach ( $candidates as $k ) {
            if ( ! empty( $_SERVER[ $k ] ) ) {
                $ip = trim( explode( ',', $_SERVER[ $k ] )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
            }
        }
        return '';
    }
}
