<?php
/**
 * Claude_MCP_Permissions
 *
 * Admin-controlled on/off toggles for the destructive / sensitive tools.
 *
 * Design:
 *   - Fresh installs → every toggle OFF (safe-by-default for third-party distribution).
 *   - Upgrades from pre-30.5.0 → every toggle ON (preserve existing operator's workflow).
 *   - Admin changes toggles in the "Permissions" tab under Claude MCP → Dashboard.
 *
 * Enforced in Claude_MCP_Tools::execute_tool() before the switch statement.
 * Blocked tools return a WP_Error naming the specific toggle to flip.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_Permissions {

    const OPTION          = 'claude_mcp_permissions';
    const VERSION_MARKER  = 'claude_mcp_perm_initialized';

    /**
     * The 8 toggles. Each entry:
     *   label     — short name shown in the admin UI
     *   warning   — risk level: 'high' | 'medium' | 'low' (drives colour and copy)
     *   desc      — one-line explanation of what the toggle unlocks
     *   tools     — array of tool names this toggle controls
     */
    public static function catalogue() {
        return array(
            'read_theme_files' => array(
                'label'   => 'Read theme files',
                'warning' => 'medium',
                'desc'    => 'Let Claude read PHP, CSS, and JS files inside the active theme. Code can contain secrets.',
                'tools'   => array( 'read_theme_file' ),
            ),
            'write_theme_files' => array(
                'label'   => 'Write theme files',
                'warning' => 'high',
                'desc'    => 'Let Claude write PHP, CSS, and JS files inside the active theme. This enables arbitrary code execution — only turn on if you trust everyone with admin access.',
                'tools'   => array( 'write_theme_file' ),
            ),
            'read_plugin_files' => array(
                'label'   => 'Read plugin files',
                'warning' => 'medium',
                'desc'    => 'Let Claude list and read files inside any installed plugin. Plugin code often contains API keys and secrets.',
                'tools'   => array( 'read_plugin_file', 'list_plugin_files' ),
            ),
            'write_plugin_files' => array(
                'label'   => 'Write plugin files',
                'warning' => 'high',
                'desc'    => 'Let Claude write files inside any installed plugin. This enables arbitrary code execution — only turn on if you trust everyone with admin access.',
                'tools'   => array( 'write_plugin_file' ),
            ),
            'install_themes_plugins' => array(
                'label'   => 'Install plugins and themes',
                'warning' => 'high',
                'desc'    => 'Let Claude download and install new plugins or themes from WordPress.org or a URL. Third-party code lands on your server.',
                'tools'   => array( 'install_plugin', 'install_theme' ),
            ),
            'manage_themes_plugins' => array(
                'label'   => 'Activate / deactivate plugins and themes',
                'warning' => 'medium',
                'desc'    => 'Let Claude activate or deactivate plugins and switch the active theme. A malicious caller could disable your security plugins.',
                'tools'   => array( 'activate_plugin', 'deactivate_plugin', 'activate_theme' ),
            ),
            'modify_options' => array(
                'label'   => 'Modify WordPress options and customizer settings',
                'warning' => 'medium',
                'desc'    => 'Let Claude read and write entries in wp_options and theme_mods. Can change site URL, admin email, and other critical settings.',
                'tools'   => array( 'update_option', 'update_customizer_settings', 'update_elementor_globals' ),
            ),
            'search_replace' => array(
                'label'   => 'Site-wide search and replace',
                'warning' => 'medium',
                'desc'    => 'Let Claude run a search-and-replace across all posts, pages, and option values. Hard to undo if mistaken.',
                'tools'   => array( 'search_replace' ),
            ),
        );
    }

    /**
     * Build a tool-name → permission-key map for fast lookups.
     * Memoised per-request.
     */
    public static function tool_map() {
        static $map = null;
        if ( $map !== null ) return $map;
        $map = array();
        foreach ( self::catalogue() as $key => $def ) {
            foreach ( $def['tools'] as $tool ) {
                $map[ $tool ] = $key;
            }
        }
        return $map;
    }

    /** Return current permissions as [key => bool], with safe defaults filled in. */
    public static function all() {
        $stored = get_option( self::OPTION, array() );
        $out    = array();
        foreach ( array_keys( self::catalogue() ) as $k ) {
            $out[ $k ] = ! empty( $stored[ $k ] );
        }
        return $out;
    }

    /** True if the named permission key is enabled. */
    public static function is_allowed( $key ) {
        $all = self::all();
        return ! empty( $all[ $key ] );
    }

    /**
     * Gate called from Claude_MCP_Tools::execute_tool() before dispatch.
     * Returns null if the tool is allowed (either not controlled or toggle is ON),
     * or a WP_Error naming the toggle the admin must flip.
     */
    public static function check_tool( $tool_name ) {
        $map = self::tool_map();
        if ( ! isset( $map[ $tool_name ] ) ) return null; // not controlled → always allowed

        $key = $map[ $tool_name ];
        if ( self::is_allowed( $key ) ) return null;

        $cat   = self::catalogue();
        $label = $cat[ $key ]['label'] ?? $key;
        return new WP_Error(
            'permission_disabled',
            sprintf(
                'This tool (%s) is disabled by site policy. The WordPress administrator must enable "%s" under Claude MCP → Dashboard → Permissions.',
                $tool_name,
                $label
            ),
            array( 'status' => 403, 'permission_key' => $key, 'tool' => $tool_name )
        );
    }

    /**
     * Called once from the plugin's activation hook.
     * Fresh install → all OFF. Upgrade (option marker already present or an older
     * version marker exists) → all ON, so the current operator's workflow is unbroken.
     */
    public static function set_defaults( $existing_version = null ) {
        // If we've initialised before, do nothing — admin's choices stay.
        if ( get_option( self::VERSION_MARKER ) ) return;

        $catalogue = self::catalogue();
        $defaults  = array();

        // Decide default state. If any prior plugin version marker exists in the DB
        // (API key, templates, token store), this is an upgrade — preserve workflow.
        $looks_like_upgrade = $existing_version
            || get_option( 'claude_mcp_api_key' )
            || get_option( 'claude_mcp_tokens' )
            || get_option( 'claude_mcp_version' );

        $default_value = $looks_like_upgrade; // true = ON for upgrades, false = OFF for fresh
        foreach ( array_keys( $catalogue ) as $k ) {
            $defaults[ $k ] = $default_value;
        }
        update_option( self::OPTION, $defaults );
        update_option( self::VERSION_MARKER, 1 );
    }

    /** Admin saves the toggles form. */
    public static function save_from_post( $post ) {
        $new = array();
        foreach ( array_keys( self::catalogue() ) as $k ) {
            $new[ $k ] = ! empty( $post[ 'claude_mcp_perm_' . $k ] );
        }
        update_option( self::OPTION, $new );
        return $new;
    }
}
