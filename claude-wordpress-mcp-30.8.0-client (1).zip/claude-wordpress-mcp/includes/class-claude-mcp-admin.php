<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class Claude_MCP_Admin {

    public function init() {
        add_action( 'admin_menu',            array( $this, 'add_menu' ) );
        add_action( 'admin_init',            array( $this, 'handle_actions' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    public function add_menu() {
        // Top-level menu on the main sidebar (not buried under Settings).
        // Templates CPT + taxonomy attach themselves under this menu via show_in_menu.
        add_menu_page(
            'Claude MCP',
            'Claude MCP',
            'manage_options',
            'claude-mcp',
            array( $this, 'render_page' ),
            'dashicons-admin-generic',
            30
        );
        // Rename the auto-generated first submenu so it doesn't just say "Claude MCP".
        add_submenu_page(
            'claude-mcp',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'claude-mcp',
            array( $this, 'render_page' )
        );
    }

    public function handle_actions() {
        if ( isset( $_POST['claude_mcp_regenerate'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            update_option( 'claude_mcp_api_key', wp_generate_password( 48, false ) );
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&msg=regenerated' ) );
            exit;
        }
        if ( isset( $_POST['claude_mcp_clear_tokens'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            // v30.7.2+: revoke every token in the custom table (the actual store
            // since 30.5.1). Also clear the legacy option for any lingering rows
            // and the auth-codes + debug-log options as before.
            if ( class_exists( 'Claude_MCP_Token_Store' ) ) {
                Claude_MCP_Token_Store::revoke_all();
            }
            delete_option( 'claude_mcp_tokens' );
            delete_option( 'claude_mcp_auth_codes' );
            delete_option( 'claude_mcp_debug_log' );
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&msg=cleared' ) );
            exit;
        }
        if ( isset( $_POST['claude_mcp_reinstall_starter'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            $result = Claude_MCP_Templates::install_starter_pack( true );
            $count  = isset( $result['installed'] ) ? intval( $result['installed'] ) : 0;
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_starter=' . $count ) );
            exit;
        }
        if ( isset( $_POST['claude_mcp_rebuild_previews'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            $result = Claude_MCP_Templates::rebuild_all_previews();
            $count  = isset( $result['rebuilt'] ) ? intval( $result['rebuilt'] ) : 0;
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_previews=' . $count ) );
            exit;
        }

        // Save permission toggles.
        if ( isset( $_POST['claude_mcp_save_permissions'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            Claude_MCP_Permissions::save_from_post( $_POST );
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_perms_saved=1#tab-permissions' ) );
            exit;
        }

        // Save email-alert settings.
        if ( isset( $_POST['claude_mcp_save_alerts'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            update_option( Claude_MCP_Activity::ALERT_ENABLED_OPTION, ! empty( $_POST['claude_mcp_alerts_enabled'] ) ? '1' : '0' );
            $to = isset( $_POST['claude_mcp_alerts_recipient'] )
                ? sanitize_email( wp_unslash( $_POST['claude_mcp_alerts_recipient'] ) )
                : '';
            update_option( Claude_MCP_Activity::ALERT_RECIPIENT_OPTION, $to );
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_alerts_saved=1#tab-activity' ) );
            exit;
        }

        // Clear activity log.
        if ( isset( $_POST['claude_mcp_clear_activity'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            Claude_MCP_Activity::clear_all();
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_activity_cleared=1#tab-activity' ) );
            exit;
        }

        // Send a test alert email so admin can verify SMTP works.
        if ( isset( $_POST['claude_mcp_test_alert'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            // Prefer the recipient the admin typed in the form (even if unsaved),
            // falling back to the saved value or the site admin email.
            $posted = isset( $_POST['claude_mcp_alerts_recipient'] )
                ? sanitize_email( wp_unslash( $_POST['claude_mcp_alerts_recipient'] ) )
                : '';
            $to      = $posted ?: Claude_MCP_Activity::alert_recipient();
            $site    = parse_url( home_url(), PHP_URL_HOST );
            $subject = '[Claude MCP · ' . $site . '] Test alert email';
            $body    = "This is a test email from Claude WordPress MCP.\n\n";
            $body   .= "If you can read this, your site can send alert emails. You will receive similar messages when Claude writes to theme/plugin files, installs plugins, or performs other high-risk actions.\n\n";
            $body   .= "Site: " . home_url() . "\n";
            $body   .= "Time: " . current_time( 'mysql', true ) . " UTC\n";
            $ok = wp_mail( $to, $subject, $body );
            $flag = $ok ? 'claude_mcp_test_sent' : 'claude_mcp_test_failed';
            $target = add_query_arg(
                array( $flag => 1, 'to' => rawurlencode( $to ) ),
                admin_url( 'admin.php?page=claude-mcp' )
            ) . '#tab-activity';
            wp_redirect( $target );
            exit;
        }

        // Save license key (and verify immediately).
        if ( isset( $_POST['claude_mcp_save_license'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            $key = isset( $_POST['claude_mcp_license_key'] ) ? wp_unslash( $_POST['claude_mcp_license_key'] ) : '';
            Claude_MCP_License::set_key( $key );
            if ( Claude_MCP_License::is_managed() && Claude_MCP_License::key() ) {
                Claude_MCP_License::verify_now();
            }
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_license_saved=1#tab-license' ) );
            exit;
        }

        // Verify license on demand.
        if ( isset( $_POST['claude_mcp_verify_license'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            Claude_MCP_License::verify_now();
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_license_verified=1#tab-license' ) );
            exit;
        }

        // Export: stream a JSON file of all templates.
        if ( isset( $_POST['claude_mcp_export_templates'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            $bundle   = Claude_MCP_Templates::export_all();
            $hostname = preg_replace( '/[^a-z0-9\-]/i', '-', wp_parse_url( home_url(), PHP_URL_HOST ) );
            $filename = 'mcp-templates-' . $hostname . '-' . date( 'Y-m-d' ) . '.json';

            nocache_headers();
            header( 'Content-Type: application/json; charset=utf-8' );
            header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
            echo wp_json_encode( $bundle, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
            exit;
        }

        // Import: accept a JSON file upload.
        if ( isset( $_POST['claude_mcp_import_templates'] ) && check_admin_referer( 'claude_mcp_action' ) ) {
            $replace = ! empty( $_POST['claude_mcp_replace_existing'] );

            if ( empty( $_FILES['claude_mcp_import_file']['tmp_name'] ) ) {
                wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_import_error=' . rawurlencode( 'No file uploaded.' ) ) );
                exit;
            }

            $tmp  = $_FILES['claude_mcp_import_file']['tmp_name'];
            $size = filesize( $tmp );
            if ( $size === false || $size > 10 * 1024 * 1024 ) { // 10 MB cap
                wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_import_error=' . rawurlencode( 'File too large (max 10 MB).' ) ) );
                exit;
            }

            $raw     = file_get_contents( $tmp );
            $decoded = $raw ? json_decode( $raw, true ) : null;
            if ( ! is_array( $decoded ) ) {
                wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_import_error=' . rawurlencode( 'File is not valid JSON.' ) ) );
                exit;
            }

            $result   = Claude_MCP_Templates::import_bundle( $decoded, array( 'replace' => $replace ) );
            $summary  = sprintf(
                'imported=%d replaced=%d skipped=%d failed=%d',
                intval( $result['imported'] ),
                intval( $result['replaced'] ),
                intval( $result['skipped'] ),
                intval( $result['failed'] )
            );
            wp_redirect( admin_url( 'admin.php?page=claude-mcp&claude_mcp_import=' . rawurlencode( $summary ) ) );
            exit;
        }
    }

    public function enqueue_scripts( $hook ) {
        // Top-level menu → hook is 'toplevel_page_claude-mcp'.
        if ( $hook !== 'toplevel_page_claude-mcp' && $hook !== 'claude-mcp_page_claude-mcp' ) return;
        wp_enqueue_style( 'claude-mcp-admin', CLAUDE_MCP_PLUGIN_URL . 'assets/admin.css', array(), CLAUDE_MCP_VERSION );
    }

    private function tool_groups() {
        $wc_note    = class_exists( 'WooCommerce' ) ? '' : ' <span class="cmcp-badge-off">WC inactive</span>';
        $acf_note   = function_exists( 'get_field' )  ? '' : ' <span class="cmcp-badge-off">ACF inactive</span>';

        return array(
            array(
                'icon'  => '📊',
                'label' => 'Token Efficiency',
                'color' => '#7c3aed',
                'desc'  => 'v28 — reduce Claude usage by 60–96%',
                'tools' => array(
                    array( 'context_summary',            'Full site overview in one call — pages, posts, plugins, menus. Use at session start instead of 4+ separate calls.' ),
                    array( 'get_posts <small>fields=</small>',  'Filter returned fields: <code>fields=id,title</code> returns only those keys. Saves ~60% on large post lists.' ),
                    array( 'get_elementor_data <small>summary=true</small>', 'Returns compact structure instead of full JSON blob. Saves up to 96% on large pages.' ),
                    array( 'Response cap (30KB)',         'Every response is automatically capped at 30KB with a truncation notice, preventing accidental token bleed.' ),
                    array( 'Null stripping',              'All null values stripped from responses before sending — reduces payload size across every tool call.' ),
                ),
            ),
            array(
                'icon'  => '📝',
                'label' => 'Posts & Pages',
                'color' => '#2563eb',
                'desc'  => 'Core content management',
                'tools' => array(
                    array( 'get_site_info',          'WP version, theme, active plugins, Elementor/WC/ACF versions, capability flags, MCP version.' ),
                    array( 'get_posts',              'List posts. Filter by status, category, search. Use <code>fields=</code> to limit returned data.' ),
                    array( 'get_post',               'Single post. Pass <code>include_elementor=true</code> for full JSON or <code>include_content=true</code> for HTML.' ),
                    array( 'create_post',            'Create post or page with Elementor data, SEO meta (Yoast/RankMath), categories, tags, featured image.' ),
                    array( 'update_post',            'Update any field of an existing post. For Elementor pages use <code>elementor_data</code>, not <code>content</code>.' ),
                    array( 'delete_post',            'Trash or permanently delete a post.' ),
                    array( 'get_pages',              'List pages by menu order. Use <code>fields=</code> to limit data.' ),
                    array( 'get_scheduled_posts',    'List posts in <em>future</em> status with their scheduled publish dates.' ),
                    array( 'get_media',              'List media library items filtered by type or search.' ),
                    array( 'upload_media_from_url',  'Upload a file from any public URL directly to the media library.' ),
                ),
            ),
            array(
                'icon'  => '🏷️',
                'label' => 'Taxonomy & Comments',
                'color' => '#0891b2',
                'desc'  => 'Categories, tags, comments',
                'tools' => array(
                    array( 'get_categories',         'List all categories with counts and parent relationships.' ),
                    array( 'create_category',        'Create a category with optional parent.' ),
                    array( 'update_category',        'Update a category name, slug, description or parent.' ),
                    array( 'get_tags',               'List all tags.' ),
                    array( 'create_tag',             'Create a new tag.' ),
                    array( 'update_tag',             'Update an existing tag.' ),
                    array( 'get_comments',           'List comments filtered by status and post.' ),
                    array( 'update_comment_status',  'Approve, hold, spam or trash a comment.' ),
                ),
            ),
            array(
                'icon'  => '⚙️',
                'label' => 'Site Options',
                'color' => '#059669',
                'desc'  => 'WordPress options — whitelisted keys only',
                'tools' => array(
                    array( 'get_option',             'Read a WordPress option. Whitelisted: blogname, timezone, permalink_structure, posts_per_page, thumbnail sizes, Elementor options, and more.' ),
                    array( 'update_option',          'Update a WordPress option (same whitelist).' ),
                    array( 'search_replace',         'Find &amp; replace across titles, content, excerpts and post meta (incl. Elementor JSON). Supports <code>dry_run=true</code>.' ),
                ),
            ),
            array(
                'icon'  => '🧭',
                'label' => 'Navigation Menus',
                'color' => '#d97706',
                'desc'  => 'v27 — full menu management',
                'tools' => array(
                    array( 'get_menus',              'List all nav menus with items (title, URL, parent, order) and theme location assignments.' ),
                    array( 'create_menu',            'Create a nav menu and assign to a theme location.' ),
                    array( 'update_menu',            'Replace all items in a menu. Supports parent/child nesting.' ),
                ),
            ),
            array(
                'icon'  => '🎨',
                'label' => 'Customizer',
                'color' => '#db2777',
                'desc'  => 'v27 — theme mods and branding',
                'tools' => array(
                    array( 'get_customizer_settings',    'Read all theme_mods for the active theme — colours, fonts, logo, layout options.' ),
                    array( 'update_customizer_settings', 'Write one or more theme_mods. Changes apply immediately site-wide.' ),
                ),
            ),
            array(
                'icon'  => '📁',
                'label' => 'Theme &amp; Plugin Files',
                'color' => '#7c3aed',
                'desc'  => 'v27 — read and write files directly',
                'tools' => array(
                    array( 'read_theme_file',        'Read any file from the active theme (e.g. <code>functions.php</code>, <code>style.css</code>).' ),
                    array( 'write_theme_file',       'Write a theme file. Original backed up as <code>.bak</code> automatically.' ),
                    array( 'read_plugin_file',       'Read any file inside a plugin. Slugs with spaces (e.g. <em>Claude MCP</em>) are supported.' ),
                    array( 'write_plugin_file',      'Write a plugin file. Original backed up as <code>.bak</code> automatically. Enables live plugin iteration without zip uploads.' ),
                    array( 'list_plugin_files',      'List all files in a plugin directory. Use <code>ext=php</code> to filter. Capped at 200 results.' ),
                ),
            ),
            array(
                'icon'  => '📋',
                'label' => 'Advanced Custom Fields',
                'color' => '#0891b2',
                'desc'  => 'v27 — requires ACF plugin' . $acf_note,
                'tools' => array(
                    array( 'get_acf_fields',         'Get all ACF field values for a post. Returns only fields registered in a field group.' ),
                    array( 'update_acf_fields',      'Update ACF field values by field name or key.' ),
                    array( 'get_acf_field_groups',   'List all ACF field groups and their field definitions (key, name, label, type).' ),
                ),
            ),
            array(
                'icon'  => '🩺',
                'label' => 'Diagnostics',
                'color' => '#dc2626',
                'desc'  => 'v27 — debugging and auditing',
                'tools' => array(
                    array( 'get_error_log',          'Read last N lines of <code>wp-content/debug.log</code>. Newest first. Optional filter string.' ),
                    array( 'audit_seo',              'Per-post SEO audit: meta title/desc, featured image alt, word count, headings. Scored 0–100, sorted worst first.' ),
                    array( 'get_broken_links',       'Scan post content for broken links (HTTP 4xx/5xx). Keep <code>per_page</code> low for speed.' ),
                ),
            ),
            array(
                'icon'  => '🛠️',
                'label' => 'Utilities',
                'color' => '#64748b',
                'desc'  => 'v27 — backups, email, snapshots',
                'tools' => array(
                    array( 'backup_post',            'Snapshot a post\'s title, content and Elementor data before editing. Returns a <code>backup_id</code>. Keeps last 10 per post.' ),
                    array( 'restore_post',           'Restore a post from a saved snapshot. Reverts title, content, Elementor data and regenerates CSS.' ),
                    array( 'list_backups',           'List all saved backups for a post.' ),
                    array( 'send_email',             'Send an email via <code>wp_mail()</code>. Useful for testing templates or sending admin notifications.' ),
                ),
            ),
            array(
                'icon'  => '⚡',
                'label' => 'Elementor — Page Building',
                'color' => '#e44f2a',
                'desc'  => 'Full Elementor control — widgets, sections, globals',
                'tools' => array(
                    array( 'get_page_structure',        '<strong>Start here.</strong> Lightweight layout overview with section/widget IDs. ~95% fewer tokens than get_elementor_data. Always call before any edit.' ),
                    array( 'get_elementor_data',        'Full raw Elementor JSON. WARNING: 50–200KB on large pages. Pass <code>summary=true</code> for compact version.' ),
                    array( 'update_elementor_widget',   'Update a single widget\'s settings by its ID. Token-efficient targeted edits — no full-page replacement needed.' ),
                    array( 'set_elementor_data',        'Replace all Elementor data on a page in one call. Use for small pages under 50KB.' ),
                    array( 'init_elementor_page',       'Step 1 of chunked build — clears page data and sets template.' ),
                    array( 'append_elementor_section',  'Step 2 — append one section. Call repeatedly, one section at a time.' ),
                    array( 'finalize_elementor_page',   'Step 3 — regenerate Elementor CSS and purge all caches.' ),
                    array( 'copy_elementor_section',    'Copy a section from one page to another. IDs are regenerated automatically to avoid collisions.' ),
                    array( 'get_elementor_globals',     'Read Elementor global colours and fonts (design tokens) from the Kit.' ),
                    array( 'update_elementor_globals',  'Update global colours or fonts. Changes propagate site-wide.' ),
                    array( 'qa_page',                   'Fetch live HTML and return structured QA report — sections, headings, buttons, pass/fail issues.' ),
                ),
            ),
            array(
                'icon'  => '🗂️',
                'label' => 'Elementor Templates',
                'color' => '#e44f2a',
                'desc'  => 'Template library management',
                'tools' => array(
                    array( 'get_elementor_templates',   'List all templates in the Elementor library, grouped by type: page, section, header, footer, popup, widget.' ),
                    array( 'create_elementor_template', 'Build a new template with Elementor data. Same format as building a page. All Pro types supported.' ),
                    array( 'get_elementor_template',    'Read a template\'s full Elementor JSON — useful before copying sections to a page.' ),
                    array( 'apply_elementor_template',  'Apply a template from the library onto any page. Element IDs regenerated automatically.' ),
                ),
            ),
            array(
                'icon'  => '🔌',
                'label' => 'Plugins &amp; Themes',
                'color' => '#2563eb',
                'desc'  => 'Install and manage extensions',
                'tools' => array(
                    array( 'list_plugins',           'List all installed plugins with status and version.' ),
                    array( 'install_plugin',         'Install a plugin from WordPress.org by slug. Optionally activate immediately.' ),
                    array( 'activate_plugin',        'Activate an installed plugin by its file path.' ),
                    array( 'deactivate_plugin',      'Deactivate a plugin.' ),
                    array( 'list_themes',            'List all installed themes with active status.' ),
                    array( 'install_theme',          'Install a theme from WordPress.org.' ),
                    array( 'activate_theme',         'Activate an installed theme.' ),
                ),
            ),
            array(
                'icon'  => '🛒',
                'label' => 'WooCommerce',
                'color' => '#7c2d8f',
                'desc'  => 'v27 — auto-detected when WC is active' . $wc_note,
                'tools' => array(
                    array( 'wc_get_products',        'List products. Filter by status, search, category.' ),
                    array( 'wc_get_product',         'Get a single product with price, stock, SKU, type and categories.' ),
                    array( 'wc_update_product',      'Update product price, stock, status or description.' ),
                    array( 'wc_get_orders',          'List orders. Filter by status or customer email.' ),
                    array( 'wc_get_order',           'Get a single order with line items, billing, total and payment method.' ),
                    array( 'wc_update_order_status', 'Update an order status (pending, processing, completed, cancelled, etc.).' ),
                ),
            ),
        );
    }

    public function render_page() {
        $api_key   = get_option( 'claude_mcp_api_key', '' );
        $mcp_url   = rest_url( 'claude-mcp/v1/mcp' );
        $token_url = rest_url( 'claude-mcp/v1/oauth/token' );
        $auth_url  = add_query_arg( 'claude_mcp_oauth', '1', get_bloginfo( 'url' ) );
        // v30.7.2+: active token count comes from the custom table, not
        // wp_options (which the v30.5.1 migration empties).
        $token_count = class_exists( 'Claude_MCP_Token_Store' )
            ? Claude_MCP_Token_Store::count_active()
            : count( get_option( 'claude_mcp_tokens', array() ) );
        $next_cron = wp_next_scheduled( 'claude_mcp_daily_cleanup' );
        $groups    = $this->tool_groups();
        $tool_count = 0;
        foreach ( $groups as $g ) { $tool_count += count( $g['tools'] ); }
        ?>
        <div class="wrap claude-mcp-wrap">

        <div class="cmcp-header">
            <div class="cmcp-header-inner">
                <span class="cmcp-logo">🤖</span>
                <div>
                    <h1>Claude WordPress MCP</h1>
                    <p>v<?php echo esc_html( CLAUDE_MCP_VERSION ); ?> &nbsp;·&nbsp; <?php echo esc_html( $tool_count ); ?> tools &nbsp;·&nbsp; <?php echo (int) $token_count; ?> active session(s)</p>
                </div>
            </div>
            <div class="cmcp-tabs">
                <button class="cmcp-tab active" data-tab="tools">🛠️ All Tools</button>
                <button class="cmcp-tab" data-tab="connect">🔗 Connect</button>
                <button class="cmcp-tab" data-tab="auth">🔑 Auth &amp; Tokens</button>
                <button class="cmcp-tab" data-tab="permissions">🔒 Permissions</button>
                <button class="cmcp-tab" data-tab="activity">📋 Activity</button>
                <button class="cmcp-tab" data-tab="license">📜 License</button>
                <button class="cmcp-tab" data-tab="tips">💡 Tips</button>
            </div>
        </div>

        <?php if ( isset( $_GET['msg'] ) && $_GET['msg'] === 'regenerated' ) : ?>
            <div class="notice notice-success is-dismissible"><p>✅ API Key regenerated. Reconnect Claude.ai.</p></div>
        <?php endif; ?>
        <?php if ( isset( $_GET['msg'] ) && $_GET['msg'] === 'cleared' ) : ?>
            <div class="notice notice-success is-dismissible"><p>✅ Tokens and log cleared.</p></div>
        <?php endif; ?>
        <?php if ( isset( $_GET['claude_mcp_previews'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p>✅ Rebuilt <?php echo intval( $_GET['claude_mcp_previews'] ); ?> template preview page(s).</p></div>
        <?php endif; ?>
        <?php if ( isset( $_GET['claude_mcp_import'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p>✅ Template import finished: <code><?php echo esc_html( $_GET['claude_mcp_import'] ); ?></code></p></div>
        <?php endif; ?>
        <?php if ( isset( $_GET['claude_mcp_import_error'] ) ) : ?>
            <div class="notice notice-error is-dismissible"><p>❌ Import failed: <?php echo esc_html( $_GET['claude_mcp_import_error'] ); ?></p></div>
        <?php endif; ?>

        <!-- ── TAB: ALL TOOLS ── -->
        <div class="cmcp-tab-content active" id="tab-tools">

            <div class="cmcp-stats-row">
                <div class="cmcp-stat">
                    <span class="cmcp-stat-num"><?php echo esc_html( $tool_count ); ?></span>
                    <span class="cmcp-stat-label">Total Tools</span>
                </div>
                <div class="cmcp-stat">
                    <span class="cmcp-stat-num"><?php echo count( $groups ); ?></span>
                    <span class="cmcp-stat-label">Categories</span>
                </div>
                <div class="cmcp-stat cmcp-stat-green">
                    <span class="cmcp-stat-num">96%</span>
                    <span class="cmcp-stat-label">Max Token Saving</span>
                </div>
                <div class="cmcp-stat <?php echo class_exists('WooCommerce') ? 'cmcp-stat-green' : 'cmcp-stat-gray'; ?>">
                    <span class="cmcp-stat-num"><?php echo class_exists('WooCommerce') ? '✓' : '—'; ?></span>
                    <span class="cmcp-stat-label">WooCommerce</span>
                </div>
                <div class="cmcp-stat <?php echo function_exists('get_field') ? 'cmcp-stat-green' : 'cmcp-stat-gray'; ?>">
                    <span class="cmcp-stat-num"><?php echo function_exists('get_field') ? '✓' : '—'; ?></span>
                    <span class="cmcp-stat-label">ACF</span>
                </div>
                <div class="cmcp-stat cmcp-stat-green">
                    <span class="cmcp-stat-num"><?php echo defined('ELEMENTOR_VERSION') ? '✓' : '—'; ?></span>
                    <span class="cmcp-stat-label">Elementor</span>
                </div>
            </div>

            <?php foreach ( $groups as $group ) : ?>
            <div class="cmcp-group">
                <div class="cmcp-group-header" style="border-left-color: <?php echo esc_attr( $group['color'] ); ?>">
                    <span class="cmcp-group-icon"><?php echo $group['icon']; ?></span>
                    <div>
                        <strong><?php echo wp_kses_post( $group['label'] ); ?></strong>
                        <span class="cmcp-group-desc"><?php echo wp_kses_post( $group['desc'] ); ?></span>
                    </div>
                    <span class="cmcp-group-count" style="background:<?php echo esc_attr( $group['color'] ); ?>"><?php echo count( $group['tools'] ); ?></span>
                </div>
                <div class="cmcp-tool-list">
                    <?php foreach ( $group['tools'] as $tool ) : ?>
                    <div class="cmcp-tool">
                        <code class="cmcp-tool-name"><?php echo wp_kses_post( $tool[0] ); ?></code>
                        <span class="cmcp-tool-desc"><?php echo wp_kses_post( $tool[1] ); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>

        </div><!-- /tab-tools -->

        <!-- ── TAB: CONNECT ── -->
        <div class="cmcp-tab-content" id="tab-connect">
            <div class="cmcp-card">
                <h2>Connect to Claude.ai</h2>
                <p>Go to <a href="https://claude.ai/settings/connectors" target="_blank"><strong>claude.ai → Settings → Connectors</strong></a> → Add Custom Connector:</p>
                <table class="cmcp-table">
                    <tr><th>Name</th><td><code>My WordPress</code></td></tr>
                    <tr>
                        <th>Remote MCP URL</th>
                        <td>
                            <code class="cmcp-copyable" id="mcp-url"><?php echo esc_html( $mcp_url ); ?></code>
                            <button class="button button-small cmcp-copy" data-target="mcp-url">Copy</button>
                        </td>
                    </tr>
                    <tr><th>OAuth Client ID</th><td><code>claude</code> <em>(or leave blank)</em></td></tr>
                    <tr><th>OAuth Client Secret</th><td><em>Leave blank</em></td></tr>
                </table>
                <p class="description">When Claude connects it opens an authorization page on your site. Log in as admin and click <strong>Allow Access</strong>.</p>
            </div>

            <div class="cmcp-card">
                <h2>OAuth Endpoints</h2>
                <table class="cmcp-table">
                    <tr>
                        <th>Authorization URL</th>
                        <td><code class="cmcp-copyable" id="auth-url"><?php echo esc_html( $auth_url ); ?></code>
                        <button class="button button-small cmcp-copy" data-target="auth-url">Copy</button></td>
                    </tr>
                    <tr>
                        <th>Token URL</th>
                        <td><code class="cmcp-copyable" id="tok-url"><?php echo esc_html( $token_url ); ?></code>
                        <button class="button button-small cmcp-copy" data-target="tok-url">Copy</button></td>
                    </tr>
                    <tr>
                        <th>Health Check</th>
                        <td><a href="<?php echo esc_url( rest_url('claude-mcp/v1/health') ); ?>" target="_blank" class="button button-secondary">Open ↗</a></td>
                    </tr>
                </table>
            </div>
        </div><!-- /tab-connect -->

        <!-- ── TAB: AUTH ── -->
        <div class="cmcp-tab-content" id="tab-auth">
            <div class="cmcp-card">
                <h2>🔑 API Key (Fallback Auth)</h2>
                <p>Use as <code>Authorization: Bearer &lt;key&gt;</code> or <code>X-API-Key: &lt;key&gt;</code> header.<br>
                <strong style="color:#c00">Never append as a URL query parameter — it exposes the key in server logs.</strong></p>
                <code class="cmcp-key" id="api-key"><?php echo esc_html( $api_key ); ?></code>
                <button class="button button-small cmcp-copy" data-target="api-key" style="margin-left:8px">Copy Key</button>
                <form method="post" style="margin-top:14px;display:inline-block">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <input type="submit" name="claude_mcp_regenerate" class="button" value="🔄 Regenerate Key"
                        onclick="return confirm('This invalidates the fallback API key only. Any client using X-API-Key header will need the new key. OAuth bearer tokens are NOT affected — use \u0022Revoke All Tokens\u0022 for those. Continue?')">
                </form>
            </div>

            <div class="cmcp-card">
                <h2>🛡️ Token Management</h2>
                <p><strong><?php echo (int) $token_count; ?></strong> active OAuth token(s). Tokens stored as SHA-256 hashes in a dedicated table — raw values never saved to DB.</p>
                <p>Next auto-cleanup: <strong><?php echo $next_cron ? human_time_diff( $next_cron ) . ' from now' : 'not scheduled'; ?></strong></p>
                <p>Rate limit: <strong><?php echo CLAUDE_MCP_RATE_LIMIT; ?></strong> tool calls/minute per token &nbsp;·&nbsp;
                   Response cap: <strong><?php echo defined('CLAUDE_MCP_MAX_RESPONSE_BYTES') ? CLAUDE_MCP_MAX_RESPONSE_BYTES : 30000; ?>B</strong></p>
                <form method="post" style="margin-top:12px">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <input type="submit" name="claude_mcp_clear_tokens" class="button button-secondary"
                        value="🗑️ Revoke All Tokens"
                        onclick="return confirm('This disconnects all Claude sessions. Continue?')">
                </form>
            </div>

            <div class="cmcp-card">
                <h2>📦 Starter Templates</h2>
                <?php
                $tpl_count = wp_count_posts( Claude_MCP_Templates::CPT );
                $published = isset( $tpl_count->publish ) ? intval( $tpl_count->publish ) : 0;
                $installed = get_option( Claude_MCP_Templates::STARTER_INSTALLED_OPTION );
                ?>
                <p><strong><?php echo $published; ?></strong> template(s) in the library.
                <?php if ( $installed ) : ?>
                    Starter pack installed <?php echo esc_html( human_time_diff( $installed ) ); ?> ago.
                <?php else : ?>
                    <span style="color:#c00">Starter pack not yet installed.</span>
                <?php endif; ?>
                </p>
                <p><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . Claude_MCP_Templates::CPT ) ); ?>" class="button button-secondary">Manage Templates</a></p>
                <form method="post" style="margin-top:12px;display:inline-block">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <input type="submit" name="claude_mcp_reinstall_starter" class="button"
                        value="↻ Reinstall Starter Pack (40+ templates)"
                        onclick="return confirm('This re-imports the bundled starter templates (40+ sections across heroes, features, pricing, testimonials, team, CTA, FAQ, gallery, contact, footer). Existing templates with the same slug are skipped. Continue?')">
                </form>
                <form method="post" style="margin-top:12px;display:inline-block;margin-left:6px">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <input type="submit" name="claude_mcp_rebuild_previews" class="button"
                        value="🔄 Rebuild All Previews">
                </form>
                <p class="description" style="margin-top:10px;">
                    <strong>Reinstall Starter Pack</strong> re-imports bundled templates (safe — skips existing slugs).<br>
                    <strong>Rebuild All Previews</strong> regenerates the live preview page for every template — click this if "View live" links give 404.
                </p>

                <hr style="margin:18px 0 14px;">

                <h3 style="margin:0 0 10px;">📤 Export / Import</h3>
                <p class="description" style="margin-top:0;">Move templates between sites. Export from one site, import on another — nothing hardcoded in the plugin.</p>

                <form method="post" style="display:inline-block;margin-top:6px">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <input type="submit" name="claude_mcp_export_templates" class="button button-primary"
                        value="⬇ Export All Templates (.json)">
                </form>

                <form method="post" enctype="multipart/form-data" style="margin-top:14px;padding:12px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <p style="margin:0 0 8px;"><strong>Import templates from a .json file:</strong></p>
                    <input type="file" name="claude_mcp_import_file" accept=".json,application/json" required style="margin-bottom:8px">
                    <br>
                    <label style="display:inline-block;margin:6px 0 10px;">
                        <input type="checkbox" name="claude_mcp_replace_existing" value="1">
                        Replace existing templates with the same slug (otherwise skipped)
                    </label>
                    <br>
                    <input type="submit" name="claude_mcp_import_templates" class="button"
                        value="⬆ Import Templates"
                        onclick="return confirm('Import templates from this file? New templates will be added to the library.')">
                </form>
                <p class="description" style="margin-top:10px;">
                    The exported file contains full template JSON and is portable across any site running this plugin. Thumbnails (featured images) are not included — set them again after import if needed.
                </p>
            </div>
        </div><!-- /tab-auth -->

        <!-- ── TAB: PERMISSIONS ── -->
        <div class="cmcp-tab-content" id="tab-permissions">
            <div class="cmcp-card">
                <h2>🔒 Permissions</h2>
                <p class="cmcp-muted" style="margin-top:0;">
                    Fine-grained control over the destructive and sensitive tools. Fresh installs have every toggle <strong>OFF</strong>; upgrades from older versions have them <strong>ON</strong>. A disabled tool returns a clear error naming the toggle to flip.
                </p>

                <?php if ( isset( $_GET['claude_mcp_perms_saved'] ) ) : ?>
                    <div class="notice notice-success is-dismissible" style="margin:12px 0;"><p>✅ Permissions saved.</p></div>
                <?php endif; ?>

                <form method="post" style="margin-top:14px;">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <?php
                    $catalogue = Claude_MCP_Permissions::catalogue();
                    $current   = Claude_MCP_Permissions::all();
                    foreach ( $catalogue as $key => $def ) :
                        $enabled = ! empty( $current[ $key ] );
                        $badge_color = $def['warning'] === 'high' ? '#dc2626' : ( $def['warning'] === 'medium' ? '#f59e0b' : '#64748b' );
                        $badge_text  = $def['warning'] === 'high' ? '⚠ High risk' : ( $def['warning'] === 'medium' ? 'Medium risk' : 'Low risk' );
                        ?>
                        <div style="padding:14px 16px;margin-bottom:10px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;">
                            <label style="display:flex;align-items:flex-start;gap:12px;cursor:pointer;">
                                <input type="checkbox" name="claude_mcp_perm_<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $enabled ); ?> style="margin-top:4px;">
                                <span style="flex:1;">
                                    <span style="display:flex;align-items:center;gap:10px;margin-bottom:4px;">
                                        <strong style="font-size:14px;color:#0f172a;"><?php echo esc_html( $def['label'] ); ?></strong>
                                        <span style="font-size:11px;padding:2px 8px;background:<?php echo esc_attr( $badge_color ); ?>;color:#fff;border-radius:999px;font-weight:600;"><?php echo esc_html( $badge_text ); ?></span>
                                    </span>
                                    <span style="display:block;color:#475569;font-size:13px;line-height:1.5;"><?php echo esc_html( $def['desc'] ); ?></span>
                                    <span style="display:block;color:#94a3b8;font-size:11px;margin-top:4px;font-family:monospace;">Controls: <?php echo esc_html( implode( ', ', $def['tools'] ) ); ?></span>
                                </span>
                            </label>
                        </div>
                    <?php endforeach; ?>

                    <div style="margin-top:16px;">
                        <input type="submit" name="claude_mcp_save_permissions" class="button button-primary" value="💾 Save Permissions">
                    </div>
                </form>

                <div style="margin-top:20px;padding:12px 14px;background:#fef3c7;border-left:4px solid #f59e0b;border-radius:4px;font-size:13px;color:#78350f;">
                    <strong>Note:</strong> These toggles do not restrict tools that are always safe (reading posts, listing pages, uploading media, applying templates). They only control the destructive and sensitive tools listed above.
                </div>
            </div>
        </div><!-- /tab-permissions -->

        <!-- ── TAB: ACTIVITY ── -->
        <div class="cmcp-tab-content" id="tab-activity">
            <div class="cmcp-card">
                <h2>📋 Activity Log</h2>
                <p class="cmcp-muted" style="margin-top:0;">
                    Every write action (file edits, plugin installs, option changes, template saves, post edits) is recorded here. Reads are not logged. Rows older than 90 days are pruned automatically; up to 10,000 kept.
                </p>

                <?php if ( isset( $_GET['claude_mcp_alerts_saved'] ) ) : ?>
                    <div class="notice notice-success is-dismissible" style="margin:12px 0;"><p>✅ Alert settings saved.</p></div>
                <?php endif; ?>
                <?php if ( isset( $_GET['claude_mcp_activity_cleared'] ) ) : ?>
                    <div class="notice notice-success is-dismissible" style="margin:12px 0;"><p>✅ Activity log cleared.</p></div>
                <?php endif; ?>

                <!-- Email-alert settings -->
                <form method="post" style="margin:14px 0;padding:14px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;">
                    <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                    <h3 style="margin:0 0 10px;font-size:14px;">✉️ Email alerts</h3>
                    <label style="display:block;margin-bottom:8px;">
                        <input type="checkbox" name="claude_mcp_alerts_enabled" value="1" <?php checked( Claude_MCP_Activity::alerts_enabled() ); ?>>
                        <strong>Send an email on every high-risk action</strong>
                        <span class="cmcp-muted" style="font-size:12px;">(file writes, plugin install/activate/deactivate, theme activate, search &amp; replace)</span>
                    </label>
                    <label style="display:block;margin-bottom:10px;">
                        Send to:
                        <input type="email" name="claude_mcp_alerts_recipient" value="<?php echo esc_attr( Claude_MCP_Activity::alert_recipient() ); ?>" style="width:320px;" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>">
                        <span class="cmcp-muted" style="font-size:12px;">(blank = site admin email)</span>
                    </label>
                    <input type="submit" name="claude_mcp_save_alerts" class="button button-primary" value="💾 Save alert settings">
                    <input type="submit" name="claude_mcp_test_alert" class="button" value="✉️ Send test email" style="margin-left:6px;">
                    <span class="cmcp-muted" style="font-size:12px;margin-left:10px;">Alerts are throttled to one email per minute per tool to avoid storms during batch actions.</span>
                    <?php if ( isset( $_GET['claude_mcp_test_sent'] ) ) : ?>
                        <div style="margin-top:10px;padding:8px 12px;background:#dcfce7;color:#166534;border-left:3px solid #16a34a;border-radius:4px;font-size:13px;">
                            ✅ Test email dispatched<?php if ( ! empty( $_GET['to'] ) ) : ?> to <strong><?php echo esc_html( sanitize_email( wp_unslash( $_GET['to'] ) ) ); ?></strong><?php endif; ?>. If it does not arrive within 2 minutes, your host blocks or misconfigures outbound mail.
                        </div>
                    <?php endif; ?>
                    <?php if ( isset( $_GET['claude_mcp_test_failed'] ) ) : ?>
                        <div style="margin-top:10px;padding:8px 12px;background:#fee2e2;color:#991b1b;border-left:3px solid #dc2626;border-radius:4px;font-size:13px;">
                            ❌ Test email failed. <code>wp_mail()</code> returned false — check your SMTP plugin or host's mail configuration.
                        </div>
                    <?php endif; ?>
                </form>

                <!-- Activity table -->
                <?php $rows = Claude_MCP_Activity::recent( 100 ); ?>
                <?php if ( empty( $rows ) ) : ?>
                    <p class="cmcp-muted" style="padding:14px;background:#f8fafc;border-radius:6px;">No activity logged yet. Rows will appear here when Claude performs a write action.</p>
                <?php else : ?>
                    <div style="overflow-x:auto;border:1px solid #e5e7eb;border-radius:6px;">
                    <table class="widefat striped" style="margin:0;">
                        <thead>
                            <tr>
                                <th style="width:140px;">When (UTC)</th>
                                <th style="width:110px;">Tool</th>
                                <th style="width:80px;">Action</th>
                                <th>Target</th>
                                <th style="width:110px;">User</th>
                                <th style="width:120px;">IP</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ( $rows as $r ) : ?>
                            <tr>
                                <td style="font-family:monospace;font-size:12px;color:#475569;"><?php echo esc_html( $r['created_at'] ); ?></td>
                                <td style="font-family:monospace;font-size:12px;"><?php echo esc_html( $r['tool'] ); ?></td>
                                <td style="font-size:12px;"><?php echo esc_html( $r['action'] ); ?></td>
                                <td style="font-size:12px;word-break:break-word;max-width:400px;"><?php echo esc_html( substr( (string) $r['target'], 0, 200 ) ); ?></td>
                                <td style="font-size:12px;"><?php echo esc_html( $r['user_login'] ?: '—' ); ?></td>
                                <td style="font-family:monospace;font-size:12px;color:#64748b;"><?php echo esc_html( $r['ip'] ?: '—' ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>

                    <form method="post" style="margin-top:14px;">
                        <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                        <input type="submit" name="claude_mcp_clear_activity" class="button" value="🗑 Clear activity log" onclick="return confirm('Delete all activity log rows? This cannot be undone.')">
                        <span class="cmcp-muted" style="font-size:12px;margin-left:10px;">Total rows: <?php echo (int) Claude_MCP_Activity::count_all(); ?></span>
                    </form>
                <?php endif; ?>
            </div>
        </div><!-- /tab-activity -->

        <!-- ── TAB: LICENSE ── -->
        <div class="cmcp-tab-content" id="tab-license">
            <div class="cmcp-card">
                <h2>📜 License</h2>

                <?php
                $status       = Claude_MCP_License::status();
                $status_label = Claude_MCP_License::status_label( $status );
                $status_color = Claude_MCP_License::status_color( $status );
                $is_managed   = Claude_MCP_License::is_managed();
                $server       = Claude_MCP_License::server_url();
                $install_id   = Claude_MCP_License::install_id();
                $tier         = Claude_MCP_License::tier();
                $last         = Claude_MCP_License::last_check();
                $expires      = Claude_MCP_License::expires_at();
                $last_err     = Claude_MCP_License::last_error();
                ?>

                <?php if ( isset( $_GET['claude_mcp_license_saved'] ) ) : ?>
                    <div class="notice notice-success is-dismissible" style="margin:12px 0;"><p>✅ License key saved. Verification runs below.</p></div>
                <?php endif; ?>
                <?php if ( isset( $_GET['claude_mcp_license_verified'] ) ) : ?>
                    <div class="notice notice-success is-dismissible" style="margin:12px 0;"><p>✅ Verification complete. Status refreshed.</p></div>
                <?php endif; ?>

                <!-- Status card -->
                <div style="display:flex;gap:16px;align-items:center;padding:16px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;margin-bottom:16px;">
                    <div style="padding:12px 18px;background:<?php echo esc_attr( $status_color ); ?>;color:#fff;border-radius:999px;font-weight:600;font-size:14px;">
                        <?php echo esc_html( $status_label ); ?>
                    </div>
                    <div style="flex:1;">
                        <?php if ( ! $is_managed ) : ?>
                            <div style="color:#475569;font-size:14px;">This plugin build is <strong>not tied to a license server</strong>. All features run unrestricted.</div>
                            <div class="cmcp-muted" style="font-size:12px;margin-top:4px;">To make a licensed build, define <code>CLAUDE_MCP_LICENSE_SERVER</code> in <code>wp-config.php</code> or in the plugin bootstrap.</div>
                        <?php else : ?>
                            <div style="color:#0f172a;font-size:14px;">License server: <code><?php echo esc_html( $server ); ?></code></div>
                            <?php if ( $tier ) : ?>
                                <div style="color:#475569;font-size:13px;margin-top:4px;">Tier: <strong><?php echo esc_html( $tier ); ?></strong></div>
                            <?php endif; ?>
                            <?php if ( $expires ) : ?>
                                <div style="color:#475569;font-size:13px;margin-top:4px;">Expires: <?php echo esc_html( gmdate( 'Y-m-d H:i', $expires ) ); ?> UTC</div>
                            <?php endif; ?>
                            <?php if ( $last ) : ?>
                                <div class="cmcp-muted" style="font-size:12px;margin-top:4px;">Last check: <?php echo esc_html( gmdate( 'Y-m-d H:i', $last ) ); ?> UTC</div>
                            <?php endif; ?>
                            <?php if ( $last_err ) : ?>
                                <div style="color:#dc2626;font-size:12px;margin-top:6px;">Last error: <?php echo esc_html( $last_err ); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ( $is_managed ) : ?>
                    <!-- License key form -->
                    <form method="post" style="margin-bottom:16px;">
                        <?php wp_nonce_field( 'claude_mcp_action' ); ?>
                        <label style="display:block;margin-bottom:6px;font-weight:600;">License key</label>
                        <input type="text" name="claude_mcp_license_key" value="<?php echo esc_attr( Claude_MCP_License::key() ); ?>" style="width:420px;font-family:monospace;" placeholder="XXXX-XXXX-XXXX-XXXX">
                        <input type="submit" name="claude_mcp_save_license" class="button button-primary" value="💾 Save &amp; verify">
                        <input type="submit" name="claude_mcp_verify_license" class="button" value="🔄 Verify now">
                    </form>
                <?php endif; ?>

                <!-- Install ID (watermark) -->
                <div style="padding:12px 14px;background:#eff6ff;border-left:4px solid #2563eb;border-radius:4px;font-size:13px;color:#1e3a8a;">
                    <strong>Install ID:</strong> <code style="background:#fff;padding:2px 6px;border-radius:3px;"><?php echo esc_html( $install_id ); ?></code>
                    <div class="cmcp-muted" style="color:#475569;font-size:12px;margin-top:4px;">
                        This ID is sent with every verification. If a leaked copy of this plugin appears in the wild, this ID identifies the install it was taken from.
                    </div>
                </div>
            </div>
        </div><!-- /tab-license -->

        <!-- ── TAB: TIPS ── -->
        <div class="cmcp-tab-content" id="tab-tips">
            <div class="cmcp-card">
                <h2>💡 Token Efficiency Tips</h2>
                <div class="cmcp-tip-list">
                    <div class="cmcp-tip">
                        <span class="cmcp-tip-icon">🚀</span>
                        <div><strong>Start every session with <code>context_summary</code></strong><br>
                        Gets pages, posts, plugins, theme in one call. Saves ~83% vs 4 separate calls.</div>
                    </div>
                    <div class="cmcp-tip">
                        <span class="cmcp-tip-icon">⚡</span>
                        <div><strong>Use <code>get_page_structure</code> before any Elementor edit</strong><br>
                        Returns section/widget IDs in a compact format — 95% fewer tokens than <code>get_elementor_data</code>.</div>
                    </div>
                    <div class="cmcp-tip">
                        <span class="cmcp-tip-icon">🎯</span>
                        <div><strong>Use <code>update_elementor_widget</code> for targeted edits</strong><br>
                        Change one widget without dumping and replacing the full page JSON.</div>
                    </div>
                    <div class="cmcp-tip">
                        <span class="cmcp-tip-icon">📋</span>
                        <div><strong>Use <code>fields=</code> on <code>get_posts</code></strong><br>
                        <code>fields=id,title</code> returns only those 2 keys instead of all 9.</div>
                    </div>
                    <div class="cmcp-tip">
                        <span class="cmcp-tip-icon">🗂️</span>
                        <div><strong>Build reusable section templates</strong><br>
                        <code>create_elementor_template</code> then <code>apply_elementor_template</code> — build once, apply anywhere.</div>
                    </div>
                    <div class="cmcp-tip">
                        <span class="cmcp-tip-icon">💾</span>
                        <div><strong>Always <code>backup_post</code> before major edits</strong><br>
                        Instant restore if something goes wrong. Keeps last 10 snapshots per post.</div>
                    </div>
                </div>
            </div>

            <div class="cmcp-card">
                <h2>⚠️ Elementor Rules (enforced via MCP instructions)</h2>
                <ol class="cmcp-rules">
                    <li>Never put HTML or CSS in the post <code>content</code> field on Elementor pages.</li>
                    <li>All styling goes inside Elementor widget <code>settings</code> objects — not in <code>&lt;style&gt;</code> tags.</li>
                    <li>Never use the HTML widget unless explicitly asked.</li>
                    <li>Use native Elementor widgets: heading, text-editor, button, image, icon, divider, spacer.</li>
                    <li>Call <code>get_page_structure</code> first before building or editing any page.</li>
                    <li>Use <code>update_elementor_widget</code> for targeted edits — not full JSON replacement.</li>
                    <li>Call <code>backup_post</code> before any destructive Elementor operation.</li>
                </ol>
                <p class="description">These rules are sent to Claude automatically on every MCP session via the <code>initialize</code> response <code>instructions</code> field.</p>
            </div>

            <div class="cmcp-card">
                <h2>📋 Quick Reference Prompts</h2>
                <table class="cmcp-table">
                    <tr><th>Task</th><th>Prompt</th></tr>
                    <tr><td>Session start</td><td><em>"Call context_summary with include_menus=true"</em></td></tr>
                    <tr><td>Before Elementor edit</td><td><em>"Get the structure of page 42"</em></td></tr>
                    <tr><td>Safe edit</td><td><em>"Backup page 42, then update the heading widget abc1234"</em></td></tr>
                    <tr><td>Bulk rename</td><td><em>"Replace 'OldBrand' with 'NewBrand' — dry run first"</em></td></tr>
                    <tr><td>Error log</td><td><em>"Show last 20 lines of the error log filtered by Fatal"</em></td></tr>
                    <tr><td>SEO check</td><td><em>"Run an SEO audit on the last 20 published posts"</em></td></tr>
                    <tr><td>Edit theme</td><td><em>"Read functions.php then add a snippet to disable Gutenberg"</em></td></tr>
                    <tr><td>Template</td><td><em>"Create a hero section template with blue background and CTA button"</em></td></tr>
                    <tr><td>Update plugin</td><td><em>"Read claude-wordpress-mcp.php then increase the rate limit to 200"</em></td></tr>
                    <tr><td>Update nav</td><td><em>"Get all menus then update the primary menu to add a Contact link"</em></td></tr>
                </table>
            </div>
        </div><!-- /tab-tips -->

        </div><!-- /wrap -->

        <style>
        .claude-mcp-wrap { max-width: 1200px; }
        .cmcp-header { background:#1e3a5f; border-radius:8px; padding:20px 24px 0; margin-bottom:20px; color:#fff; }
        .cmcp-header-inner { display:flex; align-items:center; gap:16px; margin-bottom:16px; }
        .cmcp-logo { font-size:40px; }
        .cmcp-header h1 { color:#fff; margin:0; font-size:24px; }
        .cmcp-header p { color:#93c5fd; margin:4px 0 0; font-size:13px; }
        .cmcp-tabs { display:flex; gap:2px; }
        .cmcp-tab { background:rgba(255,255,255,.1); border:none; color:#bfdbfe; padding:10px 18px; cursor:pointer; border-radius:6px 6px 0 0; font-size:13px; transition:.15s; }
        .cmcp-tab:hover { background:rgba(255,255,255,.2); color:#fff; }
        .cmcp-tab.active { background:#fff; color:#1e3a5f; font-weight:600; }
        .cmcp-tab-content { display:none; }
        .cmcp-tab-content.active { display:block; }
        .cmcp-muted { color:#64748b; }

        .cmcp-stats-row { display:flex; gap:12px; flex-wrap:wrap; margin-bottom:20px; }
        .cmcp-stat { background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:12px 20px; text-align:center; min-width:90px; }
        .cmcp-stat-num { display:block; font-size:22px; font-weight:700; color:#1e3a5f; }
        .cmcp-stat-label { font-size:11px; color:#64748b; }
        .cmcp-stat-green .cmcp-stat-num { color:#16a34a; }
        .cmcp-stat-gray .cmcp-stat-num { color:#94a3b8; }

        .cmcp-group { background:#fff; border:1px solid #e2e8f0; border-radius:8px; margin-bottom:14px; overflow:hidden; }
        .cmcp-group-header { display:flex; align-items:center; gap:12px; padding:12px 16px; background:#f8fafc; border-left:4px solid #2563eb; }
        .cmcp-group-icon { font-size:20px; }
        .cmcp-group-header strong { font-size:14px; color:#1e3a5f; display:block; }
        .cmcp-group-desc { font-size:12px; color:#64748b; }
        .cmcp-group-count { margin-left:auto; background:#2563eb; color:#fff; border-radius:12px; padding:2px 10px; font-size:12px; font-weight:600; white-space:nowrap; }
        .cmcp-badge-off { background:#fee2e2; color:#dc2626; border-radius:4px; padding:1px 6px; font-size:11px; }

        .cmcp-tool-list { padding:4px 0; }
        .cmcp-tool { display:flex; gap:14px; align-items:baseline; padding:8px 16px; border-bottom:1px solid #f1f5f9; }
        .cmcp-tool:last-child { border-bottom:none; }
        .cmcp-tool:hover { background:#f8fafc; }
        .cmcp-tool-name { min-width:220px; background:#eff6ff; color:#2563eb; padding:2px 8px; border-radius:4px; font-size:12px; border:1px solid #bfdbfe; white-space:nowrap; }
        .cmcp-tool-desc { font-size:13px; color:#374151; line-height:1.5; }
        .cmcp-tool-desc code { background:#f1f5f9; padding:1px 4px; border-radius:3px; font-size:11px; }
        .cmcp-tool-desc strong { color:#1e3a5f; }

        .cmcp-card { background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:20px 24px; margin-bottom:16px; }
        .cmcp-card h2 { margin-top:0; font-size:16px; color:#1e3a5f; }
        .cmcp-table { width:100%; border-collapse:collapse; }
        .cmcp-table th { text-align:left; padding:8px 12px; background:#f8fafc; width:160px; font-size:13px; color:#64748b; border:1px solid #e2e8f0; }
        .cmcp-table td { padding:8px 12px; border:1px solid #e2e8f0; font-size:13px; }
        .cmcp-table tr td:first-child { font-weight:600; color:#374151; }
        .cmcp-copyable { display:inline-block; background:#f1f5f9; padding:4px 10px; border-radius:4px; font-size:12px; word-break:break-all; max-width:420px; }
        .cmcp-key { display:inline-block; background:#f1f5f9; padding:8px 16px; border-radius:6px; font-size:13px; word-break:break-all; max-width:100%; border:1px solid #e2e8f0; }
        .cmcp-copy { margin-left:8px !important; }

        .cmcp-tip-list { display:flex; flex-direction:column; gap:14px; }
        .cmcp-tip { display:flex; gap:14px; align-items:flex-start; }
        .cmcp-tip-icon { font-size:22px; flex-shrink:0; }
        .cmcp-tip strong { display:block; color:#1e3a5f; margin-bottom:2px; }
        .cmcp-rules { margin:0; padding-left:20px; }
        .cmcp-rules li { margin-bottom:8px; font-size:13px; line-height:1.5; }
        .cmcp-rules li code { background:#f1f5f9; padding:1px 5px; border-radius:3px; }
        </style>

        <script>
        function cmcpActivateTab(name) {
            var btn = document.querySelector('.cmcp-tab[data-tab="' + name + '"]');
            var panel = document.getElementById('tab-' + name);
            if ( ! btn || ! panel ) return false;
            document.querySelectorAll('.cmcp-tab').forEach(function(t){ t.classList.remove('active'); });
            document.querySelectorAll('.cmcp-tab-content').forEach(function(c){ c.classList.remove('active'); });
            btn.classList.add('active');
            panel.classList.add('active');
            return true;
        }
        document.querySelectorAll('.cmcp-tab').forEach(function(tab) {
            tab.addEventListener('click', function() {
                cmcpActivateTab(tab.dataset.tab);
                // Update URL hash without scrolling so form posts return here.
                if ( history.replaceState ) history.replaceState(null, '', '#tab-' + tab.dataset.tab);
            });
        });
        // On page load, honor URL hash (e.g. #tab-license after a form redirect).
        (function(){
            var m = ( window.location.hash || '' ).match(/^#tab-([a-z0-9_-]+)$/i);
            if ( m && m[1] ) cmcpActivateTab(m[1]);
        })();
        document.querySelectorAll('.cmcp-copy').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var el = document.getElementById(btn.dataset.target);
                navigator.clipboard.writeText(el.textContent.trim()).then(function() {
                    var orig = btn.textContent; btn.textContent = '✅ Copied!';
                    setTimeout(function(){ btn.textContent = orig; }, 2000);
                });
            });
        });
        </script>
        <?php
    }
}
