<?php
/**
 * Standalone MCP Server - with full request logging
 */
ob_start();
error_reporting(0);
@ini_set('display_errors', 0);

require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';
require_once dirname(__FILE__) . '/includes/class-claude-mcp-oauth.php';
require_once dirname(__FILE__) . '/includes/class-claude-mcp-tools.php';
ob_end_clean();

// ── Log every request ─────────────────────────────────────────────────────────
function mcp_log($msg) {
    $log   = get_option('claude_mcp_debug_log', []);
    $log[] = ['time' => date('H:i:s'), 'msg' => $msg];
    if (count($log) > 100) $log = array_slice($log, -100);
    update_option('claude_mcp_debug_log', $log);
}

$method  = $_SERVER['REQUEST_METHOD'];
$all_hdrs = function_exists('getallheaders') ? getallheaders() : [];
$auth_hdr = $_SERVER['HTTP_AUTHORIZATION']
         ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
         ?? $all_hdrs['Authorization']
         ?? $all_hdrs['authorization']
         ?? 'NONE';
$accept   = $_SERVER['HTTP_ACCEPT'] ?? '';
$raw      = file_get_contents('php://input');

// v30.7.3+: redact the Authorization header to just the scheme + 4 chars of
// the credential, so the per-request log can still distinguish Bearer/Basic
// without exposing a usable token prefix (full tokens are 64+ chars).
$auth_scheme = (strpos($auth_hdr,'Bearer ')===0) ? 'Bearer' : ((strpos($auth_hdr,'Basic ')===0) ? 'Basic' : 'other');
$auth_tail   = ($auth_hdr === 'NONE') ? 'NONE' : substr($auth_hdr, strpos($auth_hdr,' ')===false ? 0 : strpos($auth_hdr,' ')+1, 4) . '...';
mcp_log("{$method} accept={$accept} auth={$auth_scheme} {$auth_tail} body=" . substr($raw,0,80));

// ── CORS ──────────────────────────────────────────────────────────────────────
// v30.7.0+: narrow CORS to claude.ai / anthropic.com origins only.
$cmcp_origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? trim( (string) $_SERVER['HTTP_ORIGIN'] ) : '';
$cmcp_host   = $cmcp_origin ? parse_url( $cmcp_origin, PHP_URL_HOST ) : '';
if ( $cmcp_host && ( $cmcp_host === 'claude.ai' || substr( $cmcp_host, -10 ) === '.claude.ai' || $cmcp_host === 'anthropic.com' || substr( $cmcp_host, -14 ) === '.anthropic.com' ) ) {
    header( 'Access-Control-Allow-Origin: ' . $cmcp_origin );
}
header( 'Vary: Origin' );
header('Access-Control-Allow-Methods: GET, POST, OPTIONS, DELETE');
header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept, Mcp-Session-Id, X-API-Key');
header('Access-Control-Expose-Headers: Mcp-Session-Id');

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ── Auth ──────────────────────────────────────────────────────────────────────
$api_key = get_option('claude_mcp_api_key', '');
$oauth   = new Claude_MCP_OAuth();
$authed  = false;

if (strpos($auth_hdr, 'Bearer ') === 0) {
    $token = trim(substr($auth_hdr, 7));
    if ($oauth->validate_token($token))              { $authed = true; mcp_log("Auth: OAuth token OK"); }
    elseif ($api_key && hash_equals($api_key,$token)){ $authed = true; mcp_log("Auth: API key OK"); }
    // v30.7.2+: log only 4 chars of the invalid token to debug which client
    // is failing without exposing a usable prefix. Full tokens are 64+ chars
    // so 4 chars is far below any brute-force concern.
    else { mcp_log("Auth: Bearer token invalid. Token prefix=" . substr($token,0,4) . "..."); }
}
if (!$authed && !empty($_SERVER['HTTP_X_API_KEY'])) {
    if ($api_key && hash_equals($api_key, $_SERVER['HTTP_X_API_KEY'])) { $authed = true; mcp_log("Auth: X-API-Key OK"); }
}
if (!$authed) {
    mcp_log("Auth FAILED. All headers: " . json_encode(array_keys($all_hdrs)));
    // Return 401 with WWW-Authenticate to trigger re-auth
    http_response_code(401);
    header('Content-Type: application/json');
    header('WWW-Authenticate: Bearer');
    echo json_encode(['error'=>'unauthorized','error_description'=>'Invalid or missing Bearer token.']);
    exit;
}

// ── GET = SSE ─────────────────────────────────────────────────────────────────
if ($method === 'GET') {
    @set_time_limit(0);
    @ini_set('output_buffering','off');
    @ini_set('zlib.output_compression',false);
    while (ob_get_level()>0) { @ob_end_clean(); }

    $scheme   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http';
    $post_url = $scheme . '://' . $_SERVER['HTTP_HOST'] . '/wp-json/claude-mcp/v1/mcp';

    mcp_log("SSE: sending endpoint=" . $post_url);

    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-store');
    header('X-Accel-Buffering: no');
    header('X-LiteSpeed-Cache-Control: no-cache, no-store');
    header('Connection: keep-alive');

    echo "event: endpoint\ndata: {$post_url}\n\n";
    @flush();

    $start = time();
    while ((time()-$start) < 55) {
        if (connection_aborted()) break;
        echo ": ping\n\n";
        @flush();
        sleep(3);
    }
    exit;
}

// ── POST = JSON-RPC ───────────────────────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$body = json_decode($raw, true);
if (json_last_error() !== JSON_ERROR_NONE || empty($body)) {
    mcp_log("Parse error: " . json_last_error_msg() . " raw=" . substr($raw,0,200));
    echo json_encode(['jsonrpc'=>'2.0','id'=>null,'error'=>['code'=>-32700,'message'=>'Parse error']]);
    exit;
}

$messages  = isset($body[0]) ? $body : [$body];
$responses = [];
$tools     = new Claude_MCP_Tools();

foreach ($messages as $msg) {
    $id     = $msg['id']     ?? null;
    $method = $msg['method'] ?? '';
    $params = $msg['params'] ?? [];
    mcp_log("RPC: {$method} id={$id}");

    switch ($method) {
        case 'initialize':
            $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>[
                'protocolVersion' => '2024-11-05',
                'capabilities'    => [
                    'tools'     => ['listChanged'=>false],
                    'resources' => ['subscribe'=>false,'listChanged'=>false],
                    'prompts'   => ['listChanged'=>false],
                ],
                'serverInfo' => ['name'=>'Claude WordPress MCP','version'=>defined('CLAUDE_MCP_VERSION') ? CLAUDE_MCP_VERSION : 'unknown'],
            ]];
            break;
        case 'notifications/initialized':
        case 'initialized':
            $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>(object)[]];
            break;
        case 'ping':
            $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>(object)[]];
            break;
        case 'tools/list':
            $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>['tools'=>$tools->get_tools()]];
            break;
        case 'tools/call':
            $name = $params['name'] ?? '';
            $args = $params['arguments'] ?? [];
            try {
                $result = $tools->execute_tool($name, $args);
                // v30.7.3+: execute_tool may now return a WP_Error for license
                // or permission denials. Convert those to a visible isError
                // response so Claude sees the real reason instead of a stale
                // success envelope with the error object serialized inside.
                if ( is_wp_error( $result ) ) {
                    $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>[
                        'content'=>[['type'=>'text','text'=>$result->get_error_message()]],
                        'isError'=>true,
                    ]];
                } else {
                    $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>[
                        'content'=>[['type'=>'text','text'=>json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)]],
                        'isError'=>false,
                    ]];
                }
            } catch (Exception $e) {
                $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>[
                    'content'=>[['type'=>'text','text'=>'Error: '.$e->getMessage()]],
                    'isError'=>true,
                ]];
            }
            break;
        case 'resources/list':
            $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>['resources'=>[]]];
            break;
        case 'prompts/list':
            $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'result'=>['prompts'=>[]]];
            break;
        default:
            if ($id !== null) {
                $responses[] = ['jsonrpc'=>'2.0','id'=>$id,'error'=>['code'=>-32601,'message'=>'Method not found: '.$method]];
            }
            break;
    }
}

$wants_sse = strpos($accept, 'text/event-stream') !== false;
if ($wants_sse) {
    @ini_set('output_buffering','off');
    while (ob_get_level()>0) { @ob_end_clean(); }
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-store');
    header('X-Accel-Buffering: no');
    header('X-LiteSpeed-Cache-Control: no-cache, no-store');
    foreach ($responses as $resp) {
        $data = json_encode($resp, JSON_UNESCAPED_UNICODE);
        echo "event: message\ndata: {$data}\n\n";
        @flush();
    }
    echo "event: close\ndata: {}\n\n";
    @flush();
} else {
    $out = count($responses)===1 ? $responses[0] : $responses;
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
}
exit;
