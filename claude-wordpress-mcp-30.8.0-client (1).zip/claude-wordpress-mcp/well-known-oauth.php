<?php
/**
 * Served at: /.well-known/oauth-authorization-server
 * Pure PHP — no WordPress dependency to avoid crashes.
 * Aggressive cache headers to prevent LiteSpeed/Airlift from corrupting JSON.
 */
header( 'Content-Type: application/json; charset=utf-8' );
// v30.7.0+: narrow CORS to claude.ai / anthropic.com. Discovery is public info,
// but tightening ACAO still blocks drive-by cross-origin reads from random sites.
$cmcp_origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? trim( (string) $_SERVER['HTTP_ORIGIN'] ) : '';
$cmcp_host   = $cmcp_origin ? parse_url( $cmcp_origin, PHP_URL_HOST ) : '';
if ( $cmcp_host && ( $cmcp_host === 'claude.ai' || substr( $cmcp_host, -10 ) === '.claude.ai' || $cmcp_host === 'anthropic.com' || substr( $cmcp_host, -14 ) === '.anthropic.com' ) ) {
    header( 'Access-Control-Allow-Origin: ' . $cmcp_origin );
}
header( 'Vary: Origin' );
header( 'Cache-Control: no-cache, no-store, must-revalidate' );
header( 'Pragma: no-cache' );
header( 'Expires: 0' );
header( 'X-LiteSpeed-Cache-Control: no-cache, no-store, must-revalidate' );
header( 'X-LiteSpeed-Tag: ' );
header( 'X-Accel-Buffering: no' );

$scheme = ( ! empty( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] !== 'off' ) ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'];
$site   = $scheme . '://' . $host;

echo json_encode( array(
    'issuer'                                => $site,
    'authorization_endpoint'                => $site . '/authorize',
    'token_endpoint'                        => $site . '/oauth/token',
    'response_types_supported'              => array( 'code' ),
    'grant_types_supported'                 => array( 'authorization_code' ),
    'code_challenge_methods_supported'      => array( 'S256' ),
    'token_endpoint_auth_methods_supported' => array( 'none' ),
) );
die();
