<?php
/**
 * Standalone OAuth token handler.
 * Accessed at: https://yourdomain.com/oauth/token
 * Routed here via .htaccess — no WordPress routing needed.
 */

// Bootstrap just enough of WordPress to use options API

$wp_load = dirname( dirname( dirname( dirname( __FILE__ ) ) ) ) . '/wp-load.php';
if ( ! file_exists( $wp_load ) ) {
    http_response_code( 500 );
    die( json_encode( array( 'error' => 'server_error', 'error_description' => 'Cannot locate WordPress.' ) ) );
}
require_once $wp_load;

header( 'Content-Type: application/json' );
// v30.7.0+: narrow CORS to claude.ai / anthropic.com origins only.
$cmcp_origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? trim( (string) $_SERVER['HTTP_ORIGIN'] ) : '';
$cmcp_host   = $cmcp_origin ? parse_url( $cmcp_origin, PHP_URL_HOST ) : '';
if ( $cmcp_host && ( $cmcp_host === 'claude.ai' || substr( $cmcp_host, -10 ) === '.claude.ai' || $cmcp_host === 'anthropic.com' || substr( $cmcp_host, -14 ) === '.anthropic.com' ) ) {
    header( 'Access-Control-Allow-Origin: ' . $cmcp_origin );
}
header( 'Vary: Origin' );
header( 'Access-Control-Allow-Methods: POST, GET, OPTIONS' );
header( 'Access-Control-Allow-Headers: Content-Type, Authorization' );
header( 'Cache-Control: no-store' );

if ( $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {
    http_response_code( 204 );
    exit;
}

// ── Parse params (try all formats) ────────────────────────────────────────────
$params = array();

// 1. Form-encoded POST body
if ( ! empty( $_POST ) ) {
    $params = $_POST;
}

// 2. JSON body
$raw = file_get_contents( 'php://input' );
if ( empty( $params['grant_type'] ) && ! empty( $raw ) ) {
    $json = json_decode( $raw, true );
    if ( is_array( $json ) && ! empty( $json['grant_type'] ) ) {
        $params = $json;
    }
}

// 3. Raw form body
if ( empty( $params['grant_type'] ) && ! empty( $raw ) ) {
    parse_str( $raw, $form );
    if ( ! empty( $form['grant_type'] ) ) {
        $params = $form;
    }
}

// 4. Query string
if ( empty( $params['grant_type'] ) ) {
    $params = array_merge( $_GET, $params );
}

$grant_type    = $params['grant_type']    ?? '';
$code          = $params['code']           ?? '';
$redirect_uri  = $params['redirect_uri']  ?? '';
$code_verifier = $params['code_verifier'] ?? '';

// ── Debug log ─────────────────────────────────────────────────────────────────
function claude_token_log( $msg ) {
    $log   = get_option( 'claude_mcp_debug_log', array() );
    $log[] = array( 'time' => date('H:i:s'), 'msg' => '[token.php] ' . $msg );
    if ( count($log) > 50 ) $log = array_slice( $log, -50 );
    update_option( 'claude_mcp_debug_log', $log );
}

claude_token_log( "Request: grant={$grant_type} code=" . substr($code,0,8) . " ct=" . ($_SERVER['CONTENT_TYPE']??'') );

function token_error( $error, $desc ) {
    claude_token_log( "Error: {$error} — {$desc}" );
    http_response_code( 400 );
    echo json_encode( array( 'error' => $error, 'error_description' => $desc ) );
    exit;
}

// ── Validate ──────────────────────────────────────────────────────────────────
if ( $grant_type !== 'authorization_code' ) {
    token_error( 'unsupported_grant_type', 'Expected authorization_code, got: ' . $grant_type );
}
if ( empty( $code ) ) {
    claude_token_log( 'Missing code. Raw: ' . substr($raw,0,300) );
    token_error( 'invalid_request', 'Missing code parameter.' );
}

$codes = get_option( 'claude_mcp_auth_codes', array() );
if ( ! isset( $codes[ $code ] ) ) {
    claude_token_log( 'Code not found. Count=' . count($codes) );
    token_error( 'invalid_grant', 'Invalid or expired authorization code.' );
}

$data = $codes[ $code ];
if ( time() > $data['expires'] ) {
    unset( $codes[ $code ] );
    update_option( 'claude_mcp_auth_codes', $codes );
    token_error( 'invalid_grant', 'Authorization code expired.' );
}

// PKCE — v30.7.3+: mandatory. The /authorize handler now rejects any flow
// without a code_challenge, so every stored code must have one. Clients MUST
// present a matching code_verifier here. Pre-30.7.3 this check was skipped
// entirely when the verifier was absent, defeating PKCE at this endpoint.
if ( empty( $data['code_challenge'] ) ) {
    claude_token_log( 'PKCE challenge missing from stored code (pre-30.5 code?).' );
    token_error( 'invalid_grant', 'PKCE challenge missing from stored authorization code.' );
}
if ( empty( $code_verifier ) ) {
    claude_token_log( 'Client sent no code_verifier.' );
    token_error( 'invalid_grant', 'code_verifier is required.' );
}
$method = $data['code_challenge_method'] ?? '';
if ( $method !== 'S256' ) {
    claude_token_log( 'Unsupported challenge method: ' . $method );
    token_error( 'invalid_grant', 'Unsupported code_challenge_method; this server requires S256.' );
}
$computed = rtrim( strtr( base64_encode( hash( 'sha256', $code_verifier, true ) ), '+/', '-_' ), '=' );
if ( ! hash_equals( $data['code_challenge'], $computed ) ) {
    claude_token_log( 'PKCE failed.' );
    token_error( 'invalid_grant', 'PKCE verification failed.' );
}

// Consume code & issue token
unset( $codes[ $code ] );
update_option( 'claude_mcp_auth_codes', $codes );

// v30.7.2+: issue via the Token_Store class (custom table) instead of the
// legacy wp_options store. Before 30.7.2 this file wrote raw tokens to
// wp_options['claude_mcp_tokens'], which the main OAuth validator could
// never find after the custom-table migration ran — breaking OAuth entirely.
$token = bin2hex( random_bytes( 32 ) );
if ( ! class_exists( 'Claude_MCP_Token_Store' ) ) {
    require_once dirname( __FILE__ ) . '/includes/class-claude-mcp-token-store.php';
}
Claude_MCP_Token_Store::issue( $token, $data['client_id'], 365 * 86400 );

claude_token_log( 'Token issued! client=' . $data['client_id'] );

echo json_encode( array(
    'access_token' => $token,
    'token_type'   => 'bearer',
    'expires_in'   => 365 * 86400,
    'scope'        => 'wordpress',
) );
exit;
